// Arabic text support for Dear ImGui.
// The ImGui draw list does not perform Arabic shaping or RTL reordering by itself.
#pragma once

#include <string>
#include <unordered_map>
#include <vector>
#include <cstdint>

namespace ArabicFix {

struct ShapeForm { uint32_t isolated, finalForm, initial, medial; bool joinsLeft; };

// Arabic Presentation Forms-B.  They are supported by the Android Arabic fonts
// and let ImGui display connected glyphs without requiring an extra linker lib.
static inline const ShapeForm* form(uint32_t c) {
    static const std::unordered_map<uint32_t, ShapeForm> f = {
        {0x0627,{0xFE8D,0xFE8E,0,0,false}}, {0x0628,{0xFE8F,0xFE90,0xFE91,0xFE92,true}},
        {0x062A,{0xFE95,0xFE96,0xFE97,0xFE98,true}}, {0x062B,{0xFE99,0xFE9A,0xFE9B,0xFE9C,true}},
        {0x062C,{0xFE9D,0xFE9E,0xFE9F,0xFEA0,true}}, {0x062D,{0xFEA1,0xFEA2,0xFEA3,0xFEA4,true}},
        {0x062E,{0xFEA5,0xFEA6,0xFEA7,0xFEA8,true}}, {0x062F,{0xFEA9,0xFEAA,0,0,false}},
        {0x0630,{0xFEAB,0xFEAC,0,0,false}}, {0x0631,{0xFEAD,0xFEAE,0,0,false}},
        {0x0632,{0xFEAF,0xFEB0,0,0,false}}, {0x0633,{0xFEB1,0xFEB2,0xFEB3,0xFEB4,true}},
        {0x0634,{0xFEB5,0xFEB6,0xFEB7,0xFEB8,true}}, {0x0635,{0xFEB9,0xFEBA,0xFEBB,0xFEBC,true}},
        {0x0636,{0xFEBD,0xFEBE,0xFEBF,0xFEC0,true}}, {0x0637,{0xFEC1,0xFEC2,0xFEC3,0xFEC4,true}},
        {0x0638,{0xFEC5,0xFEC6,0xFEC7,0xFEC8,true}}, {0x0639,{0xFEC9,0xFECA,0xFECB,0xFECC,true}},
        {0x063A,{0xFECD,0xFECE,0xFECF,0xFED0,true}}, {0x0641,{0xFED1,0xFED2,0xFED3,0xFED4,true}},
        {0x0642,{0xFED5,0xFED6,0xFED7,0xFED8,true}}, {0x0643,{0xFED9,0xFEDA,0xFEDB,0xFEDC,true}},
        {0x0644,{0xFEDD,0xFEDE,0xFEDF,0xFEE0,true}}, {0x0645,{0xFEE1,0xFEE2,0xFEE3,0xFEE4,true}},
        {0x0646,{0xFEE5,0xFEE6,0xFEE7,0xFEE8,true}}, {0x0647,{0xFEE9,0xFEEA,0xFEEB,0xFEEC,true}},
        {0x0648,{0xFEED,0xFEEE,0,0,false}}, {0x064A,{0xFEEF,0xFEF0,0xFEF1,0xFEF2,true}},
        {0x0629,{0xFE93,0xFE94,0,0,false}}, {0x0649,{0xFEF5,0xFEF6,0,0,false}},
        {0x0623,{0xFE83,0xFE84,0,0,false}}, {0x0625,{0xFE87,0xFE88,0,0,false}}, {0x0622,{0xFE81,0xFE82,0,0,false}}
    };
    auto it = f.find(c);
    return it == f.end() ? nullptr : &it->second;
}

static inline void putUtf8(std::string& out, uint32_t c) {
    if (c < 0x80) out.push_back((char)c);
    else if (c < 0x800) { out.push_back((char)(0xC0|(c>>6))); out.push_back((char)(0x80|(c&63))); }
    else { out.push_back((char)(0xE0|(c>>12))); out.push_back((char)(0x80|((c>>6)&63))); out.push_back((char)(0x80|(c&63))); }
}
static inline std::vector<uint32_t> decode(const std::string& s) {
    std::vector<uint32_t> v;
    for (size_t i=0;i<s.size();) { unsigned char c=s[i++]; uint32_t x=0;
        if(c<0x80)x=c; else if((c&0xE0)==0xC0){x=c&31; x=(x<<6)|(s[i++]&63);}
        else{x=c&15; x=(x<<6)|(s[i++]&63); x=(x<<6)|(s[i++]&63);} v.push_back(x); }
    return v;
}
static inline bool rtl(uint32_t c) { return c>=0x0600 && c<=0x06FF; }
static inline bool mark(uint32_t c) { return c>=0x064B && c<=0x065F; }

// Convert logical UTF-8 Arabic into the visual glyph order expected by ImGui.
static inline std::string ShapeForImGui(const std::string& input) {
    const auto in=decode(input); std::vector<uint32_t> out; size_t i=0;
    while(i<in.size()) {
        if(!rtl(in[i])) { out.push_back(in[i++]); continue; }
        size_t a=i; while(i<in.size() && (rtl(in[i])||mark(in[i])||in[i]==0x200C||in[i]==0x200D)) ++i;
        std::vector<uint32_t> run(in.begin()+a,in.begin()+i);
        for(size_t j=0;j<run.size();++j) { const ShapeForm* q=form(run[j]);
            if(!q) continue; bool prev=j>0&&form(run[j-1])&&form(run[j-1])->joinsLeft;
            bool next=j+1<run.size()&&form(run[j+1])&&q->joinsLeft;
            run[j]=(prev&&next&&q->medial)?q->medial:(prev&&q->finalForm)?q->finalForm:(next&&q->initial)?q->initial:q->isolated;
        }
        for(auto p=run.rbegin();p!=run.rend();++p) out.push_back(*p);
    }
    std::string result; for(uint32_t c:out) putUtf8(result,c); return result;
}

static inline std::string Normalize(const std::string& text) {
    // Old versions of the file contained Arabic Presentation Forms in reverse order.
    static const std::unordered_map<std::string,std::string> old = {
      {"ﻢﺳﺮﻟﺍ","الرسم"},{"ﻲﺋﺎﻘﻠﺘﻟﺍ","التقاتل"},{"ﻝﻮﺧﺪﻟﺍ","الدخول"},{"ﺕﺎﻣﻮﻠﻌﻤﻟﺍ","المعلومات"},{"ﻪﻐﻟﺍ","اللغة"},{"ﻪﻴﺑﺮﻌﻟﺍ","العربية"},{"ﺍﻺﻧﺠﻠﻴﺰﻳﺔ","الإنجليزية"},{"ﺕﺎﻗﺎﻄﺧ","الخطوط"},{"ﺏﻮﻴﺠﻟﺍ","الجيوب"},{"ﻲﻧﻮﻧﺎﻗ","قانوني"},{"ﻲﻛﺫ","ذكي"},{"ﻲﺸﺣﻭ","وحشي"},{"ﻥﺎﺴﻧﺇ","إنسان"},{"ﻡﻮﻘﻠﻟﺍ","التقليم"},{"ﺔﺒﻴﺘﺘﻓ","فترة"},{"ﺔﻗﺪﻟﺍ","الدقة"}
    };
    std::string r=text; for(const auto& p:old) { size_t n=0; while((n=r.find(p.first,n))!=std::string::npos){r.replace(n,p.first.size(),p.second);n+=p.second.size();} } return r;
}
static inline const char* PrepareForImGui(const char* text) {
    static std::unordered_map<std::string,std::string> cache; std::string key=text?text:"";
    auto it=cache.emplace(key,ShapeForImGui(Normalize(key))).first; return it->second.c_str();
}
static inline const char* FixArabic(const char* text) { return PrepareForImGui(text); }
static inline bool HasArabicErrors(const std::string& text) { return text.find("ﻢ")!=std::string::npos; }
static inline void InitializeArabicSupport() {}
}
#define FIX_ARABIC(text) ArabicFix::PrepareForImGui(text)
#define ARABIC(text) ArabicFix::PrepareForImGui(text)
