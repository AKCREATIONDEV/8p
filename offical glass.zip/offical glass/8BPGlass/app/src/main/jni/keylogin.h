#ifndef KEYLOGIN_H
#define KEYLOGIN_H

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <random>
#include <chrono>
#include <ctime>
#include <vector>
#include <algorithm>
#include <curl/curl.h>
#include <map>
#include "include/obfuscate.h"

// ============================================
// Server Configuration
// ============================================

const std::string API_BASE_URL = OO("https://robotai.freedev.app/lconnect").str();
const std::string DEFAULT_GAME = OO("pubg").str();

// ============================================
// Global Variables Definition
// ============================================

inline bool bValid = false;
inline bool logged_in = false;
inline bool is_logging_in = false;
inline std::string g_Token = "";
inline std::string g_Auth = "";
inline std::string g_ExpTime = "N/A";
inline std::string ERROR_MESSAGE = "";

// ============================================
// HTTP Helper Functions
// ============================================

inline size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* response) {
    response->append((char*)contents, size * nmemb);
    return size * nmemb;
}

inline std::string urlEncode(const std::string& value) {
    CURL* curl = curl_easy_init();
    if (!curl) return value;
    char* encoded = curl_easy_escape(curl, value.c_str(), (int)value.length());
    std::string result = encoded ? encoded : value;
    if (encoded) curl_free(encoded);
    curl_easy_cleanup(curl);
    return result;
}

inline std::string httpPost(const std::string& url, const std::string& postData) {
    CURL* curl = curl_easy_init();
    std::string response;
    
    if (!curl) {
        ERROR_MESSAGE = "Failed to initialize CURL";
        return "";
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    
    // x10.mx hosting block hone se bachane ke liye User-Agent
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36");
    
    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    headers = curl_slist_append(headers, "Accept: application/json, text/plain, */*");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    
    CURLcode res = curl_easy_perform(curl);
    
    if (res != CURLE_OK) {
        ERROR_MESSAGE = "Connection failed: " + std::string(curl_easy_strerror(res));
    }
    
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    
    return response;
}

// ============================================
// Simple JSON Parser
// ============================================

inline std::string extractJsonString(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\"";
    size_t keyPos = json.find(searchKey);
    if (keyPos == std::string::npos) return "";
    
    size_t valuePos = json.find(":", keyPos);
    if (valuePos == std::string::npos) return "";
    
    size_t quote1 = json.find("\"", valuePos);
    if (quote1 == std::string::npos) return "";
    
    size_t quote2 = json.find("\"", quote1 + 1);
    if (quote2 == std::string::npos) return "";
    
    return json.substr(quote1 + 1, quote2 - quote1 - 1);
}

// ============================================
// Server Verification Logic
// ============================================

inline bool verifyWithYourServer(const std::string& license_key, const std::string& hwid) {
    std::string postData = "game=" + urlEncode(DEFAULT_GAME) +
                           "&user_key=" + urlEncode(license_key) +
                           "&serial=" + urlEncode(hwid);
    
    std::string response = httpPost(API_BASE_URL, postData);
    
    if (response.empty()) {
        if (ERROR_MESSAGE.empty()) {
            ERROR_MESSAGE = "No response from server";
        }
        return false;
    }
    
    // Check if status is true
    if (response.find("\"status\":true") != std::string::npos || 
        response.find("\"status\": true") != std::string::npos) {
        
        std::string expiry = extractJsonString(response, "EXP");
        if (!expiry.empty()) g_ExpTime = expiry;
        
        std::string token = extractJsonString(response, "token");
        if (token.empty()) token = license_key;
        
        g_Token = token;
        g_Auth = token;
        return true;
    }
    
    // Extract failure reason
    std::string reason = extractJsonString(response, "reason");
    if (!reason.empty()) {
        // Agar server abhi bhi Arabic bhejta hai toh use English mein translate karein
        if (reason.find("المفتاح") != std::string::npos || reason.find("غير صالح") != std::string::npos) {
            ERROR_MESSAGE = "Invalid License Key";
        } else {
            ERROR_MESSAGE = reason;
        }
    } else {
        ERROR_MESSAGE = "Invalid License Key";
    }
    
    return false;
}

// ============================================
// Main Login Function
// ============================================

inline bool Login(std::string androidID, std::string key) {
    is_logging_in = true;
    ERROR_MESSAGE.clear();
    
    if (androidID.empty()) {
        ERROR_MESSAGE = "Unable to get Device ID (HWID)";
        is_logging_in = false;
        return false;
    }
    
    if (key.empty()) {
        ERROR_MESSAGE = "License Key cannot be empty";
        is_logging_in = false;
        return false;
    }
    
    if (verifyWithYourServer(key, androidID)) {
        logged_in = true;
        bValid = true;
        is_logging_in = false;
        return true;
    }
    
    logged_in = false;
    g_Token = "";
    g_Auth = "";
    bValid = false;
    is_logging_in = false;
    return false;
}

#endif // KEYLOGIN_H
