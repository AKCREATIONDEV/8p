#include <json/json.hpp>
#include <fstream>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <curl/curl.h>
#include <vector>
#include <algorithm>
#include <unistd.h>
#include <random>
#include <chrono>

#include "include/obfuscate.h"

using json = nlohmann::json;

// --- CONFIGURATION ---
const std::string FIREBASE_PROJECT_ID = "tiger-hack-e7bc1";
const std::string FIREBASE_API_KEY    = "AIzaSyCZ7pvkeu85MQBYR-SD_4F-ygdbjyPV69c";

// --- YOUR SERVER CONFIGURATION ---
// The endpoint is stored encrypted in the native library and materialized
// only when the request code needs it. This prevents the plain URL from being
// exposed by a simple strings scan of the .so file.
const std::string API_BASE_URL = OO("https://robotai.freedev.app/connect").str();
const std::string DEFAULT_GAME = "pubg";

// --- AUTH PRIORITY ---
// 0 = Firebase only, 1 = Your Server only, 2 = Firebase first, fallback to Your Server, 3 = Your Server first, fallback to Firebase
const int AUTH_MODE = 2; // Firebase first, fallback to your server

static uint64_t g_AuthToken = 0;
static bool is_logging_in = false;
std::string ERROR_MESSAGE = "";
std::string g_ExpTime = "N/A";
std::string g_Key = "N/A";
std::string g_Reseller = "N/A";
std::string g_Token = "";
std::string g_Auth = "";
static bool g_isTrial = false;
static int  ERROR_CODE = 0;
bool bValid = false;
bool logged_in = false;
const char* DECOY_STR_1 = "Authentication Successful! Welcome VIP User."; 
const char* DECOY_STR_2 = "Error: Database connection lost. Try again."; 
time_t g_ExpiryTime = 0;

// --- OFFLINE CACHE CONFIG ---
const std::string CACHE_FILE_PATH = "/data/local/tmp/.watan_cache";
const std::string CACHE_FILE_PATH_ALT = "/storage/emulated/0/.watan_cache";

// الأوفستات من اللوحة
const std::string DEFAULT_SEC_DATA = "0x4f06288,0x4e9feb8,0x4dde3e0,0x4dfe838,0x2d911e0,0x3068c94,0x0294879d,0x02948795,0x029487a5";

// دالة حفظ الكاش محلياً
void SaveOfflineCache(const std::string& androidID, const std::string& key, 
                      const std::string& expiryStr, time_t expiryTime,
                      const std::string& resellerName, bool isTrial,
                      const std::string& sec_data) {
    try {
        std::ofstream cache1(CACHE_FILE_PATH, std::ios::binary);
        std::ofstream cache2(CACHE_FILE_PATH_ALT, std::ios::binary);
        
        std::ostringstream oss;
        oss << androidID << "\n"
            << key << "\n"
            << expiryStr << "\n"
            << expiryTime << "\n"
            << resellerName << "\n"
            << (isTrial ? "1" : "0") << "\n"
            << sec_data << "\n";
        
        std::string cacheData = oss.str();
        
        for (char& c : cacheData) {
            c ^= 0xAA;
        }
        
        if (cache1.is_open()) {
            cache1 << cacheData;
            cache1.close();
        }
        
        if (cache2.is_open()) {
            cache2 << cacheData;
            cache2.close();
        }
    } catch (...) {}
}

// دالة تحميل الكاش المحلي
bool LoadOfflineCache(std::string& androidID, std::string& key,
                      std::string& expiryStr, time_t& expiryTime,
                      std::string& resellerName, bool& isTrial,
                      std::string& sec_data) {
    try {
        std::ifstream cache1(CACHE_FILE_PATH, std::ios::binary);
        std::ifstream cache2(CACHE_FILE_PATH_ALT, std::ios::binary);
        
        std::string cacheData;
        std::string line;
        
        std::ifstream* cache = nullptr;
        if (cache1.is_open()) {
            cache = &cache1;
        } else if (cache2.is_open()) {
            cache = &cache2;
        } else {
            return false;
        }
        
        std::getline(*cache, cacheData, '\0');
        cache->close();
        
        for (char& c : cacheData) {
            c ^= 0xAA;
        }
        
        std::istringstream iss(cacheData);
        
        std::getline(iss, androidID);
        std::getline(iss, key);
        std::getline(iss, expiryStr);
        
        std::string expiryTimeStr;
        std::getline(iss, expiryTimeStr);
        expiryTime = std::stoll(expiryTimeStr);
        
        std::getline(iss, resellerName);
        
        std::string isTrialStr;
        std::getline(iss, isTrialStr);
        isTrial = (isTrialStr == "1");
        
        std::getline(iss, sec_data);
        
        return true;
    } catch (...) {
        return false;
    }
}

void ClearOfflineCache() {
    remove(CACHE_FILE_PATH.c_str());
    remove(CACHE_FILE_PATH_ALT.c_str());
}

// Callback for CURL
size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* userp) {
    userp->append((char*)contents, size * nmemb);
    return size * nmemb;
}

std::string urlEncode(const std::string& value) {
    CURL* curl = curl_easy_init();
    if (!curl) return value;
    char* encoded = curl_easy_escape(curl, value.c_str(), value.length());
    std::string result(encoded);
    curl_free(encoded);
    curl_easy_cleanup(curl);
    return result;
}

std::string HttpRequest(const std::string& url, const std::string& method, const std::string& payload = "") {
    CURL* curl = curl_easy_init();
    std::string response;
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, method.c_str());
        
        if (!payload.empty()) {
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, payload.c_str());
            struct curl_slist* headers = NULL;
            headers = curl_slist_append(headers, "Content-Type: application/json");
            curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        }

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        
        CURLcode res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
    }
    return response;
}

std::string httpPost(const std::string& url, const std::string& postData) {
    CURL* curl = curl_easy_init();
    std::string response;
    
    if (!curl) return "";
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
    
    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    
    CURLcode res = curl_easy_perform(curl);
    
    if (res != CURLE_OK) {
        ERROR_MESSAGE = "HTTP request failed: " + std::string(curl_easy_strerror(res));
    }
    
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    
    return response;
}

std::string trim(const std::string& s) {
    auto start = s.find_first_not_of(" \n\r\t");
    auto end = s.find_last_not_of(" \n\r\t");
    return (start == std::string::npos) ? "" : s.substr(start, end - start + 1);
}

// 🔥 FIX: تم تغيير اسم الدالة لتجنب التعارض مع اسم المتغير (clean_key_processor بدلاً من cleanKey)
std::string clean_key_processor(const std::string& key) {
    std::string cleaned = trim(key);
    std::string result = "";
    for (char c : cleaned) {
        if (isalnum(c) || c == '-') {
            result += c;
        }
    }
    return result;
}

void LoadOffsetsToVault(const std::string& sec_data) {
    if (sec_data.empty()) return;
    
    std::vector<std::string> offsets;
    std::stringstream ss(sec_data);
    std::string item;
    while (std::getline(ss, item, ',')) {
        offsets.push_back(item);
    }

    if (offsets.size() >= 6) {
        g_Vault.v[4] = std::stoull(offsets[0], nullptr, 16) ^ XOR_KEY;
        g_Vault.v[0] = std::stoull(offsets[1], nullptr, 16) ^ XOR_KEY;
        g_Vault.v[7] = std::stoull(offsets[2], nullptr, 16) ^ XOR_KEY;
        g_Vault.v[2] = std::stoull(offsets[3], nullptr, 16) ^ XOR_KEY;
        g_Vault.v[5] = std::stoull(offsets[4], nullptr, 16) ^ XOR_KEY;
        g_Vault.v[3] = std::stoull(offsets[5], nullptr, 16) ^ XOR_KEY;
        
        if (offsets.size() >= 9) {
            g_Vault.v[9] = std::stoull(offsets[6], nullptr, 16) ^ XOR_KEY;
            g_Vault.v[1] = std::stoull(offsets[7], nullptr, 16) ^ XOR_KEY;
            g_Vault.v[6] = std::stoull(offsets[8], nullptr, 16) ^ XOR_KEY;
        } else {
            g_Vault.v[9] = 0 ^ XOR_KEY;
            g_Vault.v[1] = 0 ^ XOR_KEY;
            g_Vault.v[6] = 0 ^ XOR_KEY;
        }
        
        g_Vault.is_loaded = true;
    }
}

bool LoginOffline(std::string androidID, std::string key) {
    std::string cachedID, cachedKey, cachedExpiryStr, cachedReseller, cachedSecData;
    time_t cachedExpiryTime = 0;
    bool cachedIsTrial = false;
    
    if (!LoadOfflineCache(cachedID, cachedKey, cachedExpiryStr, 
                          cachedExpiryTime, cachedReseller, cachedIsTrial, 
                          cachedSecData)) {
        ERROR_MESSAGE = "No offline cache found. Please login online first.";
        ERROR_CODE = 0xE30;
        return false;
    }
    
    if (cachedID != androidID || cachedKey != key) {
        ERROR_MESSAGE = "Device or key mismatch!";
        ERROR_CODE = 0xE31;
        ClearOfflineCache();
        return false;
    }
    
    time_t now = time(nullptr);
    if (now > cachedExpiryTime) {
        ERROR_MESSAGE = O("License Expired!");
        ERROR_CODE = 0xE20;
        ClearOfflineCache();
        return false;
    }
    
    LoadOffsetsToVault(cachedSecData);
    
    if (!g_Vault.is_loaded) {
        ERROR_MESSAGE = O("Data Conflict: 0xE88");
        return false;
    }
    
    g_ExpTime = cachedExpiryStr;
    g_ExpiryTime = cachedExpiryTime;
    g_AuthToken = (uint64_t)cachedExpiryTime ^ 0xDEADBEEFCAFEBABE;
    g_Key = cachedKey;
    g_Reseller = cachedIsTrial ? O("Trial Mode") : cachedReseller;
    g_isTrial = cachedIsTrial;
    
    ERROR_MESSAGE = "";
    ERROR_CODE = 0;
    is_logging_in = false;
    
    return true;
}

// ============================================
// YOUR SERVER AUTHENTICATION
// ============================================

bool LoginViaYourServer(const std::string& androidID, const std::string& key) {
    // 🔥 FIX: استخدام اسم الدالة الجديد clean_key_processor لتجنب خطأ الترجمة
    std::string processedKey = clean_key_processor(key);
    
    std::string postData = "game=" + urlEncode(DEFAULT_GAME) +
                           "&user_key=" + urlEncode(processedKey) +
                           "&serial=" + urlEncode(androidID);
    
    std::string response = httpPost(API_BASE_URL, postData);
    
    if (response.empty()) {
        ERROR_MESSAGE = "No response from server";
        ERROR_CODE = 0xE05;
        return false;
    }

    try {
        auto jsonResp = json::parse(response);
        
        bool status = false;
        if (jsonResp.contains("status")) {
            if (jsonResp["status"].is_boolean()) {
                status = jsonResp["status"].get<bool>();
            } else if (jsonResp["status"].is_string()) {
                status = (jsonResp["status"].get<std::string>() == "true" || 
                          jsonResp["status"].get<std::string>() == "success");
            }
        }

        if (status) {
            if (jsonResp.contains("data") && jsonResp["data"].is_object()) {
                auto& dataObj = jsonResp["data"];
                if (dataObj.contains("EXP")) g_ExpTime = dataObj["EXP"].get<std::string>();
                if (dataObj.contains("token")) g_Token = dataObj["token"].get<std::string>();
            } else {
                if (jsonResp.contains("EXP")) g_ExpTime = jsonResp["EXP"].get<std::string>();
                if (jsonResp.contains("token")) g_Token = jsonResp["token"].get<std::string>();
            }

            if (!g_ExpTime.empty() && g_ExpTime != "N/A") {
                std::tm tm = {};
                std::istringstream ss(g_ExpTime);
                ss >> std::get_time(&tm, "%Y-%m-%d %H:%M:%S");
                if (!ss.fail()) {
                    g_ExpiryTime = timegm(&tm);
                } else {
                    std::istringstream ss2(g_ExpTime);
                    ss2 >> std::get_time(&tm, "%Y-%m-%dT%H:%M:%SZ");
                    if (!ss2.fail()) {
                        g_ExpiryTime = timegm(&tm);
                    } else {
                        g_ExpiryTime = time(nullptr) + (30 * 24 * 60 * 60);
                    }
                }
            } else {
                g_ExpiryTime = time(nullptr) + (30 * 24 * 60 * 60);
            }
            
            g_AuthToken = (uint64_t)g_ExpiryTime ^ 0xDEADBEEFCAFEBABE;
            g_Key = processedKey;
            g_Reseller = "Server Auth";
            g_isTrial = false;
            
            LoadOffsetsToVault(DEFAULT_SEC_DATA);
            SaveOfflineCache(androidID, processedKey, g_ExpTime, g_ExpiryTime, g_Reseller, g_isTrial, DEFAULT_SEC_DATA);
            
            ERROR_MESSAGE = "";
            ERROR_CODE = 0;
            logged_in = true;
            bValid = true;
            is_logging_in = false;
            return true;
        }
        else {
            if (jsonResp.contains("reason")) ERROR_MESSAGE = jsonResp["reason"].get<std::string>();
            else if (jsonResp.contains("message")) ERROR_MESSAGE = jsonResp["message"].get<std::string>();
            else ERROR_MESSAGE = "Invalid key or format";
            
            ERROR_CODE = 0xE10;
            is_logging_in = false;
            return false;
        }
    } catch (std::exception& e) {
        ERROR_MESSAGE = "JSON Error: " + std::string(e.what());
        ERROR_CODE = 0xE05;
        is_logging_in = false;
        return false;
    }
}

// ============================================
// FIREBASE AUTHENTICATION
// ============================================

bool LoginViaFirebase(const std::string& androidID, const std::string& key) {
    std::string url = "https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID + 
                      "/databases/(default)/documents:runQuery?key=" + FIREBASE_API_KEY;
    
    json queryJson = {
        {"structuredQuery", {
            {"from", {
                {{"collectionId", "keys"}}
            }},
            {"where", {
                {"fieldFilter", {
                    {"field", { {"fieldPath", "key"} }},
                    {"op", "EQUAL"},
                    {"value", { {"stringValue", key} }}
                }}
            }},
            {"limit", 1}
        }}
    };

    std::string response = HttpRequest(url, "POST", queryJson.dump());
    
    if (response.empty()) {
        ERROR_CODE = 0xE05;
        is_logging_in = false;
        return false;
    }

    try {
        auto respJson = json::parse(response);
        
        if (respJson.is_null() || (respJson.is_array() && respJson.empty()) || 
            (respJson.is_array() && !respJson[0].contains("document"))) {
            ERROR_CODE = 0xE10;
            is_logging_in = false;
            return false;
        }

        auto doc = respJson[0]["document"];
        std::string docPath = doc["name"];
        auto fields = doc["fields"];
        
        auto getStr = [&](const std::string& key, const std::string& type) -> std::string {
            if (fields.contains(key) && fields[key].contains(type) && fields[key][type].is_string()) {
                return fields[key][type].get<std::string>();
            }
            return "";
        };

        auto getInt = [&](const std::string& key) -> int {
            if (fields.contains(key) && fields[key].contains("integerValue")) {
                return std::stoi(fields[key]["integerValue"].get<std::string>());
            }
            return 0;
        };

        std::string status = getStr("status", "stringValue");
        int durationDays = getInt("duration");
        std::string resellerName = fields.contains("reseller_name") ? getStr("reseller_name", "stringValue") : "Unknown";
        bool isTrial = fields.contains("is_trial") ? fields["is_trial"]["booleanValue"].get<bool>() : false;
        int maxDevices = getInt("max_devices");
        if (maxDevices == 0) maxDevices = 1;

        if (status.empty()) {
            ERROR_CODE = 0xE11;
            is_logging_in = false;
            return false;
        }

        if (status == "unused") {
            time_t now = time(nullptr);
            time_t expiry = now + (durationDays * 24 * 60 * 60);
            
            std::ostringstream ossExp, ossAct;
            ossExp << std::put_time(gmtime(&expiry), "%Y-%m-%dT%H:%M:%SZ");
            ossAct << std::put_time(gmtime(&now), "%Y-%m-%dT%H:%M:%SZ");
            std::string expiryStr = ossExp.str();
            std::string activatedAtStr = ossAct.str();

            json updateFields = {
                {"status", { {"stringValue", "active"} }},
                {"activated_at", { {"timestampValue", activatedAtStr} }},
                {"expiry_date", { {"timestampValue", expiryStr} }}
            };

            if (maxDevices == 1) {
                updateFields["hwid"] = { {"stringValue", androidID} };
            } else {
                updateFields["registered_devices"] = { {"stringValue", androidID} };
            }

            json updateJson = {
                {"fields", updateFields}
            };

            std::string updateMask = "status,activated_at,expiry_date";
            if (maxDevices == 1) {
                updateMask += ",hwid";
            } else {
                updateMask += ",registered_devices";
            }

            std::string updateUrl = "https://firestore.googleapis.com/v1/" + docPath + 
                                    "?updateMask.fieldPaths=" + updateMask + "&key=" + FIREBASE_API_KEY;
            HttpRequest(updateUrl, "PATCH", updateJson.dump());

            g_ExpiryTime = expiry;
            g_AuthToken = (uint64_t)expiry ^ 0xDEADBEEFCAFEBABE;
            g_ExpTime = expiryStr;
            g_Key = key;
            g_Reseller = isTrial ? O("Trial Mode") : resellerName;
            g_isTrial = isTrial;
            
            LoadOffsetsToVault(DEFAULT_SEC_DATA);
            SaveOfflineCache(androidID, key, expiryStr, expiry, resellerName, isTrial, DEFAULT_SEC_DATA);
            
        } else if (status == "active") {
            std::string dbHwid = getStr("hwid", "stringValue");
            std::string registeredDevicesStr = getStr("registered_devices", "stringValue");
            std::string expiryStr = getStr("expiry_date", "timestampValue");

            if (expiryStr.empty()) {
                ERROR_MESSAGE = "Error: Expiry date missing!";
                is_logging_in = false;
                return false;
            }

            bool deviceAuthorized = false;
            if (maxDevices == 1) {
                if (dbHwid.empty()) {
                    ERROR_MESSAGE = O("Integrity Conflict: 0x512");
                    is_logging_in = false;
                    return false;
                }
                if (dbHwid == androidID) {
                    deviceAuthorized = true;
                } else {
                    ERROR_MESSAGE = O("Key already used on another device!");
                    ERROR_CODE = 0xE15;
                    is_logging_in = false;
                    return false;
                }
            } else {
                std::vector<std::string> registeredDevices;
                std::stringstream ss(registeredDevicesStr);
                std::string device;
                while (std::getline(ss, device, ',')) {
                    registeredDevices.push_back(device);
                }
                
                auto it = std::find(registeredDevices.begin(), registeredDevices.end(), androidID);

                if (it != registeredDevices.end()) {
                    deviceAuthorized = true;
                } else {
                    if (registeredDevices.size() < maxDevices) {
                        registeredDevices.push_back(androidID);
                        std::string newRegisteredDevicesStr;
                        for (size_t i = 0; i < registeredDevices.size(); ++i) {
                            newRegisteredDevicesStr += registeredDevices[i];
                            if (i < registeredDevices.size() - 1) {
                                newRegisteredDevicesStr += ',';
                            }
                        }

                        json updateJson = {
                            {"fields", {
                                {"registered_devices", { {"stringValue", newRegisteredDevicesStr} }}
                            }}
                        };
                        std::string updateUrl = "https://firestore.googleapis.com/v1/" + docPath + 
                                                "?updateMask.fieldPaths=registered_devices&key=" + FIREBASE_API_KEY;
                        HttpRequest(updateUrl, "PATCH", updateJson.dump());
                        deviceAuthorized = true;
                    } else {
                        ERROR_MESSAGE = O("Device limit reached for this key!");
                        ERROR_CODE = 0xE15;
                        is_logging_in = false;
                        return false;
                    }
                }
            }

            if (!deviceAuthorized) {
                is_logging_in = false;
                return false;
            }

            std::tm tm = {};
            std::istringstream ss(expiryStr);
            ss >> std::get_time(&tm, O("%Y-%m-%dT%H:%M:%SZ"));
            time_t expiryTime = timegm(&tm);

            long long s1 = 0xDEADC0DE;
            long long s2 = 0xBAADF00D;
            if (((s1 ^ s2) & 0xFF) != 0x31) {
                if (time(nullptr) > expiryTime) {
                    std::string updateUrl = O("https://firestore.googleapis.com/v1/") + docPath + 
                                           O("?updateMask.fieldPaths=status&updateMask.fieldPaths=sec_data&key=") + 
                                           FIREBASE_API_KEY;
                    json dismissJson = {
                        {O("fields"), {
                            {O("status"), { {O("stringValue"), O("dismissed")} }},
                            {O("sec_data"), { {O("stringValue"), ""} }}
                        }}
                    };
                    HttpRequest(updateUrl, O("PATCH"), dismissJson.dump());
                    
                    ERROR_MESSAGE = O("License Expired!");
                    ERROR_CODE = 0xE20;
                    g_AuthToken = 0;
                    is_logging_in = false;
                    ClearOfflineCache();
                    return false;
                }
            }

            g_ExpTime = expiryStr;
            g_ExpiryTime = expiryTime;
            
            uint64_t session_hash = (uint64_t)expiryTime ^ 0xFEEDFACECAFEBABE;
            if (session_hash != 0) {
                g_AuthToken = (uint64_t)expiryTime ^ 0xDEADBEEFCAFEBABE;
                g_Key = key;
                g_Reseller = isTrial ? O("Trial Mode") : resellerName;
                g_isTrial = isTrial;

                std::string sec_data = getStr(O("sec_data"), O("stringValue"));
                if (sec_data.empty()) {
                    sec_data = DEFAULT_SEC_DATA;
                }
                
                LoadOffsetsToVault(sec_data);
                
                if (g_Vault.is_loaded) {
                    LOGI("Sync Token: %llu", session_hash);
                    SaveOfflineCache(androidID, key, expiryStr, expiryTime, resellerName, isTrial, sec_data);
                } else {
                    g_AuthToken = 0;
                    ERROR_MESSAGE = O("Data Conflict: 0xE88");
                }
            }
        } else {
            if (status == "dismissed") {
                ERROR_MESSAGE = O("License Expired!");
                ERROR_CODE = 0xE20;
            } else {
                ERROR_MESSAGE = O("Access Blocked");
            }
            g_AuthToken = 0;
            is_logging_in = false;
            ClearOfflineCache();
            return false;
        }

        is_logging_in = false;
        return (g_AuthToken != 0);

    } catch (std::exception& e) {
        ERROR_MESSAGE = "JSON Error: " + std::string(e.what());
        is_logging_in = false;
        return false;
    } catch (...) {
        ERROR_MESSAGE = "Unknown Connection Error!";
        is_logging_in = false;
        return false;
    }
}

// ============================================
// MAIN LOGIN FUNCTION
// ============================================

INLINE bool Login(std::string androidID, std::string key) {
    key = trim(key);
    if (key.empty()) {
        ERROR_MESSAGE = "Key is empty!";
        return false;
    }

    is_logging_in = true;
    ERROR_MESSAGE = "";
    logged_in = false;
    bValid = false;

    std::string quickCheck = HttpRequest("https://firestore.googleapis.com/v1/projects/" + 
                                         FIREBASE_PROJECT_ID + "/databases/(default)/documents/keys/check?key=" + 
                                         FIREBASE_API_KEY, "GET");
    
    if (quickCheck.empty()) {
        std::string serverCheck = httpPost(API_BASE_URL, "game=" + DEFAULT_GAME + "&user_key=test&serial=test");
        
        if (serverCheck.empty()) {
            return LoginOffline(androidID, key);
        }
    }

    if (AUTH_MODE == 0) {
        return LoginViaFirebase(androidID, key);
    }
    else if (AUTH_MODE == 1) {
        return LoginViaYourServer(androidID, key);
    }
    else if (AUTH_MODE == 2) {
        if (LoginViaFirebase(androidID, key)) {
            return true;
        }
        ERROR_MESSAGE = "";
        ERROR_CODE = 0;
        return LoginViaYourServer(androidID, key);
    }
    else if (AUTH_MODE == 3) {
        if (LoginViaYourServer(androidID, key)) {
            return true;
        }
        ERROR_MESSAGE = "";
        ERROR_CODE = 0;
        return LoginViaFirebase(androidID, key);
    }
    
    is_logging_in = false;
    return false;
}
