#pragma once

#include <Vector/Vectors.h>
#include <imgui/imgui.h>
#include "include/font_arial_black.h"
#include "include/font_segoeui.h"
#include "include/font_fontawesome.h"

#include "icons/icons.h"

using namespace ImGui;
using namespace std;

#include <chrono>
#include <unordered_map>
#include <thread>
#include "include/includes.h"

#include "game.h"
#include "game/Ruleset.h"
#include "imgui/inc/8bp.h"
#include "mod/keylogin.h"
#include "oxorany/oxorany.h"

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <sys/system_properties.h>
#include <ctime>

static float menuScale = 1.0f;

#define CLAMP(v, min, max) ((v) < (min) ? (min) : ((v) > (max) ? (max) : (v)))

struct MenuState {
    bool isOpen = false;
    int currentTab = 0;
    float sidebarW = 920.0f;
    float animProgress = 0.0f;
    float menuAlpha = 0.0f;
    float menuScale = 0.9f;
    bool showLanguageSelector = false; // شاشة اختيار اللغة بعد تسجيل الدخول
    ImVec4 accentColor = ImVec4(0.0f, 0.5f, 1.0f, 1.0f);
};
static MenuState g_menu;

static ImFont* g_ArialBlackFont = nullptr;
static ImFont* g_SegoeUIFont = nullptr;
static ImFont* g_IconFont = nullptr;

// OpenGL textures belong to the current EGL context. They must be recreated
// after a surface/context reset; otherwise ImGui receives stale texture IDs.
static EGLContext g_uiTextureContext = EGL_NO_CONTEXT;
static GLuint g_logoTexture = 0;
static GLuint g_telegramTexture = 0;

static void EnsureUiTextures() {
    EGLContext currentContext = eglGetCurrentContext();
    if (currentContext == EGL_NO_CONTEXT) return;

    if (g_uiTextureContext != currentContext) {
        // Do not delete IDs here: they belong to the previous context and are
        // already invalid there. Just invalidate the cache and recreate below.
        g_uiTextureContext = currentContext;
        g_logoTexture = 0;
        g_telegramTexture = 0;
        if (bImguiSetup) {
            ImGui_ImplOpenGL3_DestroyDeviceObjects();
            ImGui_ImplOpenGL3_CreateDeviceObjects();
        }
    }

    if (g_logoTexture == 0) {
        g_logoTexture = LoadTextureFromMemory(logo_png, logo_png_len);
    }
    if (g_telegramTexture == 0) {
        g_telegramTexture = LoadTextureFromMemory(tele_logo_img, sizeof(tele_logo_img));
    }
}

// Modified global expiry to support dynamic bypass keys
static int64_t G_EXPIRY_TS = 2000000000LL; // Default placeholder

static string formatTimestamp(int64_t ts) {
    if (ts <= 0) return O("N/A");
    time_t t = (time_t)ts;
    struct tm tm_info;
    localtime_r(&t, &tm_info);
    char buffer[64];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &tm_info);
    return string(buffer);
}

static bool DEBUG_BYPASS_LOGIN = false; // Set to true to test menu without firebase login

static const int CLIENT_VERSION = 1; // Current version of this APK/library
static bool g_UpdateRequired = false;
static string g_UpdateURL = "";

// ============================================
// دالة الترجمة ودعم اللغة العربية
// ============================================
static const ImWchar* GetArabicGlyphRanges() {
    static const ImWchar ranges[] = {
        0x0020, 0x00FF,  // Basic Latin
        0x0600, 0x06FF,  // Arabic
        0x0750, 0x077F,  // Arabic Supplement
        0xFB50, 0xFDFF,  // Arabic Presentation Forms-A
        0xFE70, 0xFEFF,  // Arabic Presentation Forms-B
        0,
    };
    return ranges;
}

// --- ARABIC SHAPING ENGINE (LITE) ---
// This handles basic Arabic shaping (Initial, Medial, Final, Isolated) and BIDI reversal
// to ensure text appears connected and correct in game engines that don't support RTL.
static std::string ReshapeArabic(const char* text) {
    if (!text) return "";
    
    struct ArabicChar {
        uint32_t code;
        uint32_t isolated, initial, medial, final;
    };

    // Table of Arabic characters with their contextual forms (Unicode Presentation Forms-B)
    static const ArabicChar arabicTable[] = {
        {0x0621, 0xFE80, 0xFE80, 0xFE80, 0xFE80}, // Hamza
        {0x0622, 0xFE81, 0xFE81, 0xFE82, 0xFE82}, // Alef With Madda Above
        {0x0623, 0xFE83, 0xFE83, 0xFE84, 0xFE84}, // Alef With Hamza Above
        {0x0624, 0xFE85, 0xFE85, 0xFE86, 0xFE86}, // Waw With Hamza Above
        {0x0625, 0xFE87, 0xFE87, 0xFE88, 0xFE88}, // Alef With Hamza Below
        {0x0626, 0xFE89, 0xFE8B, 0xFE8C, 0xFE8A}, // Yeh With Hamza Above
        {0x0627, 0xFE8D, 0xFE8D, 0xFE8E, 0xFE8E}, // Alef
        {0x0628, 0xFE8F, 0xFE91, 0xFE92, 0xFE90}, // Beh
        {0x0629, 0xFE93, 0xFE93, 0xFE94, 0xFE94}, // Teh Marbuta
        {0x062A, 0xFE95, 0xFE97, 0xFE98, 0xFE96}, // Teh
        {0x062B, 0xFE99, 0xFE9B, 0xFE9C, 0xFE9A}, // Theh
        {0x062C, 0xFE9D, 0xFE9F, 0xFEA0, 0xFE9E}, // Jeem
        {0x062D, 0xFEA1, 0xFEA3, 0xFEA4, 0xFEA2}, // Hah
        {0x062E, 0xFEA5, 0xFEA7, 0xFEA8, 0xFEA6}, // Khah
        {0x062F, 0xFEA9, 0xFEA9, 0xFEAA, 0xFEAA}, // Dal
        {0x0630, 0xFEAB, 0xFEAB, 0xFEAC, 0xFEAC}, // Thal
        {0x0631, 0xFEAD, 0xFEAD, 0xFEAE, 0xFEAE}, // Reh
        {0x0632, 0xFEAF, 0xFEAF, 0xFEB0, 0xFEB0}, // Zain
        {0x0633, 0xFEB1, 0xFEB3, 0xFEB4, 0xFEB2}, // Seen
        {0x0634, 0xFEB5, 0xFEB7, 0xFEB8, 0xFEB6}, // Sheen
        {0x0635, 0xFEB9, 0xFEBB, 0xFEBC, 0xFEBA}, // Sad
        {0x0636, 0xFEBD, 0xFEBF, 0xFEC0, 0xFEBE}, // Dad
        {0x0637, 0xFEC1, 0xFEC3, 0xFEC4, 0xFEC2}, // Tah
        {0x0638, 0xFEC5, 0xFEC7, 0xFEC8, 0xFEC6}, // Zah
        {0x0639, 0xFEC9, 0xFECB, 0xFECC, 0xFECA}, // Ain
        {0x063A, 0xFECD, 0xFECF, 0xFED0, 0xFECE}, // Ghain
        {0x0641, 0xFED1, 0xFED3, 0xFED4, 0xFED2}, // Feh
        {0x0642, 0xFED5, 0xFED7, 0xFED8, 0xFED6}, // Qaf
        {0x0643, 0xFED9, 0xFEDB, 0xFEDC, 0xFEDA}, // Kaf
        {0x0644, 0xFEDD, 0xFEDF, 0xFEE0, 0xFEDE}, // Lam
        {0x0645, 0xFEE1, 0xFEE3, 0xFEE4, 0xFEE2}, // Meem
        {0x0646, 0xFEE5, 0xFEE7, 0xFEE8, 0xFEE6}, // Noon
        {0x0647, 0xFEE9, 0xFEEB, 0xFEEC, 0xFEEA}, // Heh
        {0x0648, 0xFEED, 0xFEED, 0xFEEE, 0xFEEE}, // Waw
        {0x0649, 0xFEEF, 0xFEEF, 0xFEF0, 0xFEF0}, // Alef Maksura
        {0x064A, 0xFEF1, 0xFEF3, 0xFEF4, 0xFEF2}, // Yeh
        {0x067E, 0xFB56, 0xFB58, 0xFB59, 0xFB57}, // Peh
        {0x0686, 0xFB7A, 0xFB7C, 0xFB7D, 0xFB7B}, // Tcheh
        {0x06A9, 0xFB8E, 0xFB90, 0xFB91, 0xFB8F}, // Keheh
        {0x06AF, 0xFB92, 0xFB94, 0xFB95, 0xFB93}, // Gaf
    };

    auto getChar = [](uint32_t c) -> const ArabicChar* {
        for (const auto& entry : arabicTable) {
            if (entry.code == c) return &entry;
        }
        return nullptr;
    };

    auto canConnectLeft = [&](uint32_t c) {
        const ArabicChar* entry = getChar(c);
        if (!entry) return false;
        // Characters that don't connect to the left (isolated/final only)
        return !(c == 0x0621 || c == 0x0622 || c == 0x0623 || c == 0x0624 || c == 0x0625 || c == 0x0627 || 
                 c == 0x062F || c == 0x0630 || c == 0x0631 || c == 0x0632 || c == 0x0648 || c == 0x0629);
    };

    auto canConnectRight = [&](uint32_t c) {
        return getChar(c) != nullptr;
    };

    // UTF-8 to UTF-32 (Simple)
    std::vector<uint32_t> utf32;
    const unsigned char* u = (const unsigned char*)text;
    while (*u) {
        if (*u < 0x80) utf32.push_back(*u++);
        else if ((*u & 0xE0) == 0xC0) { utf32.push_back(((*u & 0x1F) << 6) | (u[1] & 0x3F)); u += 2; }
        else if ((*u & 0xF0) == 0xE0) { utf32.push_back(((*u & 0x0F) << 12) | ((u[1] & 0x3F) << 6) | (u[2] & 0x3F)); u += 3; }
        else u++;
    }

    std::vector<uint32_t> shaped;
    for (size_t i = 0; i < utf32.size(); i++) {
        uint32_t current = utf32[i];
        const ArabicChar* entry = getChar(current);
        
        if (!entry) {
            shaped.push_back(current);
            continue;
        }

        bool prevConnects = (i > 0 && canConnectLeft(utf32[i-1]));
        bool nextConnects = (i < utf32.size() - 1 && canConnectRight(utf32[i+1]));

        if (prevConnects && nextConnects) shaped.push_back(entry->medial);
        else if (prevConnects) shaped.push_back(entry->final);
        else if (nextConnects) shaped.push_back(entry->initial);
        else shaped.push_back(entry->isolated);
    }

    // Reverse for RTL display in LTR engine
    std::reverse(shaped.begin(), shaped.end());

    // UTF-32 back to UTF-8
    std::string result;
    for (uint32_t c : shaped) {
        if (c < 0x80) result += (char)c;
        else if (c < 0x800) { result += (char)(0xC0 | (c >> 6)); result += (char)(0x80 | (c & 0x3F)); }
        else if (c < 0x10000) { result += (char)(0xE0 | (c >> 12)); result += (char)(0x80 | ((c >> 6) & 0x3F)); result += (char)(0x80 | (c & 0x3F)); }
    }
    return result;
}

// Detect whether a UTF-8 string already contains pre-shaped Arabic
// (Presentation Forms-A: U+FB50..U+FDFF or Forms-B: U+FE70..U+FEFF).
// If it does, we treat it as ready-to-render and skip ReshapeArabic.
static inline bool IsPreShapedArabic(const char* text) {
    if (!text) return false;
    const unsigned char* u = (const unsigned char*)text;
    while (*u) {
        uint32_t c = 0;
        if (*u < 0x80) { c = *u; u += 1; }
        else if ((*u & 0xE0) == 0xC0) { c = ((*u & 0x1F) << 6) | (u[1] & 0x3F); u += 2; }
        else if ((*u & 0xF0) == 0xE0) { c = ((*u & 0x0F) << 12) | ((u[1] & 0x3F) << 6) | (u[2] & 0x3F); u += 3; }
        else { u += 1; continue; }
        if ((c >= 0xFB50 && c <= 0xFDFF) || (c >= 0xFE70 && c <= 0xFEFF)) return true;
    }
    return false;
}

// Cached per-string Arabic translation to avoid leaking/rebuilding every frame.
static inline const char* L(const char* en, const char* ar) {
    if (persistent_int["iLang"] != 1) return en;
    if (!ar || !*ar) return en;

    // If the Arabic argument is already in Presentation Forms (pre-shaped &
    // pre-reversed), render it as-is. Otherwise reshape from base Arabic.
    static std::unordered_map<const char*, std::string> cache;
    auto it = cache.find(ar);
    if (it != cache.end()) return it->second.c_str();

    std::string out = IsPreShapedArabic(ar) ? std::string(ar) : ReshapeArabic(ar);
    auto ins = cache.emplace(ar, std::move(out));
    return ins.first->second.c_str();
}

static void CheckAppUpdate() {
    thread([]() {
        string url = "https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID + "/databases/(default)/documents/settings/global?key=" + FIREBASE_API_KEY;
        string response = HttpRequest(url, "GET");
        if (!response.empty()) {
            try {
                auto respJson = json::parse(response);
                if (respJson.contains("fields")) {
                    auto fields = respJson["fields"];
                    
                    bool forceUpdateVal = false;
                    if (fields.contains("force_update") && fields["force_update"].contains("booleanValue")) {
                        forceUpdateVal = fields["force_update"]["booleanValue"].get<bool>();
                    }

                    int requiredVersion = 1;
                    if (fields.contains("required_version") && fields["required_version"].contains("integerValue")) {
                        requiredVersion = std::stoi(fields["required_version"]["integerValue"].get<string>());
                    }

                    if (fields.contains("download_url") && fields["download_url"].contains("stringValue")) {
                        g_UpdateURL = fields["download_url"]["stringValue"].get<string>();
                    }

                    // Only require update if force_update is ON and the client version is older than required
                    g_UpdateRequired = forceUpdateVal && (CLIENT_VERSION < requiredVersion);
                }
            } catch (...) {
                // Ignore parse/network errors
            }
        }
    }).detach();
}

static float EaseOutBack(float x) {
    const float c1 = 1.70158f;
    const float c3 = c1 + 1.0f;
    return 1.0f + c3 * powf(x - 1.0f, 3.0f) + c1 * powf(x - 1.0f, 2.0f);
}

static float EaseOutQuart(float x) {
    return 1.0f - powf(1.0f - x, 4.0f);
}

static void DrawGradientRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImU32 col1, ImU32 col2, bool horizontal = true) {
    if (horizontal) {
        dl->AddRectFilledMultiColor(p1, p2, col1, col2, col2, col1);
    } else {
        dl->AddRectFilledMultiColor(p1, p2, col1, col1, col2, col2);
    }
}

static float AddDashedLine(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImU32 col, float thickness, float dash_len = 20.0f, float gap_len = 15.0f, float phase_offset = 0.0f) {
    ImVec2 dir = ImVec2(p2.x - p1.x, p2.y - p1.y);
    float dist = sqrtf(dir.x * dir.x + dir.y * dir.y);
    if (dist < 1.0f) return phase_offset;
    dir.x /= dist; dir.y /= dist;

    float cycle = dash_len + gap_len;
    float curr = -fmodf(phase_offset, cycle); // Start at correct phase offset
    if (curr > 0.0f) curr -= cycle;           // Ensure we start before beginning
    while (curr < dist) {
        float dashStart = curr;
        float dashEnd   = curr + dash_len;
        // Clamp to segment bounds
        float drawStart = ImMax(dashStart, 0.0f);
        float drawEnd   = ImMin(dashEnd,   dist);
        if (drawStart < drawEnd) {
            dl->AddLine(
                ImVec2(p1.x + dir.x * drawStart, p1.y + dir.y * drawStart),
                ImVec2(p1.x + dir.x * drawEnd,   p1.y + dir.y * drawEnd),
                col, thickness);
        }
        curr += cycle;
    }
    // Return how far we traveled so next segment continues the phase
    return fmodf(phase_offset + dist, cycle);
}


static bool SidebarButton(const char* label, const char* iconStr, bool selected, float width) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    // Keep all six navigation entries above the bottom close button.
    // The previous 65px icon/18px padding layout made the last entry overlap
    // the exit control on shorter screens.
    float iconSize   = 48.0f;
    float vPad       = 10.0f;
    float btnH       = vPad + iconSize + 4.0f + g.FontSize + vPad;

    ImVec2 pos  = window->DC.CursorPos;
    ImVec2 size = ImVec2(width, btnH);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);

    ImDrawList* dl = window->DrawList;

    // Icon center position
    ImVec2 iconCenter = ImVec2(
        bb.Min.x + width * 0.5f,
        bb.Min.y + vPad + iconSize * 0.5f
    );

    // Selected background/border circles have been removed as requested

    // Draw icon text centered: Orange when selected/unselected, highlighting when active
    if (iconStr && g_IconFont) {
        PushFont(g_IconFont);
        ImVec2 iconTextSize = CalcTextSize(iconStr);
        ImVec2 iconPos = ImVec2(
            iconCenter.x - iconTextSize.x * 0.5f,
            iconCenter.y - iconTextSize.y * 0.5f
        );
        
        ImU32 tint = selected ? IM_COL32(0, 150, 255, 255) : IM_COL32(0, 100, 200, 180);
        
        if (selected) {
            // Text bloom shadow
            dl->AddText(iconPos - ImVec2(1.0f, 0.0f), IM_COL32(0, 120, 255, 80), iconStr);
            dl->AddText(iconPos + ImVec2(1.0f, 0.0f), IM_COL32(0, 120, 255, 80), iconStr);
            dl->AddText(iconPos - ImVec2(0.0f, 1.0f), IM_COL32(0, 120, 255, 80), iconStr);
            dl->AddText(iconPos + ImVec2(0.0f, 1.0f), IM_COL32(0, 120, 255, 80), iconStr);
        }
        
        dl->AddText(iconPos, tint, iconStr);
        PopFont();
    }

    // Draw label centered below icon
    ImVec2 labelSize = CalcTextSize(label);
    ImVec2 textPos   = ImVec2(
        bb.Min.x + (width - labelSize.x) * 0.5f,
        bb.Min.y + vPad + iconSize + 4.0f
    );
    ImU32 textCol = selected ? IM_COL32(255, 255, 255, 255) : IM_COL32(140, 140, 150, 255);
    dl->AddText(textPos, textCol, label);

    return pressed;
}

static bool ToggleSwitch(const char* label, bool* v) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    float scale = 2.0f; // Increased to 2.0f for a bigger switch
    float height = 34.0f * scale; // Slightly thicker
    float width = 56.0f * scale;
    float radius = height * 0.5f;

    ImVec2 textSize = CalcTextSize(label);
    ImVec2 pos = window->DC.CursorPos;
    // Increased vertical padding (28.0f -> 40.0f) for more height
    ImVec2 size = ImVec2(GetContentRegionAvail().x, ImMax(height, textSize.y) + style.FramePadding.y * 2 + 40.0f);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    // Calculate toggle bounds early for interaction
    float sideMargin = 20.0f; 
    ImRect bgRect = bb;
    bgRect.Min.x += sideMargin;
    bgRect.Max.x -= sideMargin;
    float switchW = 76.0f * scale; // Slightly shorter width
    ImVec2 togglePos = ImVec2(bgRect.Max.x - switchW - 25.0f, bb.Min.y + (size.y - height) * 0.5f);
    ImVec2 toggleEnd = ImVec2(togglePos.x + switchW, togglePos.y + height);
    
    // The interactive area is strictly around the toggle switch pill
    ImRect toggleBb(ImVec2(togglePos.x - 15.0f, togglePos.y - 15.0f), ImVec2(toggleEnd.x + 15.0f, toggleEnd.y + 15.0f));

    bool hovered, held;
    bool pressed = ButtonBehavior(toggleBb, id, &hovered, &held);
    if (pressed) *v = !*v;

    static std::map<ImGuiID, float> switchAnim;
    float& animT = switchAnim[id];
    float targetT = *v ? 1.0f : 0.0f;
    animT += (targetT - animT) * g.IO.DeltaTime * 14.0f;

    ImDrawList* dl = window->DrawList;
    
    // Permanent Box Background (Segmented style) using new smaller bgRect
    dl->AddRectFilled(bgRect.Min, bgRect.Max, IM_COL32(32, 32, 38, 255), 15.0f);
    
    if (hovered) {
        dl->AddRectFilled(bgRect.Min, bgRect.Max, IM_COL32(50, 50, 60, 100), 15.0f); // Hover highlight
    }
    
    
    ImVec4 offColor = ImVec4(0.24f, 0.24f, 0.28f, 1.0f);
    ImVec4 onColor = ImVec4(0.0f, 0.5f, 1.0f, 1.0f);
    ImVec4 bgColorV = ImLerp(offColor, onColor, animT);
    dl->AddRectFilled(togglePos, toggleEnd, ImColor(bgColorV), radius);
    
    // --- ON/OFF Text Labels inside the track ---
    float innerTextScale = 0.85f;
    SetWindowFontScale(innerTextScale);
    
    if (*v) {
        // Center "ON" in the Left Half of the track (since knob is on the right)
        ImVec2 onSize = CalcTextSize("ON");
        ImVec2 onPos = ImVec2(togglePos.x + (switchW * 0.5f - onSize.x) * 0.5f + 5.0f, togglePos.y + (height - onSize.y) * 0.5f);
        dl->AddText(onPos, IM_COL32(255, 255, 255, 255), "ON");
    } else {
        // Center "OFF" in the Right Half of the track (since knob is on the left)
        ImVec2 offSize = CalcTextSize("OFF");
        ImVec2 offPos = ImVec2(togglePos.x + switchW * 0.5f + (switchW * 0.5f - offSize.x) * 0.5f - 5.0f, togglePos.y + (height - offSize.y) * 0.5f);
        dl->AddText(offPos, IM_COL32(220, 220, 230, 255), "OFF");
    }
    SetWindowFontScale(1.0f);
    
    float knobX = togglePos.x + radius + (switchW - height) * animT;
    float knobY = togglePos.y + radius;
    float knobR = radius - 6.0f; // Smaller knob, sits inside the track
    
    ImVec4 knobOffColor = ImVec4(0.05f, 0.05f, 0.05f, 1.0f); // almost black
    ImVec4 knobOnColor  = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);    // white
    ImVec4 knobColorV   = ImLerp(knobOffColor, knobOnColor, animT);
    
    dl->AddCircleFilled(ImVec2(knobX, knobY), knobR, ImColor(knobColorV));
    dl->AddCircleFilled(ImVec2(knobX, knobY), knobR, IM_COL32(0, 0, 0, 30)); // Subtle shadow

    // Align text further inside the bgRect (15.0f -> 25.0f)
    dl->AddText(ImVec2(bgRect.Min.x + 25.0f, bb.Min.y + (size.y - textSize.y) * 0.5f), IM_COL32(230, 230, 240, 255), label);

    return pressed;
}

static bool CustomSliderFloat(const char* label, float* v, float v_min, float v_max, const char* format = "%.2f") {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    float sliderHeight = 45.0f; // Height of the slider bar itself
    ImVec2 labelSize = CalcTextSize(label);
    
    ImVec2 pos = window->DC.CursorPos;
    // Taller height for the slider itself without the extra box padding
    ImVec2 size = ImVec2(GetContentRegionAvail().x, labelSize.y + sliderHeight + style.FramePadding.y * 2 + 25.0f);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    // Alignment Margins (Matching ToggleSwitch placement but without the box)
    float sideMargin = 20.0f; 
    float internalPadding = 25.0f;
    float totalSideOffset = sideMargin + internalPadding;
    float contentWidth = bb.GetWidth() - (totalSideOffset * 2.0f);

    // Calculate knob position early for interaction
    ImVec2 barPos = ImVec2(bb.Min.x + totalSideOffset, bb.Min.y + labelSize.y + 20.0f);
    float barRadius = sliderHeight * 0.5f;
    float grabPos = (*v - v_min) / (v_max - v_min) * contentWidth;
    ImVec2 knobPos = ImVec2(barPos.x + grabPos, barPos.y + barRadius);
    float hitRadius = ImMax(sliderHeight * 0.7f + 25.0f, 60.0f); // Large touch area strictly around the knob
    ImRect knobBb(ImVec2(knobPos.x - hitRadius, knobPos.y - hitRadius), ImVec2(knobPos.x + hitRadius, knobPos.y + hitRadius));

    bool hovered, held;
    bool pressed = ButtonBehavior(knobBb, id, &hovered, &held);

    if (held) {
        *v = CLAMP((g.IO.MousePos.x - (bb.Min.x + totalSideOffset)) / contentWidth * (v_max - v_min) + v_min, v_min, v_max);
    }

    ImDrawList* dl = window->DrawList;
    
    // Label (No background frame drawn here anymore)
    dl->AddText(ImVec2(bb.Min.x + totalSideOffset, bb.Min.y + 5.0f), IM_COL32(230, 230, 240, 255), label);
    
    // Value text
    char value_buf[32];
    if (strstr(label, "Percent") || strstr(label, "Transparency")) {
        snprintf(value_buf, sizeof(value_buf), "%d%%", (int)(*v * (strstr(label, "Transparency") ? 100.0f : 1.0f)));
    } else if (strstr(label, "Thickness") || strstr(label, "Size") || strstr(label, "Point")) {
        snprintf(value_buf, sizeof(value_buf), "%.1f", *v);
    } else {
        snprintf(value_buf, sizeof(value_buf), format, *v);
    }
    
    ImVec2 valSize = CalcTextSize(value_buf);
    dl->AddText(ImVec2(bb.Max.x - totalSideOffset - valSize.x, bb.Min.y + 5.0f), IM_COL32(0, 150, 255, 255), value_buf);

    // Slider Bar
    ImVec2 barEnd = ImVec2(barPos.x + contentWidth, barPos.y + sliderHeight);

    // Slider Background (This is the track, not the frame)
    dl->AddRectFilled(barPos, barEnd, IM_COL32(32, 32, 38, 255), barRadius);

    // Slider Fill
    if (grabPos > 0.0f) {
        dl->AddRectFilled(barPos, ImVec2(barPos.x + grabPos, barEnd.y), IM_COL32(0, 150, 255, 255), barRadius);
    }

    // Knob
    dl->AddCircleFilled(knobPos, 32.0f, IM_COL32(255, 255, 255, 255));
    dl->AddCircleFilled(knobPos, 32.0f, IM_COL32(0, 0, 0, 30)); 

    return held;
}

static bool CustomSliderInt(const char* label, int* v, int v_min, int v_max) {
    float f_val = (float)*v;
    if (CustomSliderFloat(label, &f_val, (float)v_min, (float)v_max, "%.0f")) {
        *v = (int)f_val;
        return true;
    }
    return false;
}

static bool SegmentedControl(const char* label, int* current, const std::vector<std::string>& options, float controlHeight = 110.0f) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    ImVec2 pos = window->DC.CursorPos;
    // Set size including vertical spacing
    ImVec2 size = ImVec2(GetContentRegionAvail().x, controlHeight + 20.0f);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    // Frame Style (Matches ToggleSwitch: 20f Margin, 15f Radius)
    float sideMargin = 20.0f;
    ImRect bgRect = bb;
    bgRect.Min.x += sideMargin;
    bgRect.Max.x -= sideMargin;

    ImDrawList* dl = window->DrawList;
    dl->AddRectFilled(bgRect.Min, bgRect.Max, IM_COL32(32, 32, 38, 255), 15.0f);

    // Internal Padding for the segments (25.0f matches Slider/Toggle)
    float internalPadding = 25.0f; 
    ImRect contentRect = bgRect;
    contentRect.Min += ImVec2(internalPadding, internalPadding);
    contentRect.Max -= ImVec2(internalPadding, internalPadding);

    float width = contentRect.Max.x - contentRect.Min.x;
    float height = contentRect.Max.y - contentRect.Min.y;
    int count = (int)options.size();
    float itemW = width / count;

    bool changed = false;
    for (int i = 0; i < count; i++) {
        ImVec2 itemMin = ImVec2(contentRect.Min.x + i * itemW, contentRect.Min.y);
        ImVec2 itemMax = ImVec2(itemMin.x + itemW, itemMin.y + height);
        ImRect itemBb(itemMin, itemMax);
        
        ImGuiID itemId = window->GetID((std::string(label) + std::to_string(i)).c_str());
        bool hovered, held;
        if (ButtonBehavior(itemBb, itemId, &hovered, &held)) {
            *current = i;
            changed = true;
        }

        if (*current == i) {
            dl->AddRectFilled(itemMin, itemMax, IM_COL32(0, 120, 255, 255), 12.0f);
        } else if (hovered) {
            dl->AddRectFilled(itemMin, itemMax, IM_COL32(50, 50, 60, 150), 12.0f);
        }

        ImVec2 ts = CalcTextSize(options[i].c_str());
        ImU32 textCol = (*current == i) ? IM_COL32(255, 255, 255, 255) : IM_COL32(160, 160, 170, 255);
        dl->AddText(ImVec2(itemMin.x + (itemW - ts.x) * 0.5f, itemMin.y + (height - ts.y) * 0.5f), textCol, options[i].c_str());
    }

    return changed;
}

static bool GlassSegmentedControl(const char* label, int* current, const std::vector<std::string>& options, float controlHeight = 100.0f) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = ImVec2(GetContentRegionAvail().x, controlHeight + 20.0f);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    float sideMargin = 20.0f;
    ImRect bgRect = bb;
    bgRect.Min.x += sideMargin;
    bgRect.Max.x -= sideMargin;

    ImDrawList* dl = window->DrawList;
    
    // Glass Background Effect
    dl->AddRectFilled(bgRect.Min, bgRect.Max, IM_COL32(45, 45, 55, 100), 12.0f);
    dl->AddRect(bgRect.Min, bgRect.Max, IM_COL32(255, 255, 255, 40), 12.0f, 0, 1.5f);

    float internalPadding = 18.0f; 
    ImRect contentRect = bgRect;
    contentRect.Min += ImVec2(internalPadding, internalPadding);
    contentRect.Max -= ImVec2(internalPadding, internalPadding);

    float width = contentRect.Max.x - contentRect.Min.x;
    float height = contentRect.Max.y - contentRect.Min.y;
    int count = (int)options.size();
    float itemW = width / count;

    // Smooth Animation for Selector
    static std::map<ImGuiID, float> selectorAnim;
    float& animX = selectorAnim[id];
    float targetX = (float)(*current) * itemW;
    animX += (targetX - animX) * g.IO.DeltaTime * 15.0f;

    // Glowing Selector
    ImVec2 selMin = ImVec2(contentRect.Min.x + animX, contentRect.Min.y);
    ImVec2 selMax = ImVec2(selMin.x + itemW, contentRect.Max.y);
    dl->AddRectFilled(selMin, selMax, IM_COL32(0, 120, 255, 180), 10.0f);
    dl->AddRect(selMin, selMax, IM_COL32(255, 255, 255, 80), 10.0f, 0, 1.0f);

    bool changed = false;
    for (int i = 0; i < count; i++) {
        ImVec2 itemMin = ImVec2(contentRect.Min.x + i * itemW, contentRect.Min.y);
        ImVec2 itemMax = ImVec2(itemMin.x + itemW, itemMin.y + height);
        ImRect itemBb(itemMin, itemMax);
        
        ImGuiID itemId = window->GetID((std::string(label) + std::to_string(i)).c_str());
        bool hovered, held;
        if (ButtonBehavior(itemBb, itemId, &hovered, &held)) {
            *current = i;
            changed = true;
        }

        ImVec2 ts = CalcTextSize(options[i].c_str());
        ImU32 textCol = (*current == i) ? IM_COL32(255, 255, 255, 255) : IM_COL32(160, 160, 170, 255);
        dl->AddText(ImVec2(itemMin.x + (itemW - ts.x) * 0.5f, itemMin.y + (height - ts.y) * 0.5f), textCol, options[i].c_str());
    }

    return changed;
}

// Compact two-row style picker used by the line-effects page. The preview
// tiles mirror the eight visual presets shown in the Effects design.
static bool EffectsStyleGrid(const char* label, int* current, const std::vector<std::string>& options) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems || options.empty()) return false;
    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(label);
    const float gap = 10.0f;
    const float tileH = 72.0f;
    const float width = GetContentRegionAvail().x;
    const float tileW = (width - gap) * 0.5f;
    const ImVec2 origin = GetCursorScreenPos();
    ItemSize(ImVec2(width, tileH * 4.0f + gap * 3.0f), g.Style.FramePadding.y);
    bool changed = false;
    static std::map<ImGuiID, float> hoverAnim;
    for (int i = 0; i < (int)options.size(); ++i) {
        const int row = i / 2;
        const int col = i % 2;
        ImVec2 p = origin + ImVec2(col * (tileW + gap), row * (tileH + gap));
        ImRect bb(p, p + ImVec2(tileW, tileH));
        ImGuiID itemId = window->GetID((std::string(label) + std::to_string(i)).c_str());
        bool hovered = false, held = false;
        if (ButtonBehavior(bb, itemId, &hovered, &held)) {
            *current = i;
            changed = true;
        }
        float& anim = hoverAnim[itemId];
        anim += ((hovered ? 1.0f : 0.0f) - anim) * g.IO.DeltaTime * 12.0f;
        ImU32 body = (*current == i) ? IM_COL32(0, 105, 180, 210) : IM_COL32(12, 22, 38, 220);
        if (held) body = IM_COL32(0, 145, 220, 230);
        window->DrawList->AddRectFilled(bb.Min, bb.Max, body, 14.0f);
        window->DrawList->AddRect(bb.Min, bb.Max,
            (*current == i) ? IM_COL32(80, 220, 255, 230) : IM_COL32(90, 125, 165, (int)(100 + 80 * anim)),
            14.0f, 0, (*current == i) ? 2.0f : 1.0f);
        // Small animated preview stroke inside each tile.
        ImVec2 a = p + ImVec2(18, 22), b = p + ImVec2(tileW - 18, 22);
        ImU32 preview[8] = { IM_COL32(180, 190, 205, 220), IM_COL32(80, 210, 255, 220),
            IM_COL32(255, 220, 90, 230), IM_COL32(190, 120, 255, 230), IM_COL32(40, 240, 255, 240),
            IM_COL32(255, 80, 100, 240), IM_COL32(255, 70, 210, 240), IM_COL32(255, 170, 70, 240) };
        if (i == 3) AddDashedLine(window->DrawList, a, b, preview[i], 2.2f, 10.0f, 8.0f, 0.0f);
        else window->DrawList->AddLine(a, b, preview[i], i == 0 ? 1.5f : 2.5f);
        window->DrawList->AddCircleFilled(b, 5.0f + 2.0f * anim, preview[i]);
        ImVec2 ts = CalcTextSize(options[i].c_str());
        window->DrawList->AddText(ImVec2(p.x + (tileW - ts.x) * 0.5f, p.y + 42.0f),
            (*current == i) ? IM_COL32(255, 255, 255, 255) : IM_COL32(205, 215, 230, 255), options[i].c_str());
    }
    return changed;
}

// File-scope so DrawToggleButton cancel can also reset countdown
static bool g_aqCounting = false;
static std::chrono::steady_clock::time_point g_aqLastCall;
static std::chrono::steady_clock::time_point g_aqCountdownStart;


static bool IsExpired() {
    return (int64_t)time(nullptr) >= G_EXPIRY_TS;
}

// Helper to update Android Window Flags for touch transparency
static void UpdateOverlayFlags(bool touchable) {
    JNIEnv* env = GetJNIEnv();
    if (!env) return;
    
    // This is a common JNI pattern to update flags on the fly
    // We target the current window and toggle FLAG_NOT_TOUCHABLE (0x10)
    static jclass viewClass = env->FindClass("android/view/View");
    static jclass paramsClass = env->FindClass("android/view/WindowManager$LayoutParams");
    
    // In a real implementation, we would need the specific View object of the overlay.
    // For now, we ensure ImGui's own internal touch handling is bypassed when closed.
    ImGuiIO& io = ImGui::GetIO();
    if (!touchable) {
        io.ConfigFlags |= ImGuiConfigFlags_NoMouse;
        io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
    } else {
        io.ConfigFlags &= ~ImGuiConfigFlags_NoMouse;
        io.ConfigFlags &= ~ImGuiConfigFlags_NoMouseCursorChange;
    }
}

INLINE void DrawExpired(ImGuiIO& io) {
    float winW = g_menu.sidebarW;

    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    SetNextWindowSize(ImVec2(winW, 0), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(21, 21, 21, 255));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 20.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(30.0f, 30.0f));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (Begin(O("##ExpiredWin"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
              ImGuiWindowFlags_AlwaysAutoResize)) {

        SetWindowFontScale(1.6f);
        ImVec2 titleSz = CalcTextSize(L("MOD EXPIRED", "انتهت صلاحية المود"));
        SetCursorPosX((winW - 60.0f - titleSz.x) * 0.5f);
        TextColored(ImVec4(1.0f, 0.1f, 0.1f, 1.0f), "%s", L("MOD EXPIRED", "انتهت صلاحية المود"));
        SetWindowFontScale(1.0f);

        Dummy(ImVec2(0, 16));

        PushTextWrapPos(GetCursorPosX() + winW - 60.0f);
        TextColored(ImVec4(0.85f, 0.85f, 0.90f, 1.0f), "%s",
            L("Key Expired. Buy on our Telegram @TIGER_GYMAR", "انتهت صلاحية المفتاح. للشراء عبر تيليجرام @TIGER_GYMAR"));
        PopTextWrapPos();

        Dummy(ImVec2(0, 10));
    }
    End();
    PopStyleVar(3);
    PopStyleColor();
}

INLINE void DrawAutoQueue() {
    if (((g_AuthToken ^ 0xDEADBEEFCAFEBABE) == g_ExpiryTime && g_ExpiryTime > 0) || (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) || DEBUG_BYPASS_LOGIN) {
        auto now = std::chrono::steady_clock::now();

        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqLastCall).count() > 500)
            g_aqCounting = false;
        g_aqLastCall = now;

        if (!g_aqCounting) {
            g_aqCounting = true;
            g_aqCountdownStart = now;
        }

        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqCountdownStart).count();
        int remaining_ms = 8000 - (int)elapsed;

        if (remaining_ms <= 0) {
            if (sharedMenuManager.getMenuStateId() == 13) PopMenuState(13);
            StartLastMatch();
            g_aqCounting = false;
            return;
        }

        std::string count_str = std::to_string((remaining_ms / 1000) + 1);

        // Minimal auto-sized window, transparent bg — we draw our own rounded rect
        SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        SetNextWindowSizeConstraints(ImVec2(350.0f, -1.0f), ImVec2(450.0f, -1.0f)); // Fixed width range
        PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0.92f));
        PushStyleColor(ImGuiCol_Border, ImVec4(1.0f, 0.47f, 0.0f, 0.8f)); // Dark Orange Border
        PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(25.0f, 20.0f));
        PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
        PushStyleVar(ImGuiStyleVar_WindowBorderSize, 3.5f);

        if (Begin(O("##AutoQueueCD"), nullptr,
                  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                  ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
                  ImGuiWindowFlags_AlwaysAutoResize)) {
            
            ImDrawList* dl = GetWindowDrawList();
            ImVec2 ws = GetWindowSize();
            
            // 1. Stylish Header - Centered
            SetWindowFontScale(0.9f);
            float hTextWidth = CalcTextSize(L("AUTO QUEUE ACTIVE", "الدخول التلقائي مفعّل")).x;
            SetCursorPosX((ws.x - hTextWidth) * 0.5f);
            TextColored(ImVec4(0.7f, 0.7f, 0.75f, 1.0f), L("AUTO QUEUE ACTIVE", "الدخول التلقائي مفعّل"));
            Separator();
            Dummy(ImVec2(0, 5));

            // 2. Large Countdown Digit
            SetWindowFontScale(2.5f);
            ImVec2 ts = CalcTextSize(count_str.c_str());
            SetCursorPosX((ws.x - ts.x) * 0.5f);
            TextColored(ImVec4(1.0f, 0.47f, 0.0f, 1.0f), "%s", count_str.c_str());
            SetWindowFontScale(1.0f);
            
            Dummy(ImVec2(0, 8));

            // 3. Stylish Terminate Button
            float btnW = ws.x - 30.0f; // Increased width (closer to edges)
            float btnH = 55.0f; // Slightly taller for better touch
            SetCursorPosX(15.0f);
            
            PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.1f, 0.1f, 1.0f));
            PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.2f, 0.2f, 1.0f));
            PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.0f, 0.0f, 1.0f));
            PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
            SetWindowFontScale(0.9f);
            
            if (Button(L("TERMINATE", "إيقاف"), ImVec2(btnW, btnH))) {
                persistent_bool[O("bAutoQueue")] = false;
                g_aqCounting = false;
            }
            
            SetWindowFontScale(1.0f);
            PopStyleVar();
            PopStyleColor(3);
        }
        End();
        PopStyleVar(3);
        PopStyleColor(2);
    }
}

#include "mod/ButtonClicker.h"

static ImU32 GetBallColor32(int i, float lineAlpha, bool isScanning) {
    static const ImU32 ballColors[] = {
        IM_COL32(255, 255, 255, 255), // 0: White
        IM_COL32(254, 228, 0,   255), // 1: Yellow
        IM_COL32(0,   89,  179, 255), // 2: Blue
        IM_COL32(216, 0,   0,   255), // 3: Red
        IM_COL32(102, 0,   153, 255), // 4: Purple
        IM_COL32(0, 127, 255, 255), // 5: Orange
        IM_COL32(0,   143, 0,   255), // 6: Green
        IM_COL32(128, 0,   0,   255), // 7: Maroon
        IM_COL32(20,  20,  20,  255), // 8: Black (Slightly light for visibility)
        IM_COL32(254, 228, 0,   255), // 9: Yellow (S)
        IM_COL32(0,   89,  179, 255), // 10: Blue (S)
        IM_COL32(216, 0,   0,   255), // 11: Red (S)
        IM_COL32(102, 0,   153, 255), // 12: Purple (S)
        IM_COL32(0, 127, 255, 255), // 13: Orange (S)
        IM_COL32(0,   143, 0,   255), // 14: Green (S)
        IM_COL32(128, 0,   0,   255)  // 15: Maroon (S)
    };

    ImU32 baseCol = ballColors[i % 16];
    ImColor col = ImColor(baseCol);

    if (persistent_int[O("iLineStyle")] == 2 && persistent_int.count(O("iColorMode"))) {
        int mode = persistent_int[O("iColorMode")];
        if (mode == 1 && i != 0) { // Bright Mode
            float h, s, v;
            ImGui::ColorConvertRGBtoHSV(col.Value.x, col.Value.y, col.Value.z, h, s, v);
            if (v > 0.1f) {
                if (s > 0.1f) s = ImMin(s * 1.5f, 1.0f); // Boost saturation
                v = ImMin(v * 1.5f, 1.0f); // Boost brightness
            }
            ImGui::ColorConvertHSVtoRGB(h, s, v, col.Value.x, col.Value.y, col.Value.z);
        } else if (mode == 2 && i != 0) { // Cyberpunk Mode
            static const ImU32 cyberpunkColors[16] = {
                IM_COL32(255, 255, 255, 255), // 0: White (Cue)
                IM_COL32(0, 255, 255, 255), // 1: Neon Yellow
                IM_COL32(0,   255, 255, 255), // 2: Electric Cyan (Blue)
                IM_COL32(255, 30,  30,  255), // 3: Neon Red (Red)
                IM_COL32(138, 43,  226, 255), // 4: Blue Violet (Purple)
                IM_COL32(0, 100, 255, 255), // 5: Neon Orange
                IM_COL32(57,  255, 20,  255), // 6: Neon Lime (Green)
                IM_COL32(160, 10,  10,  255), // 7: Dark Neon Maroon (Maroon)
                IM_COL32(110, 110, 110, 255), // 8: Cyber Grey (Black)
                IM_COL32(0, 255, 255, 255), // 9: Neon Yellow
                IM_COL32(0,   255, 255, 255), // 10: Electric Cyan
                IM_COL32(255, 30,  30,  255), // 11: Neon Red
                IM_COL32(138, 43,  226, 255), // 12: Blue Violet
                IM_COL32(0, 100, 255, 255), // 13: Neon Orange
                IM_COL32(57,  255, 20,  255), // 14: Neon Lime
                IM_COL32(160, 10,  10,  255)  // 15: Dark Neon Maroon
            };
            col = ImColor(cyberpunkColors[i % 16]);
        }
    }

    // Balls 5 and 13 must use a stable visible orange route color.
    // Keep this override after the selected color mode so neither Vivid nor
    // Cyberpunk can change its path color.
    if (i == 5 || i == 13) {
        col = ImColor(255, 127, 0, 255);
    }

    col.Value.w = (isScanning || persistent_bool[O("bESP_ShowBallNumbers")]) ? 1.0f : lineAlpha;
    
    if (i == 0) {
        col = ImColor(255, 255, 255); // Always White for Cue Ball
        col.Value.w = (isScanning || persistent_bool[O("bESP_ShowBallNumbers")]) ? 1.0f : lineAlpha;
    } else if (!isScanning && AutoPlay::g_CurrentCandidate.idx == i) {
        if (persistent_int[O("iLineStyle")] != 2) {
            col = ImColor(255, 215, 0); // Gold for Target when not scanning (unless Colors mode is on)
        }
        col.Value.w = 1.0f;
    }

    return (ImU32)col;
}

static float GetBallLineThickness(int i, bool isScanning) {
    float lineThick = (float)persistent_int[O("iLineThickness")];
    // Give the visual line a small readability boost without making it heavy.
    lineThick += 0.5f;
    if (isScanning && lineThick < 2.0f) lineThick = 2.0f; // Bolder lines during scan
    else if (lineThick < 1.0f) lineThick = 1.0f;
    
    if (i == 0) {
        if (isScanning) lineThick += 1.0f;
    } else if (!isScanning && AutoPlay::g_CurrentCandidate.idx == i) {
        lineThick += 1.0f;
    }
    return lineThick;
}

INLINE void DrawESP(ImDrawList* draw) {
    if (((g_AuthToken ^ 0xDEADBEEFCAFEBABE) == g_ExpiryTime && g_ExpiryTime > 0) || DEBUG_BYPASS_LOGIN) {
        // Native objects can be replaced for a few frames during match
        // transitions. Do not enter prediction/render code with partial data.
        if (!draw || !sharedGameManager || !gPrediction) return;
        UpdateScreenTable();
if (!g_Vault.is_loaded) {
    // Manual initialization with REAL offsets (matching sec_data)
    g_Vault.v[4] = 0x4f06288 ^ XOR_KEY;   // Director
    g_Vault.v[0] = 0x4e9feb8 ^ XOR_KEY;   // UserInfo
    g_Vault.v[7] = 0x4dde3e0 ^ XOR_KEY;   // MainManager
    g_Vault.v[2] = 0x4dfe838 ^ XOR_KEY;   // MenuManager
    g_Vault.v[5] = 0x2d911e0 ^ XOR_KEY;   // VisualCue
    g_Vault.v[3] = 0x3068c94 ^ XOR_KEY;   // StartMatch
    g_Vault.v[9] = 0x0294879d ^ XOR_KEY;  // Line2
    g_Vault.v[1] = 0x02948795 ^ XOR_KEY;  // Zero
    g_Vault.v[6] = 0x029487a5 ^ XOR_KEY;  // Small
    g_Vault.is_loaded = true;
}

        sharedDirector = F(ptr, libmain + (g_Vault.v[4] ^ XOR_KEY));
        if (!sharedDirector) return;
        sharedUserInfo = F(ptr, libmain + (g_Vault.v[0] ^ XOR_KEY));
        if (!sharedUserInfo) return;
        F(bool, sharedUserInfo + 0x340) = true;
        sharedMainManager = F(ptr, libmain + (g_Vault.v[7] ^ XOR_KEY));
        if (!sharedMainManager) return;

        sharedMenuManager = F(ptr, libmain + (g_Vault.v[2] ^ XOR_KEY));
        if (!sharedMenuManager) return;

        MainStateManager mainStateManager = sharedMainManager.mStateManager;
        if (!mainStateManager) return;
        if (!mainStateManager.isInGame()) {
        if (persistent_bool[O("bAutoQueue")]) {
            if (!sharedMenuManager.isInQueue()) DrawAutoQueue();
        } return;
        }

        auto visualCue = sharedGameManager.mVisualCue();

        Ball::Classification myclass = sharedGameManager.getPlayerClassification();

        Table table = sharedGameManager.mTable;
        if (!table) return;

        auto tableProperties = table.mTableProperties();
        if (!tableProperties) return;

        auto& pockets = tableProperties.mPockets();

        // A zero count is normal before the first prediction of a new frame.
        // Let determineShotResult populate guiData; only reject corrupt counts.
        const int safeBallsCount = gPrediction->guiData.ballsCount;
        if (safeBallsCount < 0 || safeBallsCount > MAX_BALLS_COUNT) return;



        GameStateManager gameStateManager = sharedGameManager.mStateManager;
        if (!gameStateManager) return;

        AutoPlay::Update();

        auto stateId = gameStateManager.getCurrentStateId();
        if (stateId == 4 && (AutoPlay::currentMode == AutoPlay::MODE_OFF || AutoPlay::state != AutoPlay::SCANNING)) {
            if (AutoPlay::bCueBallIsMovingOrDragging) {
                // Skip simulation while dragging cue ball
            } else if (AutoPlay::state == AutoPlay::NOMINATING || AutoPlay::state == AutoPlay::NOMINATING_HUMAN) {
                // While nominating, force the intended shot line
                gPrediction->determineShotResult(false, AutoPlay::pendingShotAngle, AutoPlay::pendingShotPower, sharedGameManager.getShotSpin(), AutoPlay::g_CurrentCandidate);
            } else if (AutoPlay::g_PredictionLocked && AutoPlay::g_CurrentCandidate.idx != -1) {
                // BOLT LOCK: Keep lines on final shot - don't follow joystick!
                gPrediction->determineShotResult(false, AutoPlay::targetAngle, AutoPlay::pendingShotPower, sharedGameManager.getShotSpin(), AutoPlay::g_CurrentCandidate);
            } else {
                // Normal aim mode - use current cue position
                gPrediction->determineShotResult(false, sharedGameManager.mVisualCue().getShotAngle(), sharedGameManager.mVisualCue().getShotPower(), sharedGameManager.getShotSpin(), AutoPlay::g_CurrentCandidate);
            }
        }
        if (stateId == 6 || stateId == 7 || stateId == 8) return;

        {
            float pocketSize = persistent_float[O("fESP_PocketSize")];
            for (int i = 0; i < 6; i++) {
                if (Prediction::pocketStatus[i]) {
                    auto screenPos = WorldToScreen(pockets[i]);
                    draw->AddCircle(ImVec2(screenPos.x, screenPos.y), pocketSize, IM_COL32(0, 255, 100, 255), 0, 5.0f);
                } else if (persistent_bool[O("bESP_DrawPockets")]) {
                    auto screenPos = WorldToScreen(pockets[i]);
                    draw->AddCircle(ImVec2(screenPos.x, screenPos.y), pocketSize, IM_COL32(0, 180, 255, 255), 0, 3.0f);
                }
            }
        }

        bool showLines = persistent_bool[O("bESP_DrawPredictionLine")];
        if (showLines && !persistent_bool[O("bPredictionAfterShot")]) {
            if (AutoPlay::AreBallsMoving() || !gameStateManager.isPlayerTurn()) {
                showLines = false;
            }
        }

        if (showLines) {
            float lineAlpha = persistent_float[O("fESP_LineAlpha")];
            float ballSize = persistent_float[O("fESP_BallSize")];
            const bool fillFinalGap = persistent_bool.count(O("bESP_FillFinalGap")) &&
                                      persistent_bool[O("bESP_FillFinalGap")];
            // Keep the start marker slightly visible even with older saved
            // profiles that still contain the previous very-small value.
            float startPointSize = ImMax(6.0f, persistent_float[O("fESP_StartPointSize")]);
            bool isScanning = AutoPlay::currentMode != AutoPlay::MODE_OFF && AutoPlay::state == AutoPlay::SCANNING;
            const bool lineVisualEffects = persistent_bool[O("bESP_LineVisualEffects")] && !isScanning && draw != nullptr;
            const float effectTime = (float)AutoPlay::nowSec();
            int effectStyle = persistent_int.count(O("iLineEffectStyle")) ? persistent_int[O("iLineEffectStyle")] : 0;
            int effectColorSet = persistent_int.count(O("iLineEffectColors")) ? persistent_int[O("iLineEffectColors")] : 0;
            float effectDensity = persistent_float.count(O("fLineEffectDensity")) ? persistent_float[O("fLineEffectDensity")] : 55.0f;
            float effectSpeed = persistent_float.count(O("fLineEffectSpeed")) ? persistent_float[O("fLineEffectSpeed")] : 1.0f;
            float effectSize = persistent_float.count(O("fLineEffectSize")) ? persistent_float[O("fLineEffectSize")] : 1.0f;
            if (effectStyle < 0 || effectStyle > 7) effectStyle = 0;
            if (effectColorSet < 0 || effectColorSet > 3) effectColorSet = 0;
            if (!(effectDensity >= 10.0f && effectDensity <= 100.0f)) effectDensity = 55.0f;
            if (!(effectSpeed >= 0.2f && effectSpeed <= 2.5f)) effectSpeed = 1.0f;
            if (!(effectSize >= 0.5f && effectSize <= 2.0f)) effectSize = 1.0f;
            int effectSegmentsDrawn = 0;

            // Lightweight moving particles: only three small circles per
            // visible segment, with a deterministic color per ball/route.
            auto DrawLineVisualEffects = [&](ImVec2 a, ImVec2 b, int seed) {
                if (!lineVisualEffects || effectStyle == 0 || effectSegmentsDrawn++ >= 96) return;
                static const ImU32 effectColors[4][6] = {
                    { IM_COL32(0, 220, 255, 210), IM_COL32(255, 80, 190, 210), IM_COL32(255, 190, 40, 210), IM_COL32(100, 255, 130, 210), IM_COL32(170, 100, 255, 210), IM_COL32(255, 90, 70, 210) },
                    { IM_COL32(0, 255, 255, 220), IM_COL32(255, 0, 180, 220), IM_COL32(130, 255, 0, 220), IM_COL32(255, 30, 30, 220), IM_COL32(120, 40, 255, 220), IM_COL32(255, 255, 0, 220) },
                    { IM_COL32(255, 90, 35, 210), IM_COL32(255, 160, 40, 210), IM_COL32(255, 220, 80, 210), IM_COL32(240, 70, 40, 210), IM_COL32(255, 120, 20, 210), IM_COL32(255, 200, 50, 210) },
                    { IM_COL32(40, 150, 255, 210), IM_COL32(80, 240, 255, 210), IM_COL32(90, 100, 255, 210), IM_COL32(60, 255, 200, 210), IM_COL32(130, 80, 255, 210), IM_COL32(40, 220, 190, 210) }
                };
                const float dx = b.x - a.x;
                const float dy = b.y - a.y;
                const float length = sqrtf(dx * dx + dy * dy);
                if (!(length >= 12.0f) || !std::isfinite(length)) return;
                const float invLength = 1.0f / length;
                const int colorIndex = (seed < 0 ? -seed : seed) % 6;
                const int colorSet = effectColorSet < 0 ? 0 : (effectColorSet > 3 ? 3 : effectColorSet);
                const ImU32 fxColor = effectColors[colorSet][colorIndex];
                const int particleCount = (effectStyle == 2 || effectStyle == 6) ? 6 :
                                          ((effectStyle == 5 || effectStyle == 7) ? 4 : 3);
                const int visibleParticles = ImMax(1, (int)ceilf(particleCount * effectDensity / 100.0f));
                for (int particle = 0; particle < visibleParticles; ++particle) {
                    float phase = fmodf(effectTime * effectSpeed * (0.22f + particle * 0.035f) +
                                       seed * 0.173f + particle * 0.31f, 1.0f);
                    if (phase < 0.0f) phase += 1.0f;
                    ImVec2 p(a.x + dx * phase, a.y + dy * phase);
                    float pulse = 0.65f + 0.35f * sinf(effectTime * effectSpeed * 5.0f + particle + seed);
                    float fade = (effectStyle == 1) ? (0.25f + 0.75f * phase) : 1.0f;
                    int alpha = (int)((effectStyle == 1 ? 85.0f : (effectStyle == 5 ? 110.0f : 75.0f)) * pulse * fade);
                    float radius = (effectStyle == 2 ? 2.2f :
                                   (effectStyle == 5 ? 3.2f : (effectStyle == 7 ? 6.0f : 4.5f))) * effectSize;
                    if (effectStyle == 6) {
                        const int rainbowIndex = (colorIndex + particle + (int)(effectTime * effectSpeed * 2.0f)) % 6;
                        draw->AddCircleFilled(p, radius + pulse * 1.8f, effectColors[1][rainbowIndex]);
                        continue;
                    }
                    draw->AddCircleFilled(p, radius + pulse * (effectStyle == 1 ? 2.5f : 2.0f),
                                          (fxColor & IM_COL32(255, 255, 255, 0)) | ((ImU32)alpha << IM_COL32_A_SHIFT));
                    if (effectStyle == 5 || effectStyle == 7) {
                        draw->AddCircle(p, radius + 2.0f + pulse * 2.0f, fxColor, 0, 1.4f);
                    } else {
                        draw->AddCircleFilled(ImVec2(p.x - dy * invLength * 3.0f,
                                                      p.y + dx * invLength * 3.0f),
                                              (effectStyle == 2 ? 1.2f : 1.6f) * effectSize + pulse,
                                              fxColor);
                    }
                }
            };

            // Auto-play supplies its selected candidate. In manual play there is no
            // candidate, so use the first ball the current prediction will hit.
            int targetBallIdx = AutoPlay::g_CurrentCandidate.idx;
            if (targetBallIdx < 0 || targetBallIdx >= gPrediction->guiData.ballsCount) {
                if (gPrediction->guiData.collision.firstHitBall) {
                    targetBallIdx = gPrediction->guiData.collision.firstHitBall->index;
                }
            }

            // Pass 1: Draw base solid colored lines for all balls
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                if (isScanning && !AutoPlay::bShowAutoPlayLines) break;

                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    ImU32 col32 = GetBallColor32(i, lineAlpha, isScanning);
                    float lineThick = GetBallLineThickness(i, isScanning);
                    bool isCyberpunk = (persistent_int[O("iLineStyle")] == 2 &&
                                        persistent_int.count(O("iColorMode")) &&
                                        persistent_int[O("iColorMode")] == 2);

                    // Helper: draw one line segment with the selected effect.
                    auto DrawSegment = [&](ImVec2 a, ImVec2 b) {
                        if (lineVisualEffects && effectStyle == 3) {
                            AddDashedLine(draw, a, b, col32, lineThick, 13.0f, 9.0f, 0.0f);
                        } else if (lineVisualEffects && (effectStyle == 4 || effectStyle == 5)) {
                            ImVec4 c = ImGui::ColorConvertU32ToFloat4(col32);
                            float glowScale = effectStyle == 5 ? 4.0f : 2.8f;
                            draw->AddLine(a, b, IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 28), lineThick * glowScale);
                            draw->AddLine(a, b, IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 70), lineThick * 1.8f);
                            draw->AddLine(a, b, col32, lineThick);
                        } else if (isCyberpunk) {
                            ImVec4 c = ImGui::ColorConvertU32ToFloat4(col32);
                            ImU32 glow1 = IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 30);
                            ImU32 glow2 = IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 65);
                            draw->AddLine(a, b, glow1, lineThick * 2.5f); // Thin outer glow
                            draw->AddLine(a, b, glow2, lineThick * 1.5f); // Mid glow
                            draw->AddLine(a, b, col32, lineThick);         // Sharp core
                        } else {
                            draw->AddLine(a, b, col32, lineThick);
                        }
                    };

                    // Helper: fill the crack at a corner joint
                    auto FixJointCrack = [&](ImVec2 p) {
                        if (isCyberpunk) {
                            ImVec4 c = ImGui::ColorConvertU32ToFloat4(col32);
                            ImU32 glow1 = IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 30);
                            ImU32 glow2 = IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 65);
                            draw->AddCircleFilled(p, lineThick * 2.5f * 0.5f, glow1);
                            draw->AddCircleFilled(p, lineThick * 1.5f * 0.5f, glow2);
                            draw->AddCircleFilled(p, lineThick * 0.5f, col32);
                        } else {
                            draw->AddCircleFilled(p, lineThick * 0.5f, col32);
                        }
                    };

                    ImVec2 curPos = WorldToScreen(ball.initialPosition);

                    if (ball.positions.size() > 1) {
                        ImVec2 prevDir = {0.0f, 0.0f};
                        for (size_t pi = 1; pi < ball.positions.size(); pi++) {
                            const auto& wp = ball.positions[pi];
                            if (wp == ball.initialPosition && pi == 1) continue; 
                            ImVec2 nextPos = WorldToScreen(wp);
                            float dx = nextPos.x - curPos.x, dy = nextPos.y - curPos.y;
                            float lenSq = dx*dx + dy*dy;
                            if (lenSq >= 2.25f) {
                                DrawSegment(curPos, nextPos);
                                DrawLineVisualEffects(curPos, nextPos, i * 17 + (int)pi);

                                // Compute current direction
                                float len = sqrtf(lenSq);
                                ImVec2 curDir = {dx / len, dy / len};

                                // Check if direction changed
                                if (prevDir.x != 0.0f || prevDir.y != 0.0f) {
                                    float dotProd = prevDir.x * curDir.x + prevDir.y * curDir.y;
                                    if (dotProd < 0.999f) { // Direction changed (corner)
                                        FixJointCrack(curPos); // Fill the crack exactly at the corner
                                    }
                                    
                                    // Draw user's bounce marker if enabled
                                    if (persistent_bool[O("bESP_BounceMarkers")] && dotProd < 0.96f) {
                                        draw->AddCircleFilled(curPos, 10.0f, col32);
                                    }
                                }

                                prevDir = curDir;
                                curPos = nextPos;
                            }
                        }
                    }

                    // Final segment from last waypoint to predictedPosition.
                    // Make only this stopping segment slightly thicker so the
                    // endpoint is clearly visible without thickening the route.
                    ImVec2 endPos = WorldToScreen(ball.predictedPosition);
                    if (curPos.x != endPos.x || curPos.y != endPos.y) {
                        const float endpointScale = 1.00f;
                        if (lineVisualEffects && effectStyle == 3) {
                            AddDashedLine(draw, curPos, endPos, col32, lineThick, 13.0f, 9.0f, 0.0f);
                        } else if (lineVisualEffects && (effectStyle == 4 || effectStyle == 5)) {
                            ImVec4 c = ImGui::ColorConvertU32ToFloat4(col32);
                            float glowScale = effectStyle == 5 ? 4.0f : 2.8f;
                            draw->AddLine(curPos, endPos, IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 28), lineThick * glowScale);
                            draw->AddLine(curPos, endPos, IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 70), lineThick * 1.8f);
                            draw->AddLine(curPos, endPos, col32, lineThick);
                        } else if (isCyberpunk) {
                            ImVec4 c = ImGui::ColorConvertU32ToFloat4(col32);
                            ImU32 glow1 = IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 30);
                            ImU32 glow2 = IM_COL32((int)(c.x*255), (int)(c.y*255), (int)(c.z*255), 65);
                            draw->AddLine(curPos, endPos, glow1, lineThick * endpointScale * 2.5f);
                            draw->AddLine(curPos, endPos, glow2, lineThick * endpointScale * 1.5f);
                            draw->AddLine(curPos, endPos, col32, lineThick * endpointScale);
                        } else {
                            draw->AddLine(curPos, endPos, col32, lineThick * endpointScale);
                        }
                        DrawLineVisualEffects(curPos, endPos, i * 17 + 97);
                    }
                }
            }

            // Pass 2: Draw white/black dashed overlays for striped balls (9 to 15) on top of the solid lines
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                if (isScanning && !AutoPlay::bShowAutoPlayLines) break;

                auto& ball = gPrediction->guiData.balls[i];
                bool isDashed = (persistent_int[O("iLineStyle")] == 1) && (i >= 9 && i <= 15);

                if (isDashed && ball.initialPosition != ball.predictedPosition) {
                    bool isTargetGold = (!isScanning && AutoPlay::g_CurrentCandidate.idx == i && persistent_int[O("iLineStyle")] != 2);
                    ImU32 dashColor = isTargetGold ? IM_COL32(20, 20, 20, 255) : IM_COL32(255, 255, 255, 255);
                    float lineThick = GetBallLineThickness(i, isScanning);
                    // Ultra-thin thread look: White dash is roughly 45% of base thickness
                    float whiteThick = ImMax(1.0f, lineThick * 0.45f);

                    ImVec2 curPos = WorldToScreen(ball.initialPosition);
                    float dashPhase = 0.0f; // Carry phase across segments for continuous dashes

                    if (ball.positions.size() > 1) {
                        for (size_t pi = 1; pi < ball.positions.size(); pi++) {
                            const auto& wp = ball.positions[pi];
                            if (wp == ball.initialPosition && pi == 1) continue; 
                            ImVec2 nextPos = WorldToScreen(wp);
                            float dx = nextPos.x - curPos.x, dy = nextPos.y - curPos.y;
                            if (dx*dx + dy*dy >= 2.25f) { 
                                dashPhase = AddDashedLine(draw, curPos, nextPos, dashColor, whiteThick, 22.0f, 18.0f, dashPhase); 
                                curPos = nextPos;
                            }
                        }
                    }
                    // Final segment — continue phase, slightly thicker at the stop.
                    ImVec2 endPos = WorldToScreen(ball.predictedPosition);
                    if (curPos.x != endPos.x || curPos.y != endPos.y) {
                        // Make the final dashed segment visibly thicker at the end of the route.
                        constexpr float finalGapEdgeThickness = 5.0f;
                        AddDashedLine(draw, curPos, endPos, dashColor, finalGapEdgeThickness, 22.0f, 18.0f, dashPhase);
                    }
                }
            }

            // Pass 3: Draw anchor circles, stop circles, ball numbers, and target indicators on top of everything
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                if (isScanning && !AutoPlay::bShowAutoPlayLines) break;

                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    ImU32 col32 = GetBallColor32(i, lineAlpha, isScanning);
                    float lineThick = GetBallLineThickness(i, isScanning);
                    bool isDashed = (persistent_int[O("iLineStyle")] == 1) && (i >= 9 && i <= 15);
                    bool isTargetGold = (!isScanning && AutoPlay::g_CurrentCandidate.idx == i && persistent_int[O("iLineStyle")] != 2);
                    if (fillFinalGap) {
                        // Draw a short solid cap over the final dash gap so the
                        // route reaches the exact point where the ball stops.
                        ImVec2 endPos = WorldToScreen(ball.predictedPosition);
                        // Prediction appends predictedPosition as the final
                        // element, so use the waypoint immediately before it.
                        Point2D lastWorld = ball.initialPosition;
                        if (ball.positions.size() > 1) lastWorld = ball.positions[ball.positions.size() - 2];
                        ImVec2 lastPos = WorldToScreen(lastWorld);
                        float dx = endPos.x - lastPos.x, dy = endPos.y - lastPos.y;
                        float len = sqrtf(dx * dx + dy * dy);
                        if (len > 0.5f && std::isfinite(len)) {
                            // Fill the complete final segment, not only a short
                            // cap, so striped balls never retain a trailing gap.
                            const float capLength = len;
                            ImVec2 capStart(endPos.x - dx * (capLength / len), endPos.y - dy * (capLength / len));
                            ImU32 finalGapColor = isDashed ?
                                (isTargetGold ? IM_COL32(20, 20, 20, 255) : IM_COL32(255, 255, 255, 255)) : col32;
                            float gapThickness = persistent_float.count(O("fESP_FinalGapThickness")) ?
                                persistent_float[O("fESP_FinalGapThickness")] : lineThick;
                            if (!(gapThickness >= 1.0f && gapThickness <= 30.0f)) gapThickness = lineThick;
                            draw->AddLine(capStart, endPos, finalGapColor, gapThickness);
                        }
                    }
                    ImU32 dashColor = isTargetGold ? IM_COL32(20, 20, 20, 255) : IM_COL32(255, 255, 255, 255);

                    ImVec2 startPos = WorldToScreen(ball.initialPosition);
                    ImVec2 endPos = WorldToScreen(ball.predictedPosition);

                    // Start marker: show only for balls that actually enter a pocket.
                    // Keep it independent of ball color/style so it is always a thin red marker
                    // in both manual play and auto-play prediction views.
                    const bool entersPocket = (ball.pocketIndex >= 0 && ball.pocketIndex < 6 && !ball.onTable);
                    if (entersPocket) {
                        const float startPointStroke = 6.0f;
                        draw->AddCircle(startPos, startPointSize, IM_COL32(255, 45, 45, 255), 0, startPointStroke);
                    }
                    
                    // Predicted stop position (Filled for Solids/8-ball/Cue, Curved Dashed Hollow for Stripes)
                    if (i >= 9 && i <= 15) {
                        if (isDashed) {
                            // Draw alternating smooth curved dashes (4 colored and 4 white) along the circle boundary using PathArcTo
                            int num_dashes = 4;
                            float segment_angle = (2.0f * 3.14159265f) / (num_dashes * 2);
                            float circleThick = 6.0f; // Slightly stronger edge around the final stopped-ball marker
                            for (int j = 0; j < num_dashes * 2; j++) {
                                float start_a = j * segment_angle;
                                float end_a = (j + 1) * segment_angle;
                                
                                draw->PathClear();
                                draw->PathArcTo(endPos, ballSize, start_a, end_a, 12);
                                ImU32 segCol = (j % 2 == 0) ? col32 : dashColor; // Use dashColor here instead of pure white
                                draw->PathStroke(segCol, false, circleThick);
                            }
                        } else {
                            float ringThick = 6.0f;
                            draw->AddCircle(endPos, ballSize, col32, 0, ringThick);
                        }
                    } else {
                        bool isCyberpunkDot = (persistent_int[O("iLineStyle")] == 2 &&
                                               persistent_int.count(O("iColorMode")) &&
                                               persistent_int[O("iColorMode")] == 2);
                        if (isCyberpunkDot) {
                            ImVec4 c = ImGui::ColorConvertU32ToFloat4(col32);
                            ImU32 glowOut = IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255), 30);
                            ImU32 glowMid = IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255), 65);
                            draw->AddCircleFilled(endPos, ballSize * 1.25f, glowOut); // Outer glow even smaller
                            draw->AddCircleFilled(endPos, ballSize * 1.1f, glowMid);  // Mid glow even smaller
                            draw->AddCircle(endPos, ballSize + 0.5f, IM_COL32(255,255,255,150), 0, 1.0f); // Thinner white border
                            draw->AddCircleFilled(endPos, ballSize, col32);           // Core dot
                        } else {
                            draw->AddCircleFilled(endPos, ballSize, col32);
                        }
                    }
                    if (persistent_bool[O("bESP_ShowBallNumbers")]) {
                        draw->AddCircle(endPos, ballSize, IM_COL32(0, 0, 0, 255), 0, 1.5f);
                    }

                    // Target highlight is independent from Start Point Size.
                    // It is a fixed red marker at the target ball's original position.
                    if (persistent_bool[O("bESP_HighlightTargetBall")] &&
                        targetBallIdx == i && !entersPocket) {
                        const float targetHighlightRadius = 7.0f;
                        const float targetHighlightStroke = 4.00f;
                        draw->AddCircle(startPos, targetHighlightRadius,
                                        IM_COL32(255, 45, 45, 255), 0,
                                        targetHighlightStroke);
                    }

                    // Ball Number Overlays
                    if (persistent_bool[O("bESP_ShowBallNumbers")] && i > 0) {
                        char buf[8];
                        sprintf(buf, "%d", i);
                        
                        // Draw a solid white circle slightly smaller than the predicted ball
                        float innerCircleRadius = ballSize * 0.65f;
                        draw->AddCircleFilled(endPos, innerCircleRadius, IM_COL32(255, 255, 255, 255));
                        
                        // Scale down font size slightly
                        ImFont* font = ImGui::GetFont();
                        float fontSize = ImGui::GetFontSize() * 0.75f;
                        
                        // Center the text based on scaled font
                        ImVec2 txtSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, buf);
                        ImVec2 txtPos = endPos - (txtSize * 0.5f);
                        
                        // Text is always black inside the white circle
                        draw->AddText(font, fontSize, txtPos, IM_COL32(0, 0, 0, 255), buf);
                    }
                }
            }

            // --- 3. Pocket Pulse Indicator (no duplicate cue→target line: Section 2 already draws the full bounce path) ---
            if (AutoPlay::g_CurrentCandidate.idx != -1 && !isScanning) {
                ImVec2 pocketScreenPos = GetPocketScreenPos(AutoPlay::g_CurrentCandidate.pocketIndex);
                // Animated pulse ring on the target pocket
                float pulse = 5.0f + sin(AutoPlay::nowSec() * 10.0f) * 3.0f;
                draw->AddCircle(pocketScreenPos, pulse, IM_COL32(0, 215, 255, 255), 0, 2.0f);
                draw->AddCircle(pocketScreenPos, ballSize * 1.8f, IM_COL32(0, 255, 255, 180), 0, 1.5f);
            }
        }
    }
}

static constexpr float kMenuNavWidth = 125.0f;

static void DrawSidebar(float windowW, float windowH) {
    ImGuiContext& g = *GImGui;
    ImDrawList* dl = GetWindowDrawList();
    ImVec2 wp = GetWindowPos();
    const float navX = windowW - kMenuNavWidth;
    const float closeSize = 35.0f;

    // Right-side vertical navigation rail, matching the compact side menu style.
    dl->AddRectFilled(
        ImVec2(wp.x + navX, wp.y),
        ImVec2(wp.x + windowW, wp.y + windowH),
        IM_COL32(15, 17, 24, 245), 18.0f);
    dl->AddLine(
        ImVec2(wp.x + navX, wp.y + 18.0f),
        ImVec2(wp.x + navX, wp.y + windowH - 18.0f),
        IM_COL32(60, 70, 90, 190), 1.5f);

    SetCursorPos(ImVec2(navX, 12.0f));
    BeginGroup();
    if (SidebarButton(O("Draw"),  "\uF4D7", g_menu.currentTab == 0, kMenuNavWidth)) g_menu.currentTab = 0;
    if (SidebarButton(O("Play"),  "\uF544", g_menu.currentTab == 1, kMenuNavWidth)) g_menu.currentTab = 1;
    if (SidebarButton(O("Queue"), "\uF1DA", g_menu.currentTab == 2, kMenuNavWidth)) g_menu.currentTab = 2;
    if (SidebarButton(O("Extra"),  "\uF013", g_menu.currentTab == 3, kMenuNavWidth)) g_menu.currentTab = 3;
    if (SidebarButton(O("Info"),  "\uF05A", g_menu.currentTab == 4, kMenuNavWidth)) g_menu.currentTab = 4;
    if (SidebarButton(O("Effects"), "\uF0D0", g_menu.currentTab == 5, kMenuNavWidth)) g_menu.currentTab = 5;
    EndGroup();

    // Close button at the bottom of the same side rail.
    SetCursorPos(ImVec2(navX + (kMenuNavWidth - closeSize) * 0.5f,
                        windowH - closeSize - 18.0f));
    ImGuiWindow* win = GetCurrentWindow();
    ImGuiID closeId = win->GetID(O("##CloseMenu"));
    ImVec2 closePos = win->DC.CursorPos;
    ImRect closeBb(closePos, closePos + ImVec2(closeSize, closeSize));
    ItemSize(ImVec2(closeSize, closeSize), g.Style.FramePadding.y);
    ItemAdd(closeBb, closeId);
    bool closeHovered = false, closeHeld = false;
    bool closePressed = ButtonBehavior(closeBb, closeId, &closeHovered, &closeHeld);
    if (closePressed) g_menu.isOpen = false;

    float xCX = closeBb.Min.x + closeSize * 0.5f;
    float xCY = closeBb.Min.y + closeSize * 0.5f;
    float xH = closeSize * 0.32f;
    ImU32 xCol = closeHovered ? IM_COL32(255, 255, 255, 240)
                              : IM_COL32(160, 160, 170, 200);
    dl->AddLine(ImVec2(xCX - xH, xCY - xH), ImVec2(xCX + xH, xCY + xH), xCol, 2.2f);
    dl->AddLine(ImVec2(xCX + xH, xCY - xH), ImVec2(xCX - xH, xCY + xH), xCol, 2.2f);

    // Reset the cursor so DrawContentArea starts at the left edge of the window.
    SetCursorPos(ImVec2(0.0f, 0.0f));
}

// Reads an IL2CPP/Unity NSString (UTF-16 internal buffer at offset 0x14, length at 0x10)
static std::string ReadNSString(ptr str) {
    if (!str) return "null";
    int32_t len = F(int32_t, str + 0x10);
    if (len <= 0 || len > 512) return "?";
    std::string result;
    result.reserve(len);
    for (int32_t i = 0; i < len; i++) {
        uint16_t ch = F(uint16_t, str + 0x14 + i * 2);
        result += (ch > 0 && ch < 128) ? (char)ch : '?';
    }
    return result;
}

// Shared vertical position for DrawToggleButton and DrawFloatingButton (they move together)
static float g_sideBtnsY      = 0.0f;
// Kept for linker compatibility — no longer used for animation
static float g_toggleRotAngle = 0.0f;
// Set true by AutoPlay when in SLOW scan state — shows CALCULATING overlay
static bool  g_autoPlayCalculating = false;

// ── svConfig ──────────────────────────────────────────────────────────────────
// ── svConfig ──────────────────────────────────────────────────────────────────
static void svConfig_Save() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    FILE* f = fopen(path.c_str(), O("w"));
    if (!f) return;
    
    fprintf(f, O("iLang=%d\n"), persistent_int["iLang"]);
    fprintf(f, O("iLineThickness=%d\n"),  persistent_int[O("iLineThickness")]);
    fprintf(f, O("iMenuSizeOffset=%d\n"), persistent_int[O("iMenuSizeOffset")]);
    fprintf(f, O("iPowerBarSide=%d\n"),   persistent_int[O("iPowerBarSide")]);
    fprintf(f, O("fPowerBarXPercent=%f\n"),      persistent_float[O("fPowerBarXPercent")]);
    fprintf(f, O("fPowerBarYStartPercent=%f\n"), persistent_float[O("fPowerBarYStartPercent")]);
    fprintf(f, O("fPowerBarYEndPercent=%f\n"),   persistent_float[O("fPowerBarYEndPercent")]);
    fclose(f);
}

static void svConfig_Load() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    
    persistent_int["iLang"] = 0;
    persistent_int[O("iPowerBarSide")] = 0;
    persistent_float[O("fPowerBarXPercent")] = 0.058f;
    persistent_float[O("fPowerBarYStartPercent")] = 0.32f;
    persistent_float[O("fPowerBarYEndPercent")] = 0.78f;
    
    FILE* f = fopen(path.c_str(), O("r"));
    if (!f) return;
    
    char line[64];
    while (fgets(line, sizeof(line), f)) {
        int v = 0;
        float fv = 0.0f;
        
        if (sscanf(line, O("iLang=%d"), &v) == 1) { persistent_int["iLang"] = v; continue; }
        if (sscanf(line, O("iLineThickness=%d"),  &v) == 1) { persistent_int[O("iLineThickness")] = v; continue; }
        if (sscanf(line, O("iMenuSizeOffset=%d"), &v) == 1) { persistent_int[O("iMenuSizeOffset")] = v; continue; }
        if (sscanf(line, O("iPowerBarSide=%d"),   &v) == 1) { persistent_int[O("iPowerBarSide")] = v; continue; }
        if (sscanf(line, O("fPowerBarXPercent=%f"),      &fv) == 1) { persistent_float[O("fPowerBarXPercent")] = fv; continue; }
        if (sscanf(line, O("fPowerBarYStartPercent=%f"), &fv) == 1) { persistent_float[O("fPowerBarYStartPercent")] = fv; continue; }
        if (sscanf(line, O("fPowerBarYEndPercent=%f"),    &fv) == 1) { persistent_float[O("fPowerBarYEndPercent")] = fv; continue; }
    }
    fclose(f);
}
// ── BREAK PREDICTION ─────────────────────────────────────────────────────────
struct BreakPredictionData {
    bool valid = false;
    bool rackReady = false;
    bool breakFinished = false;
    int stateId = -1;
    int onTableCount = 0;
    float youPercent = 50.0f;
    float certainty = 0.0f;
};

static BreakPredictionData GetBreakPrediction() {
    BreakPredictionData result;
    if (!sharedGameManager || !gPrediction) return result;

    int onTableCount = 0;
    Table table = sharedGameManager.mTable;
    if (table) {
        auto& balls = table.mBalls();
        if (balls) {
            for (int i = 0; i < balls.Count; ++i) {
                if (balls[i].isOnTable()) ++onTableCount;
            }
        }
    }

    static int previousOnTableCount = -1;
    static int previousStateId = -1;
    static bool wasInGame = false;
    static ptr previousTableIdentity = 0;
    static int previousSelectedTable = -999;
    static bool rackObserved = false;
    static bool breakFinished = false;
    const int selectedTable = persistent_int.count(O("iAutoQueue_FixTable"))
                            ? persistent_int[O("iAutoQueue_FixTable")] : -1;
    const bool inGame = sharedMainManager && sharedMainManager.mStateManager &&
                        sharedMainManager.mStateManager().isInGame();
    const ptr tableIdentity = table ? table.instance : 0;
    // Reset all cached break state whenever the preview table/card changes.
    // Without this, the first rack could permanently control later previews.
    if (tableIdentity != previousTableIdentity || selectedTable != previousSelectedTable ||
        inGame != wasInGame) {
        previousTableIdentity = tableIdentity;
        wasInGame = inGame;
        previousSelectedTable = selectedTable;
        previousOnTableCount = -1;
        previousStateId = -1;
        rackObserved = false;
        breakFinished = false;
    }
    const bool fullRack = onTableCount >= 14;
    const int currentStateId = sharedGameManager.mStateManager().getCurrentStateId();
    const bool newRack = fullRack && (previousOnTableCount < 0 || previousOnTableCount <= 3);

    if (newRack) {
        rackObserved = true;
        breakFinished = false;
    } else if (rackObserved && previousOnTableCount >= 14 && onTableCount < 14) {
        breakFinished = true;
    } else if (rackObserved && fullRack && currentStateId == 6) {
        // State 6 is the rolling/transition state in this client. This catches
        // a legal dry break where the rack count remains unchanged.
        breakFinished = true;
    } else if (rackObserved && fullRack &&
               (currentStateId == 7 || currentStateId == 8) &&
               (previousStateId == 4 || previousStateId == 5)) {
        // Also handle a fast transition directly from our turn to the opponent.
        breakFinished = true;
    }
    previousOnTableCount = onTableCount;
    previousStateId = currentStateId;

    result.valid = true;
    // In the lobby there is no real break yet. Always present a fresh preview
    // for the currently selected table/card instead of showing the first game's
    // completed state forever.
    if (!inGame) {
        result.rackReady = true;
        result.breakFinished = false;
    } else {
        result.rackReady = rackObserved && !breakFinished && fullRack;
        result.breakFinished = breakFinished;
    }
    result.onTableCount = onTableCount;
    result.stateId = currentStateId;

    // State 4/5 means our side is the active side; 7/8 means the opponent.
    // Combine that reliable state signal with rack completeness so an overlay
    // shown during transitions does not claim false certainty.
    float stateYouProbability = 0.5f;
    bool stateKnown = false;
    if (result.stateId == 4 || result.stateId == 5) {
        stateYouProbability = 0.92f;
        stateKnown = true;
    } else if (result.stateId == 7 || result.stateId == 8) {
        stateYouProbability = 0.08f;
        stateKnown = true;
    }

    float evidence = 0.0f;
    if (stateKnown) evidence += 0.72f;
    if (fullRack) evidence += 0.23f;
    if (onTableCount >= 14) evidence += 0.05f;
    if (evidence > 1.0f) evidence = 1.0f;

    result.youPercent = 50.0f + (stateYouProbability - 0.5f) * 2.0f * evidence * 50.0f;
    if (result.youPercent < 1.0f) result.youPercent = 1.0f;
    if (result.youPercent > 99.0f) result.youPercent = 99.0f;
    // Recalculate a live aim-quality component every frame. The rack center
    // is estimated from the current object-ball positions, so moving the cue
    // changes the displayed percentage instead of leaving a fixed 92/8 value.
    if (sharedGameManager.mVisualCue() && sharedGameManager.mVisualCue().mVisualGuide()) {
        Point2D rackCenter = {0.0, 0.0};
        int rackBalls = 0;
        for (int i = 1; i < gPrediction->guiData.ballsCount; ++i) {
            const auto& ball = gPrediction->guiData.balls[i];
            if (!ball.originalOnTable) continue;
            rackCenter.x += ball.initialPosition.x;
            rackCenter.y += ball.initialPosition.y;
            ++rackBalls;
        }
        if (rackBalls > 0 && gPrediction->guiData.ballsCount > 0) {
            rackCenter.x /= rackBalls;
            rackCenter.y /= rackBalls;
            const Point2D cuePos = gPrediction->guiData.balls[0].initialPosition;
            const double desiredAngle = atan2(rackCenter.y - cuePos.y, rackCenter.x - cuePos.x);
            const double currentAngle = sharedGameManager.mVisualCue().getShotAngle();
            double angleDelta = currentAngle - desiredAngle;
            while (angleDelta > M_PI) angleDelta -= 2.0 * M_PI;
            while (angleDelta < -M_PI) angleDelta += 2.0 * M_PI;
            const float angleQuality = 1.0f - ImClamp((float)(std::fabs(angleDelta) / M_PI), 0.0f, 1.0f);
            const float power = (float)sharedGameManager.mVisualCue().getShotPower(true);
            const float powerQuality = ImClamp(power / 666.0f, 0.0f, 1.0f);
            const float aimQuality = ImClamp(angleQuality * 0.75f + powerQuality * 0.25f, 0.0f, 1.0f);

            // Keep ownership as the dominant signal, while allowing aim/power
            // movement to adjust the visible confidence by up to 15 points.
            const float ownerBase = stateKnown ? (stateYouProbability * 100.0f) : 50.0f;
            result.youPercent = ownerBase + (aimQuality - 0.5f) * 30.0f;
            result.youPercent = ImClamp(result.youPercent, 1.0f, 99.0f);
        }
    }
    result.certainty = std::fabs(result.youPercent - 50.0f) * 2.0f;
    return result;
}

static void DrawBreakPrediction(ImGuiIO& io) {
    if (!persistent_bool[O("bBreakPrediction")]) return;

    // Show the preview before entering a table, not over the active match.
    // This lets the player compare the current table/card before pressing Join.
    if (!sharedMainManager) return;
    MainStateManager mainStateManager = sharedMainManager.mStateManager;
    if (!mainStateManager || mainStateManager.isInGame()) return;

    BreakPredictionData data = GetBreakPrediction();
    if (!data.valid) return;

    float scale = ImClamp(io.DisplaySize.y / 1080.0f, 0.65f, 1.0f);
    float panelW = ImClamp(io.DisplaySize.x * 0.72f, 720.0f * scale, 1500.0f * scale);
    float panelH = data.breakFinished ? 92.0f * scale : 128.0f * scale;
    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y - 28.0f * scale), ImGuiCond_Always, ImVec2(0.5f, 1.0f));
    SetNextWindowSize(ImVec2(panelW, panelH), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(8, 18, 34, 235));
    PushStyleColor(ImGuiCol_Border, IM_COL32(0, 150, 255, 220));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 16.0f);
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.5f);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(18.0f * scale, 12.0f * scale));

    if (Begin(O("##BreakPrediction"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
              ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
              ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoSavedSettings)) {
        if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
        SetWindowFontScale(0.95f * scale);
        TextColored(ImVec4(0.35f, 0.78f, 1.0f, 1.0f), L("BREAK PREDICTION", "توقع الكسر"));
        SetWindowFontScale(1.0f);
        if (g_ArialBlackFont) PopFont();

        if (data.breakFinished) {
            TextColored(ImVec4(0.75f, 0.78f, 0.85f, 1.0f), L("Break already started", "تم تنفيذ ضربة الكسر"));
        } else if (!data.rackReady) {
            TextColored(ImVec4(0.75f, 0.78f, 0.85f, 1.0f), L("Waiting for a new rack", "في انتظار بداية راك جديدة"));
        } else {
            static float animatedPercent = 50.0f;
            animatedPercent += (data.youPercent - animatedPercent) * ImClamp(io.DeltaTime * 10.0f, 0.0f, 1.0f);
            float barW = GetContentRegionAvail().x;
            float barH = 18.0f * scale;
            ImVec2 barPos = GetCursorScreenPos();
            ImDrawList* draw = GetWindowDrawList();
            draw->AddRectFilled(barPos, barPos + ImVec2(barW, barH), IM_COL32(27, 42, 62, 255), barH * 0.5f);
            float fillW = barW * (animatedPercent / 100.0f);
            draw->AddRectFilled(barPos, barPos + ImVec2(fillW, barH), IM_COL32(0, 145, 255, 255), barH * 0.5f);
            draw->AddRect(barPos, barPos + ImVec2(barW, barH), IM_COL32(70, 190, 255, 190), barH * 0.5f, 0, 1.0f);
            Dummy(ImVec2(0, barH + 5.0f * scale));

            const char* who = animatedPercent >= 50.0f ? L("Break with you", "الكسر معاك") : L("Break with opponent", "الكسر مع الخصم");
            char label[128];
            snprintf(label, sizeof(label), "%s: %.0f%%", who, animatedPercent >= 50.0f ? animatedPercent : (100.0f - animatedPercent));
            TextColored(ImVec4(0.86f, 0.94f, 1.0f, 1.0f), "%s", label);
            char detail[128];
            snprintf(detail, sizeof(detail), "%s %.0f%%  |  %s %.0f%%",
                     L("You", "أنت"), animatedPercent,
                     L("Opponent", "الخصم"), 100.0f - animatedPercent);
            TextColored(ImVec4(0.58f, 0.68f, 0.80f, 1.0f), "%s", detail);
        }
    }
    End();
    PopStyleVar(3);
    PopStyleColor(2);
}

// ── CALCULATING overlay (shown during AutoPlay SLOW scan) ─────────────────────
static void DrawCalculating(ImGuiIO& io) {
    // Setăm poziția pe centrul ecranului (Width*0.5, Height*0.5)
    // Pivotul (0.5f, 0.5f) înseamnă că mijlocul ferestrei va fi fix pe coordonatele date
    SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    
    // Auto-resize face ca fereastra să aibă dimensiunea textului automat
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(21, 21, 21, 255));
    PushStyleColor(ImGuiCol_Border, IM_COL32(0, 120, 255, 255));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);

    if (Begin(O("##CalcOverlay"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | 
              ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | 
              ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs)) {
        
        SetWindowFontScale(1.4f);
        TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), L("CALCULATING...", "جاري الحساب..."));
        SetWindowFontScale(1.0f);
    }
    End();
    PopStyleVar(2);
    PopStyleColor(2);
}


static void DrawContentArea(float winW, float winH) {
    bool need_save = false;
    
    ImDrawList* dl  = GetWindowDrawList();
    ImVec2      wp  = GetWindowPos();

    // startY este punctul unde se termină bara de butoane (Sidebar)
    float startY   = GetCursorPosY();
    float contentW = winW;

    // Desenăm fundalul zonei de conținut sub sidebar
    dl->AddRectFilled(
        ImVec2(wp.x, wp.y + startY),
        ImVec2(wp.x + contentW, wp.y + winH),
        IM_COL32(21, 21, 21, 255), 20.0f
    );
    
    const char* tabTitles[] = {
        L("Draw Settings",  "إعدادات الرسم"),
        L("Auto Play",      "اللعب التلقائي"),
        L("Auto Queue",    "الدخول التلقائي"),
        L("Extra Settings","إعدادات إضافية"),
        L("Info",          "معلومات"),
        L("Effects",       "المؤثرات"),
    };

    // --- Premium VIP Header ───────────────────────────────────────────
    float headerH = 95.0f;
    {
        float avail = contentW;
        ImVec2 p = ImVec2(wp.x, wp.y + startY);
        ImDrawList* dl2 = GetWindowDrawList();
        
        int64_t now_ts = (int64_t)time(nullptr);
        int64_t diff = g_ExpiryTime - now_ts;
        if (diff < 0) diff = 0;

        int d = (int)(diff / 86400);
        int h = (int)((diff % 86400) / 3600);
        int m = (int)((diff % 3600) / 60);
        int s = (int)(diff % 60);

        // --- Left Side: Branding ---
        float paddingX = 22.0f;
        float textY = p.y + (headerH - (GetFontSize() * 2.2f)) * 0.5f;
        
        // Primary Text: "Lion X VIP" in Arial Black
        if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
        SetWindowFontScale(1.4f);
        ImVec2 textP = ImVec2(p.x + paddingX, textY);
        dl2->AddText(textP, IM_COL32(0, 120, 255, 255), L("TIGER Engine", "تايجر انجين"));
        SetWindowFontScale(1.0f);
        if (g_ArialBlackFont) PopFont();

        // Secondary Text: "Active" (Small Light Grey)
        dl2->AddText(ImVec2(p.x + paddingX, textY + GetFontSize() * 1.5f), IM_COL32(180, 180, 190, 255), L("Active", "مفعّل"));

        // --- Right Side: Boxed Timer with Colons ---
        auto DrawTimeBox = [&](int value, float& curX, bool drawColonBefore) {
            float boxW = 55.0f;
            float boxH = 50.0f;
            float boxPad = 14.0f; // Extra space to center the colon nicely
            
            curX -= boxW;
            ImVec2 boxP(curX, p.y + (headerH - boxH) * 0.5f);
            
            // Box Background
            dl2->AddRectFilled(boxP, boxP + ImVec2(boxW, boxH), IM_COL32(0, 127, 255, 255), 10.0f);
            
            // Value Text Centered (Restored to clear, prominent size)
            char buf[8];
            snprintf(buf, sizeof(buf), "%02d", value);
            if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
            SetWindowFontScale(1.05f); // Clear, legible, beautiful size
            ImVec2 ts = CalcTextSize(buf);
            dl2->AddText(ImVec2(boxP.x + (boxW - ts.x) * 0.5f, boxP.y + (boxH - ts.y) * 0.5f), IM_COL32(255, 255, 255, 255), buf);
            SetWindowFontScale(1.0f);
            if (g_ArialBlackFont) PopFont();
            
            if (drawColonBefore) {
                // Draw colon dots exactly in the center of the gap to the left
                float colonX = curX - (boxPad * 0.5f);
                ImVec2 center(colonX, p.y + headerH * 0.5f);
                dl2->AddCircleFilled(center - ImVec2(0, 5), 2.0f, IM_COL32(255, 255, 255, 160));
                dl2->AddCircleFilled(center + ImVec2(0, 5), 2.0f, IM_COL32(255, 255, 255, 160));
            }
            
            curX -= boxPad; // Apply gap
        };

        float rightX = p.x + avail - paddingX;
        DrawTimeBox(s, rightX, true);  // Colon between seconds and minutes
        DrawTimeBox(m, rightX, true);  // Colon between minutes and hours
        DrawTimeBox(h, rightX, true);  // Colon between hours and days
        DrawTimeBox(d, rightX, false); // Far left (days) - no colon to its left
    }

    SetCursorPos(ImVec2(10.0f, startY + headerH + 10.0f));
    
    // Începutul zonei de child (conținutul propriu-zis)
    PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));
    
    // --- Visible vertical navigation scrollbar ---
    PushStyleVar(ImGuiStyleVar_ScrollbarSize, 16.0f);
    PushStyleVar(ImGuiStyleVar_ScrollbarRounding, 12.0f);
    PushStyleColor(ImGuiCol_ScrollbarBg, IM_COL32(8, 12, 20, 180));
    PushStyleColor(ImGuiCol_ScrollbarGrab, IM_COL32(0, 125, 230, 220));
    PushStyleColor(ImGuiCol_ScrollbarGrabHovered, IM_COL32(0, 165, 255, 245));
    PushStyleColor(ImGuiCol_ScrollbarGrabActive, IM_COL32(0, 205, 255, 255));

    // Keep the child scrollable by touch, wheel, and the visible thumb.
    BeginChild(O("##ContentArea"), ImVec2(contentW - 20.0f, winH - startY - headerH - 10.0f), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);
    
    // --- God-Tier Smooth Touch Drag Scrolling ---
    {
        ImGuiIO& io = GetIO();
        static bool isScrollingActive = false;
        static bool isSliderDraggingActive = false;

        if (IsWindowHovered(ImGuiHoveredFlags_ChildWindows)) {
            if (io.MouseDown[0]) {
                if (!isScrollingActive && !isSliderDraggingActive) {
                    float dx = io.MousePos.x - io.MouseClickedPos[0].x;
                    float dy = io.MousePos.y - io.MouseClickedPos[0].y;
                    float distSqr = dx * dx + dy * dy;
                    if (distSqr > 36.0f) { // 6 pixels threshold
                        if (fabs(dy) > fabs(dx)) {
                            isScrollingActive = true;
                            ImGui::ClearActiveID();
                        } else {
                            isSliderDraggingActive = true;
                        }
                    }
                }
                
                if (isScrollingActive) {
                    float deltaY = io.MouseDelta.y;
                    if (deltaY != 0.0f) {
                        SetScrollY(GetScrollY() - deltaY);
                    }
                    ImGui::ClearActiveID();
                }
            } else {
                isScrollingActive = false;
                isSliderDraggingActive = false;
            }
        } else {
            if (!io.MouseDown[0]) {
                isScrollingActive = false;
                isSliderDraggingActive = false;
            }
        }
    }
    
    switch (g_menu.currentTab) {
  case 0: {
    Dummy(ImVec2(0, 10));
    need_save |= ToggleSwitch(L("Draw Lines", "ﻁﻮﻄﺨﻟﺍ ﻢﺳﺭ"), &persistent_bool[O("bESP_DrawPredictionLine")]); Dummy(ImVec2(0, 8));
    need_save |= ToggleSwitch(L("Draw Pockets", "ﺏﻮﻴﺠﻟﺍ ﻢﺳﺭ"), &persistent_bool[O("bESP_DrawPockets")]); Dummy(ImVec2(0, 8));
    need_save |= ToggleSwitch(L("Show Ball Numbers", "ﺕﺍﺮﻜﻟﺍ ﻡﺎﻗﺭﺃ ﺭﺎﻬﻇﺇ"), &persistent_bool[O("bESP_ShowBallNumbers")]); Dummy(ImVec2(0, 8));
    if (!persistent_bool.count(O("bESP_HighlightTargetBall"))) persistent_bool[O("bESP_HighlightTargetBall")] = true;
    need_save |= ToggleSwitch(L("Highlight Target Ball", "ﺔﻓﺪﻬﺘﺴﻤﻟﺍ ﺓﺮﻜﻟﺍ ﺰﻴﻴﻤﺗ"), &persistent_bool[O("bESP_HighlightTargetBall")]); Dummy(ImVec2(0, 8));
    need_save |= ToggleSwitch(L("Bounce Sync", "ﺩﺍﺪﺗﺭﻻﺍ ﺔﻧﺯﺍﻮﻣ"), &persistent_bool[O("bESP_BounceMarkers")]); Dummy(ImVec2(0, 8));
    if (!persistent_bool.count(O("bESP_FillFinalGap"))) persistent_bool[O("bESP_FillFinalGap")] = false;
    need_save |= ToggleSwitch(L("Remove Final Gap", "ﺔﻴﻬﻨﻟﺍ ﺓﻮﺠﻔﻟﺍ ﺔﻟﺍﺯﺇ"), &persistent_bool[O("bESP_FillFinalGap")]);
    
    Dummy(ImVec2(0, 15));
    {
        ImVec2 cp = GetCursorScreenPos();
        dl->AddLine(ImVec2(wp.x + 50.0f, cp.y), ImVec2(wp.x + contentW - 50.0f, cp.y), IM_COL32(0, 120, 255, 100), 1.0f);
    }
    Dummy(ImVec2(0, 15));
    
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.6f, 0.6f, 0.65f, 1.0f), L("LANGUAGE", "ﺔﻐﻠﻟﺍ"));
    if (g_ArialBlackFont) PopFont();
    
    Dummy(ImVec2(0, 8));
    
    if (!persistent_int.count(O("iLang"))) persistent_int[O("iLang")] = 0;
    
    std::vector<std::string> languages = { "English", "ﺔﻴﺑﺮﻌﻟﺍ" };
    need_save |= GlassSegmentedControl(O("##lang_select"), &persistent_int[O("iLang")], languages, 100.0f);
    
    Dummy(ImVec2(0, 15));
    {
        ImVec2 cp = GetCursorScreenPos();
        dl->AddLine(ImVec2(wp.x + 50.0f, cp.y), ImVec2(wp.x + contentW - 50.0f, cp.y), IM_COL32(0, 120, 255, 100), 1.0f);
    }
    Dummy(ImVec2(0, 15));
    
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("Line Style", "ﻂﺨﻟﺍ ﻂﻤﻧ"));
    if (g_ArialBlackFont) PopFont();
    if (!persistent_int.count(O("iLineStyle"))) persistent_int[O("iLineStyle")] = 0;
    need_save |= GlassSegmentedControl(O("##line_style"), &persistent_int[O("iLineStyle")], { L("Solid", "ﻞﺼﺘﻣ"), L("Stripe", "ﻊﻃﺎﻘﺘﻣ"), L("Colors", "ﻥﻮﻠﻣ") });
    
    if (persistent_int[O("iLineStyle")] == 2) {
        Dummy(ImVec2(0, 5));
        SetCursorPosX(45.0f);
        if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
        TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("Color Mode", "ﻥﺍﻮﻟﻷﺍ ﻂﻤﻧ"));
        if (g_ArialBlackFont) PopFont();
        if (!persistent_int.count(O("iColorMode"))) persistent_int[O("iColorMode")] = 0;
        
        need_save |= GlassSegmentedControl(O("##color_mode"), &persistent_int[O("iColorMode")], { L("Default", "ﻲﺿﺍﺮﺘﻓﺍ"), L("Vivid", "ﻲﻫﺍﺯ"), L("Chroma", "ﻲﻣﻭﺮﻛ") });
    }

    Dummy(ImVec2(0, 5));
    if (!persistent_int.count(O("iLineThickness"))) persistent_int[O("iLineThickness")] = 5;
    need_save |= CustomSliderInt(L("Line Thickness", "ﻂﺨﻟﺍ ﻚﻤﺳ"), &persistent_int[O("iLineThickness")], 1, 15);
    if (!persistent_float.count(O("fESP_FinalGapThickness"))) persistent_float[O("fESP_FinalGapThickness")] = 6.0f;
    need_save |= CustomSliderFloat(L("Final Gap Thickness", "ﺔﻴﻬﻨﻟﺍ ﺓﻮﺠﻔﻟﺍ ﻚﻤﺳ"), &persistent_float[O("fESP_FinalGapThickness")], 1.0f, 20.0f, "%.1f");
    need_save |= CustomSliderFloat(L("Line Transparency", "ﻂﺨﻟﺍ ﺔﻴﻓﺎﻔﺷ"), &persistent_float[O("fESP_LineAlpha")], 0.1f, 1.0f);
    need_save |= CustomSliderFloat(L("Pocket Size", "ﺐﻴﺠﻟﺍ ﻢﺠﺣ"), &persistent_float[O("fESP_PocketSize")], 10.0f, 100.0f);
    need_save |= CustomSliderFloat(L("Ball Predicted Size", "ﺔﻋﻮﻗﻮﺘﻤﻟﺍ ﺓﺮﻜﻟﺍ ﻢﺠﺣ"), &persistent_float[O("fESP_BallSize")], 5.0f, 40.0f);
    if (!persistent_float.count(O("fESP_StartPointSize"))) persistent_float[O("fESP_StartPointSize")] = 6.0f;
    need_save |= CustomSliderFloat(L("Start Point Size", "ﺔﻳﺍﺪﺒﻟﺍ ﺔﻄﻘﻧ ﻢﺠﺣ"), &persistent_float[O("fESP_StartPointSize")], 2.0f, 40.0f);
    need_save |= CustomSliderInt(L("Fix Menu Size", "ﺔﻤﺋﺎﻘﻟﺍ ﻢﺠﺣ ﻞﻳﺪﻌﺗ"), &persistent_int[O("iMenuSizeOffset")], -10, 10);

    Dummy(ImVec2(0, 20));
    {
        float btnH = 80.0f;
        float sideMargin = contentW * 0.15f;
        float avail = (contentW - 20.0f) - (sideMargin * 2.0f);
        ImVec2 p = GetCursorScreenPos();
        p.x += sideMargin;
        ImVec2 size = ImVec2(avail, btnH);
        
        ImGuiID id = GetID(O("SaveBtn_Premium"));
        bool hovered, held;
        bool pressed = ButtonBehavior(ImRect(p, p + size), id, &hovered, &held);
        
        static std::map<ImGuiID, float> btnAnim;
        if (btnAnim.find(id) == btnAnim.end()) btnAnim[id] = 0.0f;
        btnAnim[id] = ImLerp(btnAnim[id], hovered ? 1.0f : 0.0f, GetIO().DeltaTime * 8.0f);
        float anim = btnAnim[id];

        ImDrawList* dl2 = GetWindowDrawList();
        
        ImU32 shadowCol = IM_COL32(255, 120, 0, (int)(40 * anim));
        float rounding = 25.0f;
        for(int i=1; i<=8; i++) 
            dl2->AddRect(p - ImVec2(i,i), p + size + ImVec2(i,i), IM_COL32(255, 100, 0, (int)((20-i*2)*anim)), rounding + i, 0, 1.0f);

        ImU32 colBody = hovered ? IM_COL32(0, 130, 255, 255) : IM_COL32(0, 110, 255, 255);
        if (held) colBody = IM_COL32(180, 70, 0, 255);
        dl2->AddRectFilled(p, p + size, colBody, rounding);

        dl2->AddLine(p + ImVec2(30, 2), p + ImVec2(size.x - 30, 2), IM_COL32(255, 255, 255, 90), 1.5f);

        float iconSize = 30.0f;
        float spacing = 15.0f;
        ImVec2 ts = CalcTextSize(L("SAVE CHANGES", "ﺕﺍﺮﻴﻴﻐﺘﻟﺍ ﻆﻔﺣ"));
        float totalW = iconSize + spacing + ts.x;
        ImVec2 contentStart = ImVec2(p.x + (avail - totalW) * 0.5f, p.y + (btnH - iconSize) * 0.5f);

        ImVec2 iP = contentStart;
        dl2->AddRectFilled(iP, iP + ImVec2(iconSize, iconSize), IM_COL32(255, 255, 255, 220), 4.0f);
        dl2->AddRectFilled(iP + ImVec2(6, 2), iP + ImVec2(iconSize - 6, 12), IM_COL32(40, 40, 50, 255), 2.0f);
        dl2->AddRectFilled(iP + ImVec2(8, 18), iP + ImVec2(iconSize - 8, iconSize - 2), IM_COL32(60, 60, 70, 255), 1.0f);
        dl2->AddRect(iP, iP + ImVec2(iconSize, iconSize), IM_COL32(0, 0, 0, 40), 4.0f);

        dl2->AddText(ImVec2(contentStart.x + iconSize + spacing, p.y + (btnH - ts.y) * 0.5f), IM_COL32(255, 255, 255, 255), L("SAVE CHANGES", "ﺕﺍﺮﻴﻴﻐﺘﻟﺍ ﻆﻔﺣ"));
        
        if (pressed) {
            svConfig_Save();
        }
        Dummy(size);
        Dummy(ImVec2(0, 10));
    }
    break;
}

case 1: {
    Dummy(ImVec2(0, 10));
    
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.6f, 0.6f, 0.65f, 1.0f), L("AUTOMATION CONTROL", "التحكم التلقائي"));
    if (g_ArialBlackFont) PopFont();
    if (ToggleSwitch(L("Auto Play Mode", "وضع اللعب التلقائي"), &persistent_bool[O("bAutoPlaySwitch")])) {
        AutoPlay::bAutoPlaySwitch = persistent_bool[O("bAutoPlaySwitch")];
        if (AutoPlay::bAutoPlaySwitch) {
            persistent_bool[O("bAutoAimSwitch")] = false;
            AutoPlay::bAutoAimSwitch = false;
        }
        AutoPlay::bAutoPlaying = false; 
        AutoPlay::currentMode = AutoPlay::MODE_OFF;
        AutoPlay::ClearState();
        need_save = true;
    }
    Dummy(ImVec2(0, 8));
    if (ToggleSwitch(L("Auto Aim Mode", "وضع التصويب التلقائي"), &persistent_bool[O("bAutoAimSwitch")])) {
        AutoPlay::bAutoAimSwitch = persistent_bool[O("bAutoAimSwitch")];
        if (AutoPlay::bAutoAimSwitch) {
            persistent_bool[O("bAutoPlaySwitch")] = false;
            AutoPlay::bAutoPlaySwitch = false;
        }
        AutoPlay::bAutoPlaying = false; 
        AutoPlay::currentMode = AutoPlay::MODE_OFF;
        AutoPlay::ClearState();
        need_save = true;
    }

    // Keep the requested prediction and recording options adjacent in the menu.
    Dummy(ImVec2(0, 12));
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.6f, 0.6f, 0.65f, 1.0f), L("AUTOMATION OPTIONS", "خيارات اللعب التلقائي"));
    if (g_ArialBlackFont) PopFont();

    if (!persistent_bool.count(O("bHideLinesWhileRecordingVisual"))) persistent_bool[O("bHideLinesWhileRecordingVisual")] = false;
    Dummy(ImVec2(0, 8));
    need_save |= ToggleSwitch(L("Hide Lines While Recording", "إخفاء الخطوط أثناء تصوير"), &persistent_bool[O("bHideLinesWhileRecordingVisual")]);

    if (!persistent_bool.count(O("bBreakPrediction"))) persistent_bool[O("bBreakPrediction")] = true;
    Dummy(ImVec2(0, 8));
    need_save |= ToggleSwitch(L("Break Prediction", "توقع الكسر"), &persistent_bool[O("bBreakPrediction")]);

    Dummy(ImVec2(0, 12));
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("Automation Speed", "سرعة اللعب التلقائي"));
    if (g_ArialBlackFont) PopFont();
    if (!persistent_int.count(O("iAutoSpeed"))) persistent_int[O("iAutoSpeed")] = 0;
    std::vector<std::string> speeds = { L("Maximum Fast", "ﺔﻋﺮﺳ ﻰﺼﻗﺃ"), L("Minimum Slow", "لعب بشري") };
    need_save |= GlassSegmentedControl("##auto_speed", &persistent_int[O("iAutoSpeed")], speeds);
    AutoPlay::automationSpeed = (AutoPlay::AutomationSpeed)persistent_int[O("iAutoSpeed")];

    Dummy(ImVec2(0, 12));
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("Play Style", "ﺐﻌﻠﻟﺍ ﻂﻤﻧ"));
    if (g_ArialBlackFont) PopFont();
    if (!persistent_int.count(O("iPlayStyle"))) persistent_int[O("iPlayStyle")] = 0;
    std::vector<std::string> styles = { L("Natural Play", "ﻲﻌﻴﺒﻃ ﺐﻌﻟ"), L("Instant Mode", "لعب سريع") };
    need_save |= GlassSegmentedControl("##play_style", &persistent_int[O("iPlayStyle")], styles);
    AutoPlay::playStyle = (AutoPlay::PlayStyle)persistent_int[O("iPlayStyle")];

    Dummy(ImVec2(0, 15));
    
    if (!persistent_bool.count(O("bCleanTable"))) persistent_bool[O("bCleanTable")] = false;
    AutoPlay::cleanTableMode = persistent_bool[O("bCleanTable")] ? AutoPlay::CLEAN_ALL_BALLS : AutoPlay::CLEAN_YOUR_BALLS;

    Dummy(ImVec2(0, 12));
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("9-Ball Strategy", "ﺕﺍﺮﻛ 9 ﺔﻴﺠﻴﺗﺍﺮﺘﺳﺍ"));
    if (g_ArialBlackFont) PopFont();
    if (!persistent_int.count(O("iNineMode"))) persistent_int[O("iNineMode")] = 1;
    std::vector<std::string> nineModes = { L("Best Shot", "ﺔﺑﺮﺿ ﻞﻀﻓﺃ"), L("Snipe 9", "9 ﺪﻴﺻ") };
    need_save |= GlassSegmentedControl("##nine_mode", &persistent_int[O("iNineMode")], nineModes);
    AutoPlay::nineBallStrategy = (AutoPlay::NineBallStrategy)(persistent_int[O("iNineMode")] + 1);

    Dummy(ImVec2(0, 15));
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.6f, 0.6f, 0.65f, 1.0f), L("AUTO PLAY PHYSICS", "فيزياء اللعب التلقائي"));
    if (g_ArialBlackFont) PopFont();
    
    AutoPlay::bAutoSpin = false;

    Dummy(ImVec2(0, 10));
    need_save |= ToggleSwitch(L("Auto Call Pocket", "ﺎًﻴﺋﺎﻘﻠﺗ ﺐﻴﺠﻟﺍ ﺮﻴﻴﻐﺗ"), &persistent_bool[O("bAutoPocket")]);
    if (!persistent_bool.count(O("bAutoPocket"))) persistent_bool[O("bAutoPocket")] = true;
    AutoPlay::bAutoPocket = persistent_bool[O("bAutoPocket")];

    Dummy(ImVec2(0, 10));
    need_save |= ToggleSwitch(L("Cushion Shot (8-Ball)", "(ﺕﺍﺮﻛ 8) ﺓﺩﺎﺳﻮﻟﺍ ﺔﺑﺮﺿ"), &persistent_bool[O("bCushionShot")]);
    if (!persistent_bool.count(O("bCushionShot"))) persistent_bool[O("bCushionShot")] = true;
    AutoPlay::bCushionShot = persistent_bool[O("bCushionShot")];

    Dummy(ImVec2(0, 10));
    need_save |= ToggleSwitch(L("Show Pocket Target Visual", "ﻑﺪﻬﻟﺍ ﺐﻴﺠﻟﺍ ﺮﻴﻴﻐﺗ ﺽﺮﻋ"), &persistent_bool[O("bPocketTargetVisual")]);
    if (!persistent_bool.count(O("bPocketTargetVisual"))) persistent_bool[O("bPocketTargetVisual")] = true;

    Dummy(ImVec2(0, 10));
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("Power Bar Side", "ﺓﻮﻘﻟﺍ ﻂﻳﺮﺷ ﻊﺿﻮﻣ"));
    if (g_ArialBlackFont) PopFont();
    if (!persistent_int.count(O("iPowerBarSide"))) persistent_int[O("iPowerBarSide")] = 0;
    std::vector<std::string> powerBarSides = { L("Left Side", "ﺮﺴﻳﻷﺍ ﺐﻧﺎﺠﻟﺍ"), L("Right Side", "ﻦﻤﻴﻟﺍ ﺐﻧﺎﺠﻟﺍ") };
    need_save |= GlassSegmentedControl("##powerbar_side", &persistent_int[O("iPowerBarSide")], powerBarSides);

    if (!persistent_float.count(O("fPowerBarXPercent"))) persistent_float[O("fPowerBarXPercent")] = 0.058f;
    if (!persistent_float.count(O("fPowerBarYStartPercent"))) persistent_float[O("fPowerBarYStartPercent")] = 0.32f;
    if (!persistent_float.count(O("fPowerBarYEndPercent"))) persistent_float[O("fPowerBarYEndPercent")] = 0.78f;

    Dummy(ImVec2(0, 10));
    break;
}
case 2: {
    Dummy(ImVec2(0, 10));
    need_save |= ToggleSwitch(L("Enable AutoQueue", "ﻲﺋﺎﻘﻠﺘﻟﺍ ﻝﻮﺧﺪﻟﺍ ﻞﻴﻌﻔﺗ"), &persistent_bool[O("bAutoQueue")]);
    Dummy(ImVec2(0, 20));
    
    std::vector<std::string> qModes = {L("Last Selected", "ﺭﺎﻴﺘﺧﺍ ﺮﺧﺁ"), L("Smart", "ﻲﻛﺫ"), L("Fix Table", "ﺔﺘﺑﺎﺛ ﺔﻟﻭﺎﻃ")};
    need_save |= GlassSegmentedControl(O("##mode_q"), &persistent_int[O("iAutoQueue_Mode")], qModes, 90.0f);
    
    if (persistent_int[O("iAutoQueue_Mode")] == 1) {
        Dummy(ImVec2(0, 15));
        need_save |= CustomSliderInt(L("Bet Percent", "ﻥﺎﻫﺮﻟﺍ ﺔﺒﺴﻧ"), &persistent_int[O("iAutoQueue_BetPercent")], 1, 100);
    }

    if (persistent_int[O("iAutoQueue_Mode")] == 2) {
        Dummy(ImVec2(0, 15));
        TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("Select Table", "ﺔﻟﻭﺎﻄﻟﺍ ﺮﺘﺧﺍ"));
        Dummy(ImVec2(0, 8));

        static const char* tableLabels[] = {
            "100", "200", "1k", "2.5k", "10k", "50k", "100k", "500k",
            "1M", "2M", "5M", "8M", "10M", "20M", "30M", "50M", "200M"
        };

        int& selected = persistent_int[O("iAutoQueue_FixTable")];
        float avail   = GetContentRegionAvail().x;
        int   cols    = 3;
        float gap     = 10.0f;
        float btnW    = (avail - gap * (cols - 1)) / cols;
        float btnH    = 100.0f;

        PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);

        static std::map<int, float> tileAnim;
        for (int i = 0; i < 17; i++) {
            if (i % cols != 0) SameLine(0, gap);

            ImVec2 p = GetCursorScreenPos();
            ImVec2 size = ImVec2(btnW, btnH);
            
            char btnId[64];
            snprintf(btnId, sizeof(btnId), "%s##table_tile_%d", tableLabels[i], i);
            ImGuiID id = GetID(btnId);
            
            ImRect btnBb(p + ImVec2(15.0f, 15.0f), p + size - ImVec2(15.0f, 15.0f));
            bool hovered, held;
            bool pressed = ButtonBehavior(btnBb, id, &hovered, &held);

            if (tileAnim.find(i) == tileAnim.end()) tileAnim[i] = 0.0f;
            tileAnim[i] = ImLerp(tileAnim[i], hovered ? 1.0f : 0.0f, GetIO().DeltaTime * 10.0f);
            
            bool isSel = (selected == i);
            ImDrawList* dl2 = GetWindowDrawList();
            float rounding = 25.0f;

            if (isSel) {
                ImU32 colBody = hovered ? IM_COL32(0, 140, 255, 255) : IM_COL32(0, 110, 255, 255);
                if (held) colBody = IM_COL32(180, 70, 0, 255);
                dl2->AddRectFilled(p, p + size, colBody, rounding);
                
                for(int j=1; j<=5; j++) 
                    dl2->AddRect(p - ImVec2(j,j), p + size + ImVec2(j,j), IM_COL32(255, 100, 0, 12 - j*2), rounding + j, 0, 1.0f);
                
                dl2->AddLine(p + ImVec2(rounding, 2), p + ImVec2(btnW - rounding, 2), IM_COL32(255, 255, 255, 80), 1.0f);
            } else {
                ImU32 bgCol = IM_COL32(45, 45, 55, 180);
                dl2->AddRectFilled(p, p + size, bgCol, rounding);
                if (hovered) dl2->AddRect(p, p + size, IM_COL32(255, 255, 255, 40), rounding, 0, 1.5f);
            }

            float coinR = 11.0f;
            float coinStackOffset = 5.0f;
            float spacing = 12.0f;
            ImVec2 ts = CalcTextSize(tableLabels[i]);
            float totalContentW = (coinR * 2 + coinStackOffset) + spacing + ts.x;
            float contentStartX = p.x + (btnW - totalContentW) * 0.5f;
            float centerY = p.y + btnH * 0.5f;

            ImVec2 coinP1 = ImVec2(contentStartX + coinR, centerY + 2);
            dl2->AddCircleFilled(coinP1, coinR, IM_COL32(180, 120, 0, 255), 0);
            dl2->AddCircle(coinP1, coinR, IM_COL32(140, 90, 0, 255), 0, 1.0f);

            ImVec2 coinP2 = ImVec2(contentStartX + coinR + coinStackOffset, centerY - 2);
            dl2->AddCircleFilled(coinP2, coinR, IM_COL32(0, 215, 255, 255), 0);
            dl2->AddCircle(coinP2, coinR, IM_COL32(200, 160, 0, 255), 0, 1.2f);
            dl2->AddCircle(coinP2, coinR * 0.6f, IM_COL32(0, 240, 255, 200), 0, 1.0f);

            dl2->AddText(ImVec2(contentStartX + (coinR * 2 + coinStackOffset) + spacing, centerY - ts.y * 0.5f), 
                isSel ? IM_COL32(255, 255, 255, 255) : IM_COL32(220, 220, 230, 255), tableLabels[i]);

            if (pressed) {
                selected = i;
                need_save = true;
            }
            Dummy(size);
        }
        PopStyleVar();
    }

    if (persistent_int[O("iAutoQueue_Mode")] == 0) {
        Dummy(ImVec2(0, 15));
        TextColored(ImVec4(0.5f, 0.5f, 0.55f, 1.0f), L("You will be auto queued to", "ﺎًﻴﺋﺎﻘﻠﺗ ﻚﻟﺎﺧﺩﺇ ﻢﺘﻴﺳ"));
        TextColored(ImVec4(0.5f, 0.5f, 0.55f, 1.0f), L("the last game mode you played", "ﻪﺘﺒﻌﻟ ﻢﻠﻋ ﻊﺿﻭ ﺮﺧﺁ"));
    }
    break;
}

case 3: {
    Dummy(ImVec2(0, 10));
    
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.6f, 0.6f, 0.65f, 1.0f), L("EXTRA FEATURES", "ﺕﺍﺰﻴﻤﻣﻭ ﺕﺎﻓﺎﺿﺇ"));
    if (g_ArialBlackFont) PopFont();
    Dummy(ImVec2(0, 5));

    if (!persistent_bool.count(O("bDisableAds"))) persistent_bool[O("bDisableAds")] = true;
    need_save |= ToggleSwitch(L("Disable Ads", "ﺕﺎﻧﻼﻋﻹﺍ ﻑﺎﻘﻳﺇ"), &persistent_bool[O("bDisableAds")]);
    Dummy(ImVec2(0, 8));
    
    need_save |= ToggleSwitch(L("Hide Resolution Text", "ﺔﻗﺪﻟﺍ ﺺﻧ ﺀﺎﻔﺧﺇ"), &persistent_bool[O("bHideResText")]);
    Dummy(ImVec2(0, 8));

    need_save |= ToggleSwitch(L("FPS Counter", "FPS ﺕﺍﺭﺎﻃﻹﺍ ﺩﺍﺪﻋ"), &persistent_bool[O("bFpsCounter")]);
    
    Dummy(ImVec2(0, 10));

    if (!persistent_float.count(O("fScannerLevel"))) persistent_float[O("fScannerLevel")] = 50.0f;
    need_save |= CustomSliderFloat(L("Scanner Level", "ﺢﺴﻤﻟﺍ ﻯﻮﺘﺴﻣ"), &persistent_float[O("fScannerLevel")], 0.0f, 100.0f, "%.0f%%");

    Dummy(ImVec2(0, 8));

    if (!persistent_float.count(O("fPredictionFps"))) persistent_float[O("fPredictionFps")] = 30.0f;
    need_save |= CustomSliderFloat(L("Prediction FPS", "FPS ﻊﻗﻮﺘﻟﺍ ﺔﻋﺮﺳ"), &persistent_float[O("fPredictionFps")], 15.0f, 30.0f, "%.0f FPS");

    if (!persistent_bool.count(O("bPredictionAfterShot"))) persistent_bool[O("bPredictionAfterShot")] = false;
    need_save |= ToggleSwitch(L("Prediction After Shot", "ﺔﺑﺮﻀﻟﺍ ﺪﻌﺑ ﻊﻗﻮﺘﻟﺍ"), &persistent_bool[O("bPredictionAfterShot")]);

    Dummy(ImVec2(0, 8));

    if (!persistent_bool.count(O("bDisableFlicker"))) persistent_bool[O("bDisableFlicker")] = false;
    need_save |= ToggleSwitch(L("Disable Flicker", "ﺾﻴﻣﻮﻟﺍ ﻊﻨﻣ"), &persistent_bool[O("bDisableFlicker")]);

    Dummy(ImVec2(0, 8));

    break;
}

case 4: {
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    auto DrawSectionHeader = [&](const char* title) {
        Dummy(ImVec2(0, 14));
        float avail = GetContentRegionAvail().x;
        ImVec2 p    = GetCursorScreenPos();
        float  fs   = GImGui->FontSize;
        ImVec2 ts   = CalcTextSize(title);
        float  lineY = p.y + fs * 0.5f;
        float  gap   = 8.0f;
        float  lineW = (avail - ts.x - gap * 2.0f) * 0.5f;
        ImDrawList* dl2 = GetWindowDrawList();
        dl2->AddLine(ImVec2(p.x, lineY), ImVec2(p.x + lineW, lineY), IM_COL32(60,60,75,160), 1.0f);
        dl2->AddLine(ImVec2(p.x + lineW + gap + ts.x + gap, lineY), ImVec2(p.x + avail, lineY), IM_COL32(60,60,75,160), 1.0f);
        SetCursorPosX(GetCursorPosX() + lineW + gap);
        TextColored(ImVec4(0.55f, 0.55f, 0.65f, 1.0f), "%s", title);
        Dummy(ImVec2(0, 6));
    };

    auto DrawInfoRow = [&](const char* key, const char* val, ImVec4 valCol = ImVec4(0.90f, 0.90f, 0.95f, 1.0f)) {
        SetCursorPosX(35.0f);
        TextColored(ImVec4(0.65f, 0.65f, 0.75f, 1.0f), "%s", key);
        SameLine(210.0f);
        
        if (strstr(key, "Key")) {
            SetWindowFontScale(1.15f);
            TextColored(valCol, "%s", val);
            SetWindowFontScale(1.0f);
        } else {
            TextColored(valCol, "%s", val);
        }
        Dummy(ImVec2(0, 4));
    };

    Dummy(ImVec2(0, 5));

    ImVec4 green(0.0f, 1.0f, 0.4f, 1.0f);
    ImVec4 yellow(1.0f, 0.9f, 0.0f, 1.0f);
    ImVec4 red(1.0f, 0.2f, 0.2f, 1.0f);
    ImVec4 gold(1.0f, 0.84f, 0.0f, 1.0f);
    ImVec4 cyan(0.0f, 1.0f, 1.0f, 1.0f);

    SetWindowFontScale(1.15f);
    DrawSectionHeader(L("Information", "ﺯﺎﻬﺠﻟﺍ ﺕﺎﻣﻮﻠﻌﻣ"));
    {
        static char s_manufacturer[PROP_VALUE_MAX] = {};
        static char s_model[PROP_VALUE_MAX]        = {};
        static char s_abi[PROP_VALUE_MAX]          = {};
        static bool s_props_loaded = false;
        if (!s_props_loaded) {
            __system_property_get("ro.product.manufacturer", s_manufacturer);
            __system_property_get("ro.product.model",        s_model);
            __system_property_get("ro.product.cpu.abi",      s_abi);
            s_props_loaded = true;
        }

        DrawInfoRow(L("Device: ", "ﺔﻛﺮﺸﻟﺍ :"), s_manufacturer, green);
        DrawInfoRow(L("Model:  ", "ﻞﻳﺩﻮﻤﻟﺍ :"), s_model, green);
        DrawInfoRow(L("ABI:    ", "ﺞﻟﺎﻌﻤﻟﺍ :"), s_abi, yellow);
        DrawInfoRow(L("Game:   ", "ﺔﺒﻌﻠﻟﺍ :"), O("8ball pool 56.27.0"), red);
        DrawInfoRow(L("Type:   ", "ﻉﻮﻨﻟﺍ :"), L("TIGER Engine", "نسخة تايجر"), red);
        Dummy(ImVec2(0, 5));
    }

    DrawSectionHeader(L("License Info", "ﺺﻴﺧﺮﺘﻟﺍ ﺕﺎﻣﻮﻠﻌﻣ"));
    {
        float avail = GetContentRegionAvail().x;
        
        DrawInfoRow(L("Status: ", "ﺔﻟﺎﺤﻟﺍ :"), L("Activated", "ﻞﻌﻔﻣ"), cyan);
        DrawInfoRow(L("Key:    ", "ﺡﺎﺘﻔﻤﻟﺍ :"), g_Key.c_str(), green);
        DrawInfoRow(L("Seller: ", "ﻉﺯﻮﻤﻟﺍ :"), g_Reseller.c_str(), gold);
        
        if (g_isTrial) {
            Dummy(ImVec2(0, 10));
            PushTextWrapPos(avail - 40);
            TextColored(ImVec4(1.0f, 0.2f, 0.2f, 1.0f), L("This key is provied for free. Any attempt to sell it should be considered a sacm", "ﻝﺎﺘﺣﺍ ﺔﻴﻠﻤﻋ ﺮﺒﺘﻌﺗ ﻪﻌﻴﺑ ﺔﻟﻭﺎﺤﻣ ﻱﺃ ،ﺎًﻧﺎﺠﻣ ﺡﺎﺘﻔﻤﻟﺍ ﺍﺬﻫ"));
            PopTextWrapPos();
        }
        
        Dummy(ImVec2(0, 10));
    }
    SetWindowFontScale(1.0f);
    if (g_ArialBlackFont) PopFont();
    break;
}
case 5: {
    Dummy(ImVec2(0, 10));
    SetCursorPosX(45.0f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), L("LINE EFFECTS", "ﻁﻮﻄﺨﻟﺍ ﺕﺍﺮﺛﺆﻣ"));
    if (g_ArialBlackFont) PopFont();
    Dummy(ImVec2(0, 8));

    if (!persistent_bool.count(O("bESP_LineVisualEffects"))) persistent_bool[O("bESP_LineVisualEffects")] = false;
    need_save |= ToggleSwitch(L("Enable Line Effects", "ﻁﻮﻄﺨﻟﺍ ﺕﺍﺮﺛﺆﻣ ﻞﻴﻌﻔﺗ"), &persistent_bool[O("bESP_LineVisualEffects")]);
    Dummy(ImVec2(0, 10));

    if (!persistent_int.count(O("iLineEffectStyle"))) persistent_int[O("iLineEffectStyle")] = 0;
    TextColored(ImVec4(0.7f, 0.7f, 0.75f, 1.0f), L("Effect Style", "ﺮﺛﺆﻤﻟﺍ ﻂﻤﻧ"));
    need_save |= EffectsStyleGrid(O("##line_effect_style"), &persistent_int[O("iLineEffectStyle")],
                                  {L("Off", "ﻑﺎﻘﻳﺇ"), L("Classic Fade", "ﻲﻜﻴﺳﻼﻛ ﻲﺷﻼﺗ"),
                                   L("Dotted", "ﻂﻘﻨﻣ"), L("Dashed", "ﻊﻃﺎﻘﺘﻣ"),
                                   L("Neon Glow", "ﻲﻧﻮﻴﻧ ﻖﻠﺒﺗ"), L("Laser Beam", "ﺭﺰﻴﻟ ﺔﻋﺎﺷﺇ"),
                                   L("Rainbow Flow", "ﻥﻮﻟﻷﺍ ﻑﻮﻃ"), L("Comet", "ﺐﻧﺫ ﻢﺠﻧ" )});
    Dummy(ImVec2(0, 8));

    if (!persistent_int.count(O("iLineEffectColors"))) persistent_int[O("iLineEffectColors")] = 0;
    TextColored(ImVec4(0.7f, 0.7f, 0.75f, 1.0f), L("Color Set", "ﻥﺍﻮﻟﻷﺍ ﺔﻋﻮﻤﺠﻣ"));
    need_save |= GlassSegmentedControl(O("##line_effect_colors"), &persistent_int[O("iLineEffectColors")],
                                       {L("Rainbow", "ﻥﻮﻟﻷﺍ ﻑﻮﻃ"), L("Neon", "ﻥﻮﻴﻧ"), L("Warm", "ﺊﻓﺍﺩ"), L("Cool", "ﺩﺭﺎﺑ")});
    Dummy(ImVec2(0, 8));

    if (!persistent_float.count(O("fLineEffectDensity"))) persistent_float[O("fLineEffectDensity")] = 55.0f;
    need_save |= CustomSliderFloat(L("Effect Density", "ﺮﺛﺆﻤﻟﺍ ﺔﻓﺎﺜﻛ"), &persistent_float[O("fLineEffectDensity")], 10.0f, 100.0f, "%.0f%%");
    if (!persistent_float.count(O("fLineEffectSpeed"))) persistent_float[O("fLineEffectSpeed")] = 1.0f;
    need_save |= CustomSliderFloat(L("Effect Speed", "ﺮﺛﺆﻤﻟﺍ ﺔﻋﺮﺳ"), &persistent_float[O("fLineEffectSpeed")], 0.2f, 2.5f, "%.1fx");
    if (!persistent_float.count(O("fLineEffectSize"))) persistent_float[O("fLineEffectSize")] = 1.0f;
    need_save |= CustomSliderFloat(L("Smoke / Spark Size", "ﺭﺮﺸﻟﺍ / ﻥﺎﺧﺪﻟﺍ ﻢﺠﺣ"), &persistent_float[O("fLineEffectSize")], 0.5f, 2.0f, "%.1fx");
    break;
}
    }
    
    if (need_save) save_persistence();
    
    EndChild();
    PopStyleColor(5); // ChildBg, ScrollbarBg, Grab, Hovered, Active
    PopStyleVar(2);   // ScrollbarSize, ScrollbarRounding
}

struct ToastMsg {
    std::string text;
    float alpha;
    float targetY;
    float currentY;
    double spawnTime;
};
static std::vector<ToastMsg> g_Toasts;
static double g_lastToastTime = 0.0;
static int g_toastState = 0; // 0: idle, 1: scanning, 2: found

static void PushToast(const std::string& text) {
    for (auto& t : g_Toasts) {
        t.targetY -= 85.0f; // Shift older toasts up higher to avoid overlap with bigger boxes
    }
    ToastMsg t;
    t.text = text;
    t.alpha = 0.0f;
    t.targetY = ImGui::GetIO().DisplaySize.y - 140.0f; // Lifted much higher to avoid bottom screen/nav bar clipping
    t.currentY = t.targetY + 40.0f; // Start further down for a smoother slide-up spawn
    t.spawnTime = ImGui::GetTime();
    g_Toasts.push_back(t);
    g_lastToastTime = ImGui::GetTime();
}

static void DrawToasts(ImDrawList* draw) {
    if (!persistent_bool[O("bDisableFlicker")]) {
        if (!g_Toasts.empty()) { g_Toasts.clear(); g_toastState = 0; }
        return;
    }

    double now = ImGui::GetTime();
    bool isScanning = (AutoPlay::currentMode != AutoPlay::MODE_OFF && AutoPlay::state == AutoPlay::SCANNING);
    bool isFound = (AutoPlay::g_CurrentCandidate.idx != -1);
    
        if (isFound) {
        if (g_toastState != 2) {
            PushToast(L("Shot Found!", "ﺔﺑﺮﺿ ﻰﻠﻋ ﺭﻮﺜﻌﻟﺍ ﻢﺗة!"));
            g_toastState = 2;
        } else if (now - g_lastToastTime > 1.5) {
            g_Toasts.clear();
        }
    } else if (isScanning) {
        if (g_toastState != 1 || now - g_lastToastTime > 1.2) { // Slightly longer interval between toasts
            if (g_toastState != 1) {
                PushToast(L("Scanning...", "ﺢﺴﻤﻟﺍ ﻱﺭﺎﺟ..."));
            } else {
                int r = rand() % 2;
                PushToast(r == 0 ? L("Scanning...", "ﺢﺴﻤﻟﺍ ﻱﺭﺎﺟ...") : L("Finding Shot...", "ﺔﺑﺮﺿ ﻦﻋ ﺚﺤﺒﻟﺍ ﻱﺭﺎﺟة..."));
            }
            g_toastState = 1;
        }
    } else {
        if (g_toastState == 1) {
            g_Toasts.clear();
            g_toastState = 0;
        }
    }

    float dt = ImGui::GetIO().DeltaTime;
    
    // Animate and draw toasts
    for (int i = 0; i < (int)g_Toasts.size(); i++) {
        auto& t = g_Toasts[i];
        
        bool isLatest = (i == (int)g_Toasts.size() - 1);
        
        if (!isLatest || (now - t.spawnTime > 1.5 && g_toastState != 2)) {
            t.alpha -= dt * 2.5f; // Fade out older or expiring toasts
        } else {
            t.alpha += dt * 4.0f; // Fade in latest
        }
        if (t.alpha > 1.0f) t.alpha = 1.0f;
        
        t.currentY += (t.targetY - t.currentY) * 6.0f * dt; // Lowered from 12.0f for a much smoother glide
        
        if (t.alpha <= 0.01f) {
            g_Toasts.erase(g_Toasts.begin() + i);
            i--;
            continue;
        }
        
        ImFont* font = ImGui::GetFont();
        float fontSize = font->FontSize * 1.2f;
        ImVec2 textSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, t.text.c_str());
        
        float paddingX = 36.0f; // Width reduced as requested
        float paddingY = 22.0f; // Height increased as requested
        float boxW = textSize.x + paddingX * 2.0f;
        float boxH = textSize.y + paddingY * 2.0f;
        
        float x = ImGui::GetIO().DisplaySize.x - boxW - 30.0f;
        float y = t.currentY;
        
        ImU32 bgCol = IM_COL32(0, 0, 0, (int)(t.alpha * 220)); // Deep black bg
        ImU32 textCol = IM_COL32(255, 255, 255, (int)(t.alpha * 255));
        
        draw->AddRectFilled(ImVec2(x, y), ImVec2(x + boxW, y + boxH), bgCol, 6.0f);
        
        // Running Animated Border Effect
        float t_anim = (float)now * 2.0f; // Speed of animation
        ImVec2 p_min = ImVec2(x, y);
        ImVec2 p_max = ImVec2(x + boxW, y + boxH);
        float perimeter = (boxW * 2.0f) + (boxH * 2.0f);
        float runLen = 60.0f; // Length of the running border highlight
        
        // Draw static dim orange border as base
        draw->AddRect(p_min, p_max, IM_COL32(100, 50, 0, (int)(t.alpha * 255)), 6.0f, 0, 2.0f);
        
        // Draw the moving bright segment using Path API for smooth clipping around corners
        float offset = fmodf(t_anim * 150.0f, perimeter); // Distance traveled
        
        // Setup clip rect for the glowing segment to simulate a running line
        ImVec2 glowMin = p_min;
        ImVec2 glowMax = p_max;
        
        // Simple 4-edge perimeter tracking for the highlight
        if (offset < boxW) { // Top edge
            glowMin.x = p_min.x + offset - runLen;
            glowMax.x = p_min.x + offset;
            glowMin.y = p_min.y - 8.0f;
            glowMax.y = p_min.y + 8.0f;
        } else if (offset < boxW + boxH) { // Right edge
            glowMin.x = p_max.x - 8.0f;
            glowMax.x = p_max.x + 8.0f;
            glowMin.y = p_min.y + (offset - boxW) - runLen;
            glowMax.y = p_min.y + (offset - boxW);
        } else if (offset < boxW * 2.0f + boxH) { // Bottom edge
            glowMin.x = p_max.x - (offset - boxW - boxH);
            glowMax.x = p_max.x - (offset - boxW - boxH) + runLen;
            glowMin.y = p_max.y - 8.0f;
            glowMax.y = p_max.y + 8.0f;
        } else { // Left edge
            glowMin.x = p_min.x - 8.0f;
            glowMax.x = p_min.x + 8.0f;
            glowMin.y = p_max.y - (offset - boxW * 2.0f - boxH);
            glowMax.y = p_max.y - (offset - boxW * 2.0f - boxH) + runLen;
        }
        
        draw->PushClipRect(ImVec2(ImMax(p_min.x, glowMin.x), ImMax(p_min.y, glowMin.y)), 
                           ImVec2(ImMin(p_max.x, glowMax.x), ImMin(p_max.y, glowMax.y)), true);
        draw->AddRect(p_min, p_max, IM_COL32(0, 150, 255, (int)(t.alpha * 255)), 6.0f, 0, 2.0f); // Bright Blue Highlight
        draw->PopClipRect();

        // Draw Text
        draw->AddText(font, fontSize, ImVec2(x + paddingX, y + paddingY), textCol, t.text.c_str(), NULL, 0.0f, NULL);
    }
}

INLINE void DrawMenu(ImGuiIO& io) {
    if (((g_AuthToken ^ 0xDEADBEEFCAFEBABE) == g_ExpiryTime && g_ExpiryTime > 0) || (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) || DEBUG_BYPASS_LOGIN) {
        if (is_segv_handler_active()) {
            jump_buffer_active = 1;
            if (!sigsetjmp(jump_buffer, 1)) {
                ImDrawList* bgDraw = GetBackgroundDrawList();
                DrawESP(bgDraw);
                DrawToasts(bgDraw);
            }
            jump_buffer_active = 0;
        }

        float targetAlpha = g_menu.isOpen ? 1.0f : 0.0f;
        if (g_menu.isOpen) {
            g_menu.menuAlpha += (1.0f - g_menu.menuAlpha) * io.DeltaTime * 12.0f;
        } else {
            g_menu.menuAlpha = 0.0f;
        }

        if (g_menu.menuAlpha > 0.01f) {
            float sizeScale = 1.0f + (float)persistent_int[O("iMenuSizeOffset")] * 0.03f;
            if (sizeScale < 0.3f) sizeScale = 0.3f;
            float winW = g_menu.sidebarW * sizeScale;
            float winH = 720.0f * sizeScale; // Restore the larger menu height for the expanded Effects page
            
            SetNextWindowSize(ImVec2(winW, winH), ImGuiCond_Always);
            // Keep the taller menu centered vertically so its lower content remains visible.
            SetNextWindowPos(ImVec2(Width / 2.0f, Height / 2.0f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
            
            PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.10f, 0.10f, 0.13f, 0.f));
            PushStyleVar(ImGuiStyleVar_WindowRounding, 16.0f);
            PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
            PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
            PushStyleVar(ImGuiStyleVar_Alpha, g_menu.menuAlpha);
            
            ImGuiWindowFlags winFlags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                                        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                                        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove;
            
            if (Begin(O("##MainMenu"), &g_menu.isOpen, winFlags)) {
                DrawSidebar(winW, winH);
                DrawContentArea(winW - kMenuNavWidth, winH);
            }
            End();
            
            PopStyleVar(4);
            PopStyleColor();
        }
    }
}

// Moved from AutoPlay namespace — plays/pauses autoplay (cancelMode=false)
// or cancels autoqueue (cancelMode=true)
static void DrawToggleButton(bool cancelMode) {
    if (!cancelMode && !AutoPlay::bAutoPlaySwitch && !AutoPlay::bAutoAimSwitch) {
        AutoPlay::bAutoPlaying = false;
        AutoPlay::currentMode = AutoPlay::MODE_OFF;
        return;
    }
    ImGuiIO& io = GetIO();

        EnsureUiTextures();



    float scale = ImClamp(io.DisplaySize.y / 1080.0f, 0.65f, 1.0f);
    float button_size   = 130.0f * scale;
    float winSize       = 155.0f * scale; // Match DrawFloatingButton's window size
    const float rightMargin = 20.0f * scale;
    float fixedX = io.DisplaySize.x - rightMargin - winSize; 

    float windowWidth   = button_size + 20.0f * scale;
    float windowHeight  = button_size + 20.0f * scale;
    
    // Adjust fixedX to center the smaller 130px button under the 150px main button
    float buttonX = fixedX + (winSize - windowWidth) * 0.5f;

    if (g_sideBtnsY == 0.0f)
        g_sideBtnsY = io.DisplaySize.y - 120.0f; // Default starting height

    SetNextWindowSize(ImVec2(windowWidth, windowHeight), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(buttonX, g_sideBtnsY), ImGuiCond_Always);

    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleColor(ImGuiCol_Border,   IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.0f, 10.0f)); // Add padding to prevent clipping

    if (Begin(O("##ToggleBtn"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove)) {

        ImVec2 pos    = GetCursorScreenPos();
        ImVec2 size(button_size, button_size);
        ImVec2 center(pos.x + size.x * 0.5f, pos.y + size.y * 0.5f);

        bool clicked = InvisibleButton(O("##TglBtnHit"), size);

        float r = size.x * 0.5f;
        ImDrawList* dl = GetWindowDrawList();
        
        // Circular Background for Toggle
        dl->AddCircleFilled(center, r, IM_COL32(18, 18, 22, 255));
        
        // Stylish Glow (Static)
        dl->AddCircle(center, r + 2.0f, IM_COL32(0, 150, 255, 100), 0, 3.0f);
        
        // Circular Border for Toggle - Static thickness, no wobble
        dl->AddCircle(center, r, IM_COL32(0, 150, 255, 255), 0, 4.5f);

        // Inner Animated Circle
        static float innerCircleAnim = 0.0f;
        float targetAnim = AutoPlay::bAutoPlaying ? 1.0f : 0.0f;
        innerCircleAnim += (targetAnim - innerCircleAnim) * io.DeltaTime * 12.0f;
        
        float baseInnerR = r - 16.0f; 
        float expandedInnerR = r; // Mix with main border when playing
        float currentInnerR = baseInnerR + (expandedInnerR - baseInnerR) * innerCircleAnim;
        
        // Halka (light/semi-transparent) inner circle
        dl->AddCircle(center, currentInnerR, IM_COL32(0, 200, 255, 150), 0, 2.0f);
        
        // Draw Play/Pause Symbols manually
        if (AutoPlay::bAutoPlaying) {
            // Pause Symbol (Two Vertical Bars)
            float barW = r * 0.25f;
            float barH = r * 0.7f;
            float gap  = r * 0.2f;
            ImU32 col  = IM_COL32(255, 60, 60, 255); // Red for Pause action available
            dl->AddRectFilled(ImVec2(center.x - gap - barW, center.y - barH * 0.5f), ImVec2(center.x - gap, center.y + barH * 0.5f), col, 4.0f);
            dl->AddRectFilled(ImVec2(center.x + gap, center.y - barH * 0.5f), ImVec2(center.x + gap + barW, center.y + barH * 0.5f), col, 4.0f);
        } else {
            // Play Symbol (Triangle)
            float triR = r * 0.45f;
            ImVec2 p1(center.x - triR * 0.6f, center.y - triR);
            ImVec2 p2(center.x - triR * 0.6f, center.y + triR);
            ImVec2 p3(center.x + triR, center.y);
            dl->AddTriangleFilled(p1, p2, p3, IM_COL32(0, 255, 100, 255)); // Green for Play
        }

        // Vertical-only drag
        if (IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left)) {
            g_sideBtnsY += io.MouseDelta.y;
            g_sideBtnsY = ImClamp(g_sideBtnsY, 0.0f, io.DisplaySize.y - windowHeight);
        }

        if (clicked) {
            if (cancelMode) {
                persistent_bool[O("bAutoQueue")] = false;
                g_aqCounting = false;
            } else {
                AutoPlay::bAutoPlaying = !AutoPlay::bAutoPlaying;
                if (AutoPlay::bAutoPlaying) {
                    // Set mode based on priority
                    if (AutoPlay::bAutoPlaySwitch) {
                        AutoPlay::currentMode = AutoPlay::MODE_AUTO_PLAY;
                    } else if (AutoPlay::bAutoAimSwitch) {
                        AutoPlay::currentMode = AutoPlay::MODE_AUTO_AIM;
                    }
                    AutoPlay::ClearState();
                } else {
                    AutoPlay::currentMode = AutoPlay::MODE_OFF;
                }
            }
        }
    }
    End();
    PopStyleVar();
    PopStyleColor(2);
}

static void DrawFloatingButton(ImGuiIO& io) {
    EnsureUiTextures();
    static bool isDragging = false;

    float scale = ImClamp(io.DisplaySize.y / 1080.0f, 0.65f, 1.0f);
    float buttonRadius = 70.0f * scale; // Total size 140px
    float buttonSize   = buttonRadius * 2.0f;
    float winSize      = buttonSize + 15.0f * scale; // 155px
    float margin       = 2.0f * scale; // Keep the hack menu attached to the autoplay button

    float toggleWinH = GetFrameHeight() * 1.7f + GetStyle().WindowPadding.y * 2.0f;
    const float rightMargin = 20.0f * scale;
    float toggleWinW = GetFrameHeight() * 1.7f + GetStyle().WindowPadding.x * 2.0f;
    float fixedX = io.DisplaySize.x - rightMargin - ImMax(winSize, toggleWinW);

    if (g_sideBtnsY == 0.0f)
        g_sideBtnsY = io.DisplaySize.y - 80.0f - toggleWinH;

    float posY = g_sideBtnsY - winSize - margin;

    // No shared background: keep the hack menu and autoplay button visually separate.
    SetNextWindowPos(ImVec2(fixedX, posY), ImGuiCond_Always);
    SetNextWindowSize(ImVec2(winSize, winSize), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (Begin(O("##FloatBtn"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
              ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {

        ImDrawList* dl     = GetWindowDrawList();
        ImVec2      center = ImVec2(fixedX + buttonRadius + 5, posY + buttonRadius + 5);

        SetCursorPos(ImVec2(0, 0));
        InvisibleButton(O("##FloatBtnHit"), ImVec2(winSize, winSize));

        // Circular Background
        dl->AddCircleFilled(center, buttonRadius, IM_COL32(15, 15, 20, 255));
        
        // Animated Pulse Glow (Only when AutoPlay is ON)
        static float pulsePhase = 0.0f;
        if (AutoPlay::bAutoPlaying) {
            pulsePhase += io.DeltaTime * 3.5f;
            float pulseAlpha = (sinf(pulsePhase) * 0.5f + 0.5f); // 0.0 to 1.0
            
            dl->AddCircle(center, buttonRadius + 2.0f + (pulseAlpha * 3.0f), IM_COL32(0, 150, 255, (int)(100 * (1.0f - pulseAlpha))), 0, 4.0f);
            dl->AddCircle(center, buttonRadius + 4.0f + (pulseAlpha * 6.0f), IM_COL32(0, 150, 255, (int)(50 * (1.0f - pulseAlpha))), 0, 8.0f);
        }

        // Rotating Segmented Border (Outer)
        static float rotAngle = 0.0f;
        if (AutoPlay::bAutoPlaying) {
            rotAngle += io.DeltaTime * 1.5f;
        }
        
        int num_segments = 6;
        float dash_length = (2.0f * 3.141592654f) / (num_segments * 2.0f);
        for (int i = 0; i < num_segments; i++) {
            float a_min = rotAngle + i * dash_length * 2.0f;
            float a_max = a_min + dash_length;
            // Move it slightly outward (buttonRadius + 6.0f) to avoid overlapping the main solid border
            dl->PathArcTo(center, buttonRadius + 6.0f, a_min, a_max, 10);
            // Increased thickness to 6.0f and opacity to 255 for better visibility
            dl->PathStroke(IM_COL32(0, 150, 255, 255), 0, 6.0f); 
        }

        // Main Solid Border (Slightly thicker as requested)
        dl->AddCircle(center, buttonRadius, IM_COL32(0, 150, 255, 255), 0, 5.5f);
        
        // Inner Fine Ring
        dl->AddCircle(center, buttonRadius - 5.0f, IM_COL32(0, 150, 255, 150), 0, 2.0f);
        
        // Draw logo — Perfectly Rounded
        ImVec2 p_min(center.x - buttonRadius + 8.0f, center.y - buttonRadius + 8.0f);
        ImVec2 p_max(center.x + buttonRadius - 8.0f, center.y + buttonRadius - 8.0f);
        if (g_logoTexture) {
            dl->AddImageRounded((ImTextureID)(intptr_t)g_logoTexture, p_min, p_max, ImVec2(0,0), ImVec2(1,1), IM_COL32_WHITE, buttonRadius);
        } else {
            // Keep the control visible even if decoding failed on this frame.
            dl->AddCircleFilled(center, buttonRadius - 8.0f, IM_COL32(25, 25, 32, 255));
            dl->AddTriangleFilled(
                ImVec2(center.x - buttonRadius * 0.22f, center.y - buttonRadius * 0.32f),
                ImVec2(center.x - buttonRadius * 0.22f, center.y + buttonRadius * 0.32f),
                ImVec2(center.x + buttonRadius * 0.34f, center.y),
                IM_COL32(0, 255, 100, 255));
        }

        // Vertical-only drag moves both buttons together via g_sideBtnsY
        if (IsItemActive() && IsMouseDragging(0)) {
            isDragging = true;
            g_sideBtnsY += io.MouseDelta.y;
            g_sideBtnsY = ImClamp(g_sideBtnsY, winSize + margin,
                                  io.DisplaySize.y - 80.0f - toggleWinH);
        }

        if (IsItemHovered() && IsMouseReleased(0) && !isDragging)
            g_menu.isOpen = !g_menu.isOpen;

        if (!IsItemActive()) isDragging = false;
    }
    End();
    PopStyleVar(2);
    PopStyleColor();
}


INLINE void DrawUpdateRequired(ImGuiIO& io) {
    // Full screen black transparent overlay
    SetNextWindowPos(ImVec2(0, 0));
    SetNextWindowSize(io.DisplaySize);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.02f, 0.02f, 0.03f, 0.92f));
    Begin(O("##OverlayUpdate"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBringToFrontOnFocus);
    PopStyleColor();

    float cardW = 860;
    float cardH = (io.DisplaySize.y < 850) ? io.DisplaySize.y * 0.95f : 820;

    SetNextWindowSize(ImVec2(cardW, cardH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.08f, 0.08f, 0.10f, 1.0f));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 30.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    Begin(O("##UpdateCard"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar);

    ImDrawList* dl = GetWindowDrawList();
    ImVec2 winPos = GetWindowPos();
    
    // Draw Orange Border (Stylish bold look)
    dl->AddRect(winPos, winPos + ImVec2(cardW, cardH), IM_COL32(0, 127, 255, 200), 30.0f, 0, 13.0f);
    dl->AddRect(winPos + ImVec2(2, 2), winPos + ImVec2(cardW - 2, cardH - 2), IM_COL32(0, 127, 255, 40), 30.0f, 0, 1.0f);

    // Title Section: "UPDATE REQUIRED" (Orange bold text - moved higher)
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    SetCursorPosY(cardH * 0.085f);
    SetWindowFontScale(1.7f);
    ImVec2 titleSize = CalcTextSize(L("UPDATE REQUIRED", "التحديث مطلوب"));
    SetCursorPosX((cardW - titleSize.x) * 0.5f);
    
    TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), L("UPDATE REQUIRED", "التحديث مطلوب"));
    SetWindowFontScale(1.0f);
    if (g_ArialBlackFont) PopFont();

    // Text Description (centered, multi-line, with "APK" in yellow and written "chota")
    std::string p1 = L("This version is outdated for the new ", "هذه النسخة قديمة للملف الجديد ");
    std::string p2 = O("APK");
    std::string p3 = L(" file", "");
    std::string line2Text = L("please click the button below and download", "اضغط الزر بالأسفل لتحميل التحديث");
    std::string enjoyText = L("Enjoy TIGER Engine", "استمتع بتطبيق تايجر انجين");

    float w1 = CalcTextSize(p1.c_str()).x;
    float w2 = CalcTextSize(p2.c_str()).x;
    float w3 = CalcTextSize(p3.c_str()).x;
    float totalW1 = w1 + w2 + w3;
    float totalW2 = CalcTextSize(line2Text.c_str()).x;
    float totalW3 = CalcTextSize(enjoyText.c_str()).x;

    // Line 1: Centered with Yellow APK
    SetCursorPosY(cardH * 0.21f);
    SetWindowFontScale(0.95f);
    SetCursorPosX((cardW - totalW1) * 0.5f);
    TextColored(ImVec4(0.85f, 0.85f, 0.90f, 1.0f), "%s", p1.c_str());
    SameLine(0, 0);
    TextColored(ImVec4(1.0f, 0.9f, 0.0f, 1.0f), "%s", p2.c_str()); // Yellow
    SameLine(0, 0);
    TextColored(ImVec4(0.85f, 0.85f, 0.90f, 1.0f), "%s", p3.c_str());

    // Line 2: Centered white text below Line 1
    SetCursorPosY(cardH * 0.21f + 30.0f);
    SetCursorPosX((cardW - totalW2) * 0.5f);
    TextColored(ImVec4(0.85f, 0.85f, 0.90f, 1.0f), "%s", line2Text.c_str());

    // Line 3: Very small orange "Enjoy LionX" below Line 2
    SetCursorPosY(cardH * 0.21f + 65.0f);
    SetWindowFontScale(0.80f); // Very small
    SetCursorPosX((cardW - totalW3) * 0.5f);
    TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), "%s", enjoyText.c_str()); // Orange

    SetWindowFontScale(1.0f);

    // Download Button
    SetCursorPosY(cardH * 0.51f);
    SetCursorPosX(70);
    PushStyleColor(ImGuiCol_Button, ImVec4(1.0f, 0.45f, 0.0f, 1.0f));
    PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.55f, 0.1f, 1.0f));
    PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.8f, 0.35f, 0.0f, 1.0f));
    PushStyleVar(ImGuiStyleVar_FrameRounding, 20.0f);
    
    if (Button(O("##DownloadBtn"), ImVec2(cardW - 140, cardH * 0.17f))) {
        if (!g_UpdateURL.empty()) {
            OpenURL(g_UpdateURL.c_str());
        }
    }

    // Draw text and icon on top of the button
    ImVec2 btnPos = GetItemRectMin();
    ImVec2 btnSize = GetItemRectSize();
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    SetWindowFontScale(1.4f);
    ImVec2 btnTextSize = CalcTextSize(L("Download Now", "حمّل الآن"));
    dl->AddText(ImVec2(btnPos.x + (btnSize.x - btnTextSize.x) * 0.5f + 20, btnPos.y + (btnSize.y - btnTextSize.y) * 0.5f), IM_COL32(255, 255, 255, 255), L("Download Now", "حمّل الآن"));
    SetWindowFontScale(1.0f);
    if (g_ArialBlackFont) PopFont();

    // Draw Download Icon using FontAwesome to the left of the text
    if (g_IconFont) {
        PushFont(g_IconFont);
        SetWindowFontScale(1.4f); // Match the scale of download button text
        ImVec2 downloadIconSize = CalcTextSize("\uF019");
        float textX = btnPos.x + (btnSize.x - btnTextSize.x) * 0.5f + 20.0f;
        ImVec2 iconDrawPos = ImVec2(
            textX - downloadIconSize.x - 15.0f,
            btnPos.y + (btnSize.y - downloadIconSize.y) * 0.5f
        );
        dl->AddText(iconDrawPos, IM_COL32(255, 255, 255, 255), "\uF019");
        SetWindowFontScale(1.0f);
        PopFont();
    }

    PopStyleVar();
    PopStyleColor(3);

    // Community Footer (Two Identical Telegram Icons - Texture Based)
    SetCursorPosY(cardH * 0.73f);
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    ImVec2 commSize = CalcTextSize(L("Join Community", "انضم إلى مجتمعنا"));
    SetCursorPosX((cardW - commSize.x) * 0.5f);
    TextColored(ImVec4(0.6f, 0.6f, 0.65f, 1.0f), L("Join Community", "انضم إلى مجتمعنا"));
    if (g_ArialBlackFont) PopFont();
    
    EnsureUiTextures();

    float iconSide = cardH * 0.134f; // Upscaled
    float iconY = cardH * 0.88f;

    auto DrawTeleLogo = [&](float centerX, const char* url) {
        ImVec2 center = winPos + ImVec2(centerX, iconY);
        ImVec2 topLeft = center - ImVec2(iconSide * 0.5f, iconSide * 0.5f);
        ImVec2 bottomRight = center + ImVec2(iconSide * 0.5f, iconSide * 0.5f);
        
        if (g_telegramTexture) {
            dl->AddImageRounded((ImTextureID)(intptr_t)g_telegramTexture, topLeft, bottomRight, ImVec2(0,0), ImVec2(1,1), IM_COL32_WHITE, 15.0f);
        }
        
        SetCursorScreenPos(topLeft);
        if (InvisibleButton((O("##TeleBtnUpdate_") + std::to_string((int)centerX)).c_str(), ImVec2(iconSide, iconSide))) {
            OpenURL(url);
        }
    };

    DrawTeleLogo(cardW * 0.35f, O("https://t.me/TIGERGYMAR")); // Left Icon
    DrawTeleLogo(cardW * 0.65f, O("https://t.me/TIGERGYMAR")); // Right Icon

    End(); // UpdateCard
    PopStyleVar(3);
    PopStyleColor();

    End(); // OverlayUpdate
}


static bool first_time = true;
INLINE void DrawLogin(ImGuiIO& io) {
    if ((g_AuthToken ^ 0xDEADBEEFCAFEBABE) == g_ExpiryTime && g_ExpiryTime > 0) return DrawMenu(io);

    // Full screen overlay
    SetNextWindowPos(ImVec2(0, 0));
    SetNextWindowSize(io.DisplaySize);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.02f, 0.02f, 0.03f, 0.92f));
    Begin(O("##Overlay"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBringToFrontOnFocus);
    PopStyleColor();

    float cardW = 860;
    float cardH = (io.DisplaySize.y < 850) ? io.DisplaySize.y * 0.95f : 820;

    SetNextWindowSize(ImVec2(cardW, cardH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.08f, 0.08f, 0.10f, 1.0f));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 30.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    Begin(O("##LoginCard"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar);

    ImDrawList* dl = GetWindowDrawList();
    ImVec2 winPos = GetWindowPos();
    
    // Draw Blue Border
    dl->AddRect(winPos, winPos + ImVec2(cardW, cardH), IM_COL32(0, 127, 255, 200), 30.0f, 0, 13.0f);
    dl->AddRect(winPos + ImVec2(2, 2), winPos + ImVec2(cardW - 2, cardH - 2), IM_COL32(0, 127, 255, 40), 30.0f, 0, 1.0f);

    // Title Section
    if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
    SetCursorPosY(cardH * 0.085f);
    SetWindowFontScale(1.7f);
    ImVec2 titleSize = CalcTextSize(L("TIGER Engine", "تايجر انجين"));
    SetCursorPosX((cardW - titleSize.x) * 0.5f);
    TextColored(ImVec4(1.0f, 0.5f, 0.0f, 1.0f), L("TIGER Engine", "تايجر انجين"));
    SetWindowFontScale(1.0f);
    if (g_ArialBlackFont) PopFont();

    // --- SECURITY HEARTBEAT WATCHDOG ---
    static uint64_t lastHeartbeat = 0;
    static time_t lastHeartbeatTime = 0;
    if (lastHeartbeatTime == 0) {
        lastHeartbeat = Security::securityHeartbeat;
        lastHeartbeatTime = time(nullptr);
    } else {
        if (Security::securityHeartbeat != lastHeartbeat) {
            lastHeartbeat = Security::securityHeartbeat;
            lastHeartbeatTime = time(nullptr);
        } else if (time(nullptr) - lastHeartbeatTime > 30) {
            exit(0);
        }
    }
    
    if (is_logging_in) {
        SetCursorPosY(cardH * 0.45f);
        static float spinnerAngle = 0.0f;
        spinnerAngle += io.DeltaTime * 6.0f;
        ImVec2 center = winPos + ImVec2(cardW * 0.5f, cardH * 0.5f);
        for (int i = 0; i < 8; i++) {
            float a = spinnerAngle + (i * 3.1415f * 2.0f / 8.0f);
            dl->AddCircleFilled(center + ImVec2(cosf(a), sinf(a)) * 50.0f, 9.0f, IM_COL32(255, 127, 0, (int)(255 * (8 - i) / 8.0f)));
        }
        SetCursorPosY(cardH * 0.70f);
        ImVec2 authTextSize = CalcTextSize(L("Authenticating...", "جاري التحقق..."));
        SetCursorPosX((cardW - authTextSize.x) * 0.5f);
        TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), L("Authenticating...", "جاري التحقق..."));
    } else {
        // Error Message Display
        if (ERROR_CODE != 0 || !ERROR_MESSAGE.empty()) {
            std::string displayError = ERROR_MESSAGE.empty() ? std::string(L("Connection Error!", "خطأ في الاتصال!")) : ERROR_MESSAGE;
            if (ERROR_CODE == 0xE05) displayError = L("Server busy, try again.", "الخادم مشغول، حاول مجدداً.");
            if (ERROR_CODE == 0xE10) displayError = L("Invalid License Key!", "مفتاح الترخيص غير صالح!");
            if (ERROR_CODE == 0xE11) displayError = L("Data sync error.", "خطأ في مزامنة البيانات.");
            if (ERROR_CODE == 0xE15) displayError = L("Key used on another device!", "المفتاح مستخدم على جهاز آخر!");
            if (ERROR_CODE == 0xE20) displayError = L("License Expired!", "انتهت صلاحية الترخيص!");
            
            SetCursorPosY(cardH * 0.21f);
            SetWindowFontScale(0.85f);
            ImVec2 errSize = CalcTextSize(displayError.c_str());
            SetCursorPosX((cardW - errSize.x) * 0.5f);
            TextColored(ImVec4(1.0f, 0.2f, 0.2f, 1.0f), "%s", displayError.c_str());
            SetWindowFontScale(1.0f);
        }

        // Key Input Display Area
        SetCursorPosY(cardH * 0.26f);
        ImVec2 inputSize = ImVec2(cardW - 140, cardH * 0.17f);
        SetCursorPosX(70);
        ImVec2 inputPos = GetCursorScreenPos();
        
        dl->AddRectFilled(inputPos, inputPos + inputSize, IM_COL32(25, 25, 30, 255), 20.0f);
        dl->AddRect(inputPos, inputPos + inputSize, IM_COL32(0, 127, 255, 40), 20.0f, 0, 2.0f);
        
        SetCursorPosY(cardH * 0.26f + (inputSize.y - 45) / 2.0f); 
        SetCursorPosX(100);
        static std::string loginError = "";
        std::string displayKey = persistent_string["key"];
        bool isPlaceholder = displayKey.empty();
        if (isPlaceholder) displayKey = O("XXXXX-XXXXX-XXXXX-XXXXX-XXXXX");
        
        if (isPlaceholder) {
            SetWindowFontScale(1.15f);
            TextColored(ImVec4(0.45f, 0.45f, 0.5f, 1.0f), "%s", displayKey.c_str());
        } else {
            SetWindowFontScale(1.4f);
            TextColored(ImVec4(0.9f, 0.9f, 0.95f, 1.0f), "%s", displayKey.c_str());
        }
        SetWindowFontScale(1.0f);
        
        float iconSize = inputSize.y * 0.46f;
        ImVec2 iconPos = inputPos + ImVec2(inputSize.x - iconSize - 20, (inputSize.y - iconSize) / 2.0f);
        
        if (g_IconFont) {
            PushFont(g_IconFont);
            SetWindowFontScale(1.4f);
            ImVec2 faClipboardSize = CalcTextSize("\uF46D");
            ImVec2 iconDrawPos = ImVec2(
                iconPos.x + (iconSize - faClipboardSize.x) * 0.5f,
                iconPos.y + (iconSize - faClipboardSize.y) * 0.5f
            );
            dl->AddText(iconDrawPos, IM_COL32(0, 127, 255, 255), "\uF46D");
            SetWindowFontScale(1.0f);
            PopFont();
        }

        SetCursorScreenPos(iconPos);
        if (InvisibleButton(O("##PasteBtn"), ImVec2(iconSize, iconSize))) {
            JNIEnv* env;
            jint getEnvResult = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
            if (getEnvResult == JNI_EDETACHED) VM->AttachCurrentThread(&env, nullptr);
            
            std::string pasted = getClipboard(env);
            if (!pasted.empty()) {
                pasted.erase(pasted.find_last_not_of(" \n\r\t") + 1);
                persistent_string["key"] = pasted;
                loginError = "";
                ERROR_MESSAGE = "";
                save_persistence();
            }
        }

        // Authenticate Button
        SetCursorPosY(cardH * 0.51f);
        SetCursorPosX(70);
        PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.45f, 1.0f, 1.0f));
        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.1f, 0.55f, 1.0f, 1.0f));
        PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.0f, 0.35f, 0.8f, 1.0f));
        PushStyleVar(ImGuiStyleVar_FrameRounding, 20.0f);
        
        if (Button(O("##AuthBtn"), ImVec2(cardW - 140, cardH * 0.17f))) {
            JNIEnv* env;
            jint getEnvResult = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
            if (getEnvResult == JNI_EDETACHED) VM->AttachCurrentThread(&env, nullptr);
            
            std::string keyToUse = persistent_string["key"];
            if (keyToUse.empty()) keyToUse = getClipboard(env);
            
            // =============================================================
            // 🔥 التعديل الجديد: إزالة القيود الصارمة وتنظيف المفتاح تلقائياً
            // =============================================================
            
            // 1. تنظيف المفتاح من أي مسافات أو رموز غير مرغوب فيها (مثل الشرطات الزائدة)
            std::string cleanedKey = "";
            for (char c : keyToUse) {
                if (isalnum(c) || c == '-') { // نحتفظ فقط بالأحرف والأرقام والشرطة
                    cleanedKey += c;
                }
            }

            // 2. التحقق من مفتاح الـ Bypass (7 أيام)
            if (cleanedKey == O("LION-56BF-8628-FFNK-9A2D")) {
                loginError = "";
                g_AuthToken = (uint64_t)g_ExpiryTime ^ 0xDEADBEEFCAFEBABE;
                g_Token = O("WATAN_VIP_7D");
                g_Auth = O("WATAN_VIP_7D");
                
                if (persistent_string[O("bypass_act_ts")].empty()) {
                    persistent_string[O("bypass_act_ts")] = std::to_string((int64_t)time(nullptr));
                    save_persistence();
                }
                
                int64_t actTs = std::stoll(persistent_string[O("bypass_act_ts")]);
                G_EXPIRY_TS = actTs + (7LL * 24LL * 3600LL);
                g_ExpTime = formatTimestamp(G_EXPIRY_TS);
                
                g_menu.showLanguageSelector = true;
                g_menu.isOpen = false;
                first_time = false;
            } else if (!DEBUG_BYPASS_LOGIN) {
                // 3. بدء التسجيل الحقيقي (تمت إزالة شرط الـ 23 حرفاً)
                ERROR_MESSAGE = "";
                std::thread([cleanedKey]() {
                    Login(getAndroidID(nullptr), cleanedKey);
                }).detach();
            } else {
                loginError = "";
                g_AuthToken = (uint64_t)g_ExpiryTime ^ 0xDEADBEEFCAFEBABE; 
                g_Token = O("DEBUG_BYPASS");
                g_Auth = O("DEBUG_BYPASS");
                g_menu.showLanguageSelector = true;
                g_menu.isOpen = false;
                first_time = false;
            }
        }
        
        // Draw text and icon on top of the button
        ImVec2 btnPos = GetItemRectMin();
        ImVec2 btnSize = GetItemRectSize();
        if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
        SetWindowFontScale(1.4f);
        ImVec2 authTextSize = CalcTextSize(L("AUTHENTICATE", "ﻝﻮﺧﺪﻟﺍ ﻞﻴﺠﺴﺗ"));
        dl->AddText(ImVec2(btnPos.x + (btnSize.x - authTextSize.x) * 0.5f + 35, btnPos.y + (btnSize.y - authTextSize.y) * 0.5f), IM_COL32(255, 255, 255, 255), L("AUTHENTICATE", "ﻝﻮﺧﺪﻟﺍ ﻞﻴﺠﺴﺗ"));
        SetWindowFontScale(1.0f);
        if (g_ArialBlackFont) PopFont();
        
        if (g_IconFont) {
            PushFont(g_IconFont);
            SetWindowFontScale(1.0f);
            ImVec2 keyIconSize = CalcTextSize("\uF084");
            float textX = btnPos.x + (btnSize.x - authTextSize.x) * 0.5f + 35.0f;
            ImVec2 iconDrawPos = ImVec2(
                textX - keyIconSize.x - 18.0f,
                btnPos.y + (btnSize.y - keyIconSize.y) * 0.5f
            );
            dl->AddText(iconDrawPos, IM_COL32(255, 255, 255, 255), "\uF084");
            SetWindowFontScale(1.0f);
            PopFont();
        }

        PopStyleVar();
        PopStyleColor(3);

        // Community Footer
        SetCursorPosY(cardH * 0.73f);
        if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
        ImVec2 commSize = CalcTextSize(L("Join Community", "ﺎﻨﻌﻤﺘﺠﻣ ﻰﻟﺍ ﻢﻀﻧﺍا"));
        SetCursorPosX((cardW - commSize.x) * 0.5f);
        TextColored(ImVec4(0.6f, 0.6f, 0.65f, 1.0f), L("Join Community", "ﺎﻨﻌﻤﺘﺠﻣ ﻰﻟﺍ ﻢﻀﻧﺍا"));
        if (g_ArialBlackFont) PopFont();
        
        EnsureUiTextures();

        float iconSide = cardH * 0.134f;
        float iconY = cardH * 0.88f;

        // --- LANGUAGE SELECTOR UI ---
        if (g_menu.showLanguageSelector) {
            float lCardW = 450.0f * g_menu.menuScale;
            float lCardH = 320.0f * g_menu.menuScale;
            SetNextWindowPos(winPos + ImVec2((cardW - lCardW) * 0.5f, (cardH - lCardH) * 0.5f));
            SetNextWindowSize(ImVec2(lCardW, lCardH));
            PushStyleColor(ImGuiCol_WindowBg, IM_COL32(11, 14, 18, 255));
            PushStyleVar(ImGuiStyleVar_WindowRounding, 25.0f);
            Begin(O("##LangSelector"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove);
            
            ImDrawList* lDl = GetWindowDrawList();
            ImVec2 lPos = GetWindowPos();
            ImVec2 lSize = GetWindowSize();

            lDl->AddRectFilled(lPos, ImVec2(lPos.x + lSize.x, lPos.y + 70 * g_menu.menuScale), IM_COL32(20, 24, 28, 255), 25.0f, ImDrawFlags_RoundCornersTop);
            lDl->AddLine(ImVec2(lPos.x, lPos.y + 70 * g_menu.menuScale), ImVec2(lPos.x + lSize.x, lPos.y + 70 * g_menu.menuScale), IM_COL32(0, 127, 255, 200), 2.0f);

            const char* lTitle = L("CHOOSE LANGUAGE", "اختر اللغة");
            if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
            ImVec2 ltSize = CalcTextSize(lTitle);
            lDl->AddText(ImVec2(lPos.x + (lSize.x - ltSize.x) * 0.5f, lPos.y + (70 * g_menu.menuScale - ltSize.y) * 0.5f), IM_COL32(255, 255, 255, 255), lTitle);
            if (g_ArialBlackFont) PopFont();

            float lBtnW = 160.0f * g_menu.menuScale;
            float lBtnH = 100.0f * g_menu.menuScale;
            float lStartX = lPos.x + (lSize.x - (lBtnW * 2 + 30 * g_menu.menuScale)) * 0.5f;
            float lStartY = lPos.y + 110 * g_menu.menuScale;

            auto DrawLangBtn = [&](const char* label, const char* sub, int langVal, ImVec2 p) {
                ImGuiID id = GetID(label);
                ImRect bb(p, p + ImVec2(lBtnW, lBtnH));
                ItemAdd(bb, id);
                bool hov, held;
                bool pressed = ButtonBehavior(bb, id, &hov, &held);

                ImU32 bCol = hov ? IM_COL32(40, 44, 52, 255) : IM_COL32(25, 29, 35, 255);
                if (held) bCol = IM_COL32(0, 127, 255, 100);
                
                lDl->AddRectFilled(bb.Min, bb.Max, bCol, 15.0f);
                lDl->AddRect(bb.Min, bb.Max, hov ? IM_COL32(0, 127, 255, 255) : IM_COL32(60, 64, 72, 255), 15.0f, 0, 1.5f);

                ImVec2 txtS = CalcTextSize(label);
                lDl->AddText(ImVec2(p.x + (lBtnW - txtS.x) * 0.5f, p.y + 25 * g_menu.menuScale), IM_COL32(255, 255, 255, 255), label);
                ImVec2 subS = CalcTextSize(sub);
                lDl->AddText(ImVec2(p.x + (lBtnW - subS.x) * 0.5f, p.y + 55 * g_menu.menuScale), IM_COL32(180, 180, 180, 255), sub);

                if (pressed) {
                    persistent_int["iLang"] = langVal;
                    svConfig_Save();
                    g_menu.showLanguageSelector = false;
                    g_menu.isOpen = true;
                }
            };

            DrawLangBtn("English", "Welcome", 0, ImVec2(lStartX, lStartY));
            DrawLangBtn("العربية", "أهلاً بك", 1, ImVec2(lStartX + lBtnW + 30 * g_menu.menuScale, lStartY));

            End();
            PopStyleVar();
            PopStyleColor();
            return;
        }

        auto DrawTeleLogo = [&](float centerX, const char* url) {
            ImVec2 center = winPos + ImVec2(centerX, iconY);
            ImVec2 topLeft = center - ImVec2(iconSide * 0.5f, iconSide * 0.5f);
            ImVec2 bottomRight = center + ImVec2(iconSide * 0.5f, iconSide * 0.5f);
            
            if (g_telegramTexture) {
                dl->AddImageRounded((ImTextureID)(intptr_t)g_telegramTexture, topLeft, bottomRight, ImVec2(0,0), ImVec2(1,1), IM_COL32_WHITE, 15.0f);
            }
            
            SetCursorScreenPos(topLeft);
            if (InvisibleButton((O("##TeleBtn_") + std::to_string((int)centerX)).c_str(), ImVec2(iconSide, iconSide))) {
                OpenURL(url);
            }
        };

        DrawTeleLogo(cardW * 0.35f, O("https://t.me/TIGERGYMAR"));
        DrawTeleLogo(cardW * 0.65f, O("https://t.me/TIGERGYMAR"));
    }

    End(); // LoginCard
    PopStyleVar(3);
    PopStyleColor();

    End(); // Overlay
}



INLINE void SetupImgui() {
    CheckAppUpdate();
    PACKAGE_NAME = string(getcmdline());

    ImGui::CreateContext();

    auto& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;

    switch_theme(current_theme);
    load_persistence();
    
    std::string savedKey = persistent_string["key"];
    if (!savedKey.empty() && !((g_AuthToken ^ 0xDEADBEEFCAFEBABE) == g_ExpiryTime && g_ExpiryTime > 0)) {
        std::thread([savedKey]() {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            Login(getAndroidID(nullptr), savedKey);
        }).detach();
    }

    AutoPlay::bAutoPlaySwitch = persistent_bool[O("bAutoPlaySwitch")];
    AutoPlay::bAutoAimSwitch = persistent_bool[O("bAutoAimSwitch")];
    svConfig_Load();
    load_imgui_style();

    static string INI_PATH = O("/data/user_de/0/") + PACKAGE_NAME + O("/no_backup/.ini");
    io.IniFilename = persistent_bool["bImguiAutoSave"] ? INI_PATH.c_str() : nullptr;
    io.ConfigWindowsMoveFromTitleBarOnly = persistent_bool["bMoveOnlyWithTitleBar"];

    // ============================================
    // Helper: load Arabic system font and MERGE on top of the
    // previously added font.
    // ============================================
    auto MergeArabicInto = [&](float sizePx) -> bool {
        static const char* arabicFontPaths[] = {
            "/system/fonts/NotoNaskhArabic-Regular.ttf",
            "/system/fonts/NotoNaskhArabicUI-Regular.ttf",
            "/system/fonts/NotoSansArabic-Regular.ttf",
            "/system/fonts/NotoKufiArabic-Regular.ttf",
            "/system/fonts/DroidNaskh-Regular.ttf",
            "/system/fonts/DroidSansArabic.ttf",
            "/system/fonts/Roboto-Regular.ttf",
        };
        ImFontConfig arabic_cfg;
        arabic_cfg.MergeMode            = true;
        arabic_cfg.PixelSnapH           = true;
        arabic_cfg.FontDataOwnedByAtlas = false;
        arabic_cfg.SizePixels           = sizePx;
        arabic_cfg.GlyphOffset          = ImVec2(0.0f, 2.0f);
        for (const char* fontPath : arabicFontPaths) {
            FILE* f = fopen(fontPath, "rb");
            if (f) {
                fclose(f);
                io.Fonts->AddFontFromFileTTF(fontPath, sizePx, &arabic_cfg, GetArabicGlyphRanges());
                return true;
            }
        }
        return false;
    };

    float baseSize = persistent_float["fFontScale"];

    // ============================================
    // 1) Segoe UI + Arabic merge on top of it
    // ============================================
    ImFontConfig font_cfg;
    font_cfg.SizePixels = baseSize;
    font_cfg.FontDataOwnedByAtlas = false;
    g_SegoeUIFont = io.Fonts->AddFontFromMemoryTTF((void*)segoeui_ttf, segoeui_ttf_len, baseSize, &font_cfg);
    bool arabicFontLoaded = MergeArabicInto(baseSize);

    // ============================================
    // 2) Arial Black + Arabic merge on top of it
    // ============================================
    g_ArialBlackFont = io.Fonts->AddFontFromMemoryTTF((void*)arial_black_ttf, arial_black_ttf_len, baseSize, &font_cfg);
    MergeArabicInto(baseSize);

    // ============================================
    // 3) FontAwesome icons (separate font, no Arabic merge)
    // ============================================
    static const ImWchar icon_ranges[] = {
        0xF013, 0xF013, 0xF019, 0xF019, 0xF05A, 0xF05A,
        0xF084, 0xF084, 0xF1DA, 0xF1DA, 0xF46D, 0xF46D,
        0xF4D7, 0xF4D7, 0xF544, 0xF544,
        0
    };
    ImFontConfig icon_cfg;
    icon_cfg.FontDataOwnedByAtlas = false;
    float iconScale = (baseSize > 5.0f) ? (baseSize / 22.0f) : 1.0f;
    g_IconFont = io.Fonts->AddFontFromMemoryTTF((void*)font_awesome_ttf, font_awesome_ttf_len, 35.0f * iconScale, &icon_cfg, icon_ranges);

    if (!arabicFontLoaded) {
        // Fallback: default font (English glyphs only) so build does not fail.
        ImFontConfig fallbackCfg;
        fallbackCfg.MergeMode = true;
        fallbackCfg.SizePixels = baseSize;
        io.Fonts->AddFontDefault(&fallbackCfg);
    }

    io.Fonts->Build();

    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(O("#version 300 es"));

    bImguiSetup = true;
}
INLINE void DrawResolutionText(ImGuiIO& io, int w, int h) {
    if (persistent_bool[O("bHideResText")]) return;

    float scale = ImClamp(io.DisplaySize.y / 1080.0f, 0.65f, 1.0f);
    SetNextWindowPos(ImVec2(30.0f * scale, 105.0f * scale));

    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (Begin(O("##ResTextWin"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoInputs)) {
        
        if (g_ArialBlackFont) PushFont(g_ArialBlackFont);
        SetWindowFontScale(0.95f * scale);
        
        char resBuf[64];
        snprintf(resBuf, sizeof(resBuf), "%s: %d x %d", L("Resolution", "الدقة"), w, h);
        
        ImVec2 pos = GetCursorScreenPos();
        ImDrawList* dl = GetWindowDrawList();
        
        ImU32 outCol = IM_COL32(0, 0, 0, 255);
        ImU32 textCol = IM_COL32(0, 255, 0, 255);
        
        // Sharp outline for that professional overlay look
        dl->AddText(ImVec2(pos.x - 1.0f, pos.y), outCol, resBuf);
        dl->AddText(ImVec2(pos.x + 1.0f, pos.y), outCol, resBuf);
        dl->AddText(ImVec2(pos.x, pos.y - 1.0f), outCol, resBuf);
        dl->AddText(ImVec2(pos.x, pos.y + 1.0f), outCol, resBuf);
        
        // Main green text
        dl->AddText(pos, textCol, resBuf);

        ImVec2 ts = CalcTextSize(resBuf);
        SetWindowSize(ImVec2(ts.x + 10, ts.y + 10));
        
        SetWindowFontScale(1.0f);
        if (g_ArialBlackFont) PopFont();
    }
    End();
    PopStyleVar(2);
    PopStyleColor();
}

INLINE void DrawFPSCounter(ImGuiIO& io) {
    if (!persistent_bool[O("bFpsCounter")]) return;

    static float g_fpsCounterY = 0.0f;
    if (g_fpsCounterY == 0.0f) {
        g_fpsCounterY = Height * 0.4f; // Default starting height
    }

    float scale = ImClamp(io.DisplaySize.y / 1080.0f, 0.65f, 1.0f);
    float button_size = 130.0f * scale; // Same as play/pause button
    float radius = button_size * 0.5f;
    
    // Fixed X pos, Draggable Y pos
    float margin = 20.0f * scale;
    float fixedX = margin; 

    float windowWidth = button_size + 20.0f * scale;
    float windowHeight = button_size + 20.0f * scale;

    SetNextWindowSize(ImVec2(windowWidth, windowHeight), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(fixedX, g_fpsCounterY), ImGuiCond_Always);

    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.0f, 10.0f));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (Begin(O("##FPSCounterWin"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings)) {
        
        ImVec2 pos = GetCursorScreenPos();
        ImVec2 size(button_size, button_size);
        ImVec2 center(pos.x + size.x * 0.5f, pos.y + size.y * 0.5f);
        
        // Handle dragging
        bool clicked = InvisibleButton(O("##FPSHit"), size);
        if (IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left)) {
            g_fpsCounterY += io.MouseDelta.y;
            g_fpsCounterY = ImClamp(g_fpsCounterY, 0.0f, io.DisplaySize.y - windowHeight);
        }

        ImDrawList* dl = GetWindowDrawList();
        
        // Stylish Background (Matching Play/Pause button style)
        dl->AddCircleFilled(center, radius, IM_COL32(18, 18, 22, 255));
        
        // FPS logic with Smooth Interpolation (EMA)
        static float smoothedFps = 60.0f;
        if (smoothedFps == 60.0f && io.Framerate > 0.0f) {
            smoothedFps = io.Framerate;
        }
        smoothedFps += (io.Framerate - smoothedFps) * 0.07f; // Smooth transition
        
        char fpsBuf[16];
        snprintf(fpsBuf, sizeof(fpsBuf), "%.0f", smoothedFps);
        
        ImU32 fpsCol = IM_COL32(0, 255, 100, 255); // Vibrant Green
        if (smoothedFps < 30.0f) {
            fpsCol = IM_COL32(255, 50, 50, 255);   // Red
        } else if (smoothedFps < 45.0f) {
            fpsCol = IM_COL32(0, 120, 255, 255);   // Orange
        } else if (smoothedFps < 55.0f) {
            fpsCol = IM_COL32(0, 215, 255, 255);   // Golden Yellow
        }

        // --- DYNAMIC ORANGE & YELLOW HUD CIRCLE ---
        // 1. Dark grey track background
        dl->AddCircle(center, radius, IM_COL32(45, 45, 50, 255), 0, 4.0f);
        
        // 2. Outer orange glowing ring
        dl->AddCircle(center, radius + 2.0f, IM_COL32(0, 120, 255, 80), 0, 2.0f);
        
        // 3. Dynamic Golden Yellow Progress Arc based on FPS
        float angle_max = (smoothedFps / 60.0f) * 2.0f * IM_PI;
        if (angle_max > 2.0f * IM_PI) angle_max = 2.0f * IM_PI;
        if (angle_max < 0.0f) angle_max = 0.0f;
        
        dl->PathArcTo(center, radius, -IM_PI * 0.5f, -IM_PI * 0.5f + angle_max, 40);
        dl->PathStroke(IM_COL32(0, 215, 255, 255), 0, 4.0f);

        // Render FPS value
        SetWindowFontScale(2.5f * scale);
        ImVec2 ts = CalcTextSize(fpsBuf);
        dl->AddText(ImVec2(center.x - ts.x * 0.5f, center.y - ts.y * 0.5f - 8.0f * scale), fpsCol, fpsBuf);
        
        // Render Label
        SetWindowFontScale(1.0f * scale);
        ImVec2 tsLbl = CalcTextSize("FPS");
        dl->AddText(ImVec2(center.x - tsLbl.x * 0.5f, center.y + ts.y * 0.5f - 10.0f * scale), IM_COL32(200, 200, 220, 255), "FPS");
        
        SetWindowFontScale(1.0f);
    }
    End();
    PopStyleVar(2);
    PopStyleColor();
}

DEFINES(EGLBoolean, Draw, EGLDisplay dpy, EGLSurface surface) {

    eglQuerySurface(dpy, surface, EGL_WIDTH, &Width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &Height);

    if (Width <= 0 || Height <= 0) return _Draw(dpy, surface);

    screenCenter = Vector2(Width / 2, Height / 2);

    if (!bImguiSetup) SetupImgui();

    ImGuiIO& io = ImGui::GetIO();

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(Width, Height);
    ImGui::NewFrame();

    if (!is_segv_handler_active()) setup_global_segv_handler();
    if (g_UpdateRequired) {
        DrawUpdateRequired(io);
        static bool lastState = true;
        bool currentState = true;
        if (currentState != lastState) {
            UpdateOverlayFlags(currentState);
            lastState = currentState;
        }
    } else if (IsExpired()) {
        DrawExpired(io);
    } else if (((g_AuthToken ^ 0xDEADBEEFCAFEBABE) == g_ExpiryTime && g_ExpiryTime > 0) || DEBUG_BYPASS_LOGIN || (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth)) {
        DrawFloatingButton(io);
        DrawMenu(io);
        DrawToggleButton(false);
        DrawFPSCounter(io);
        DrawBreakPrediction(io);
        DrawResolutionText(io, Width, Height);
        
        // Update Touch Mask: If menu is closed and no modal is active, make window transparent to touches
        static bool lastState = true;
        bool currentState = g_menu.isOpen || g_aqCounting || first_time;
        if (currentState != lastState) {
            UpdateOverlayFlags(currentState);
            lastState = currentState;
        }
    } else {
        DrawLogin(io);
    }
    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    ImGui_ClearHoverEffect();

    return _Draw(dpy, surface);
}

void __IMGUI__() {
    create_directory_recursive(CONC(O("/data/user_de/0/"), PACKAGE_NAME.c_str(), O("/no_backup")));
}
