#ifndef KEYLOGIN_H
#define KEYLOGIN_H

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <random>
#include <chrono>
#include <ctime>
#include <vector>
#include <algorithm>
#include <curl/curl.h>
#include <map>
#include "include/obfuscate.h"
// ============================================
// إعدادات السيرفر الخاص بك
// ============================================

// ⚠️ قم بتغيير هذا الرابط إلى رابط موقعك الفعلي
const std::string API_BASE_URL = OO("https://davidenginecheto.x10.mx/lconnect").str();// مثال: "https://abonakhl.com/connect"
const std::string DEFAULT_GAME = OO("8pool").str(); // اللعبة الوحيدة المتاحة هي PUBG

// ============================================
// تعريف المتغيرات العامة
// ============================================

extern bool bValid;
extern bool logged_in;
extern bool is_logging_in;
extern std::string g_Token;
extern std::string g_Auth;
extern std::string g_ExpTime;
extern std::string ERROR_MESSAGE;

// تعريف المتغيرات نفسها (القيم الافتراضية)
bool bValid = false;
bool logged_in = false;
bool is_logging_in = false;
std::string g_Token = "";
std::string g_Auth = "";
std::string g_ExpTime = "N/A";
std::string ERROR_MESSAGE = "";

// ============================================
// دوال HTTP الأساسية
// ============================================

size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* response) {
    response->append((char*)contents, size * nmemb);
    return size * nmemb;
}

std::string urlEncode(const std::string& value) {
    CURL* curl = curl_easy_init();
    if (!curl) return value;
    char* encoded = curl_easy_escape(curl, value.c_str(), value.length());
    std::string result(encoded);
    curl_free(encoded);
    curl_easy_cleanup(curl);
    return result;
}

/**
 * دالة POST لإرسال البيانات إلى السيرفر
 * @param url رابط الـ API
 * @param postData البيانات المرسلة (مثل: "game=pubg&user_key=KEY123&serial=HWID123")
 */
std::string httpPost(const std::string& url, const std::string& postData) {
    CURL* curl = curl_easy_init();
    std::string response;
    
    if (!curl) return "";
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    
    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    
    CURLcode res = curl_easy_perform(curl);
    
    if (res != CURLE_OK) {
        ERROR_MESSAGE = "HTTP request failed: " + std::string(curl_easy_strerror(res));
    }
    
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    
    return response;
}

// ============================================
// الحصول على HWID (معرف الجهاز)
// ============================================

std::string getHWID() {
    std::ifstream hwid_file(".hwid");
    if (hwid_file.is_open()) {
        std::string id;
        std::getline(hwid_file, id);
        hwid_file.close();
        if (!id.empty()) return id;
    }
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 15);
    const char* chars = "0123456789ABCDEF";
    std::string hwid;
    for (int i = 0; i < 32; i++) {
        hwid += chars[dis(gen)];
    }
    
    std::ofstream out_file(".hwid");
    out_file << hwid;
    out_file.close();
    
    return hwid;
}

// ============================================
// تحليل JSON يدوي بسيط (بدون مكتبات خارجية)
// ============================================

std::string extractJsonString(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\"";
    size_t keyPos = json.find(searchKey);
    if (keyPos == std::string::npos) return "";
    
    size_t valuePos = json.find(":", keyPos);
    if (valuePos == std::string::npos) return "";
    
    size_t quote1 = json.find("\"", valuePos);
    if (quote1 == std::string::npos) return "";
    
    size_t quote2 = json.find("\"", quote1 + 1);
    if (quote2 == std::string::npos) return "";
    
    return json.substr(quote1 + 1, quote2 - quote1 - 1);
}

bool extractJsonBool(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\"";
    size_t keyPos = json.find(searchKey);
    if (keyPos == std::string::npos) return false;
    
    size_t valuePos = json.find(":", keyPos);
    if (valuePos == std::string::npos) return false;
    
    // البحث عن "true" أو "false"
    if (json.find("true", valuePos) != std::string::npos && 
        json.find("true", valuePos) < json.find(",", valuePos)) {
        return true;
    }
    return false;
}

// ============================================
// دالة التحقق الرئيسية عبر السيرفر الخاص بك (PUBG فقط)
// ============================================

/**
 * ترسل طلب POST إلى السيرفر للتحقق من صحة المفتاح.
 * @param license_key المفتاح الذي أدخله المستخدم
 * @param hwid معرف الجهاز (Android ID أو HWID)
 * @return true إذا كان المفتاح صالحاً، false إذا فشل التحقق
 */
bool verifyWithYourServer(const std::string& license_key, const std::string& hwid) {
    // إعداد البيانات التي سيتم إرسالها إلى السيرفر
    // ملاحظة: اللعبة ثابتة = "pubg" لأن السيرفر يدعم PUBG فقط
    std::string postData = "game=" + urlEncode(DEFAULT_GAME) +
                           "&user_key=" + urlEncode(license_key) +
                           "&serial=" + urlEncode(hwid);
    
    std::cout << "🌐 جاري الاتصال بالسيرفر: " << API_BASE_URL << std::endl;
    std::cout << "🎮 اللعبة: " << DEFAULT_GAME << " (PUBG)" << std::endl;
    std::cout << "🔑 المفتاح: " << license_key << std::endl;
    std::cout << "📱 HWID: " << hwid << std::endl;
    
    // إرسال الطلب إلى السيرفر
    std::string response = httpPost(API_BASE_URL, postData);
    
    if (response.empty()) {
        ERROR_MESSAGE = "لا يوجد رد من السيرفر";
        return false;
    }
    
    std::cout << "📨 رد السيرفر: " << response << std::endl;
    
    // التحقق من وجود "status\":true في الرد
    if (response.find("\"status\":true") != std::string::npos || 
        response.find("\"status\": true") != std::string::npos) {
        
        // استخراج تاريخ الانتهاء إذا وجد
        std::string expiry = extractJsonString(response, "EXP");
        if (!expiry.empty()) {
            g_ExpTime = expiry;
            std::cout << "📅 تاريخ الانتهاء: " << g_ExpTime << std::endl;
        }
        
        // استخراج التوكن إذا وجد
        std::string token = extractJsonString(response, "token");
        if (!token.empty()) {
            g_Token = token;
            g_Auth = token;
        }
        
        std::cout << "✅ المفتاح صالح!" << std::endl;
        return true;
    }
    
    // فشل التحقق، استخراج سبب الفشل
    std::string reason = extractJsonString(response, "reason");
    if (!reason.empty()) {
        ERROR_MESSAGE = reason;
    } else {
        ERROR_MESSAGE = "المفتاح غير صالح";
    }
    
    return false;
}

// ============================================
// دالة تسجيل الدخول الرئيسية
// ============================================

bool Login(std::string androidID, std::string key) {
    is_logging_in = true;
    
    if (androidID.empty()) {
        ERROR_MESSAGE = "لا يمكن الحصول على معرف الجهاز (Android ID)";
        is_logging_in = false;
        return false;
    }
    
    if (key.empty()) {
        ERROR_MESSAGE = "المفتاح فارغ";
        is_logging_in = false;
        return false;
    }
    
    std::string hwid = androidID;
    
    std::cout << "🔍 جاري التحقق من المفتاح: " << key << std::endl;
    std::cout << "📱 معرف الجهاز (HWID): " << hwid << std::endl;
    
    // ============ التحقق عبر السيرفر الخاص بك (PUBG فقط) ============
    std::cout << "🌐 جاري الاتصال بالسيرفر للتحقق..." << std::endl;
    
    if (verifyWithYourServer(key, hwid)) {
        logged_in = true;
        g_Token = key;
        g_Auth = key;
        bValid = true;
        is_logging_in = false;
        std::cout << "✅ تم تسجيل الدخول بنجاح عبر السيرفر!" << std::endl;
        return true;
    } else {
        std::cout << "❌ فشل التحقق عبر السيرفر: " << ERROR_MESSAGE << std::endl;
    }
    
    // فشل التحقق
    logged_in = false;
    g_Token = "";
    g_Auth = "";
    bValid = false;
    is_logging_in = false;
    
    return false;
}

#endif // KEYLOGIN_H