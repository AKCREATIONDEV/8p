#pragma once

#include <Vector/Vectors.h>
#include <imgui/imgui.h>

#include "resources.h"

using namespace ImGui;
using namespace std;

#include "include/includes.h"

#include "8bp.h"
#include "8bp/Ruleset.h"
#include "imgui/inc/8bp.h"
#include "keylogin.h"
#include "oxorany/oxorany.h"

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <jni.h>
#include <cstring>

struct MenuState {
    bool isOpen = false;
    int currentTab = 0;
    float sidebarWidth = 300.0f;
    float animProgress = 0.0f;
    float menuAlpha = 0.0f;
    float menuScale = 0.9f;
    ImVec4 accentColor = ImVec4(0.35f, 0.65f, 0.95f, 1.0f);
};
static MenuState g_menu;

static float EaseOutBack(float x) {
    const float c1 = 1.70158f;
    const float c3 = c1 + 1.0f;
    return 1.0f + c3 * powf(x - 1.0f, 3.0f) + c1 * powf(x - 1.0f, 2.0f);
}

static float EaseOutQuart(float x) {
    return 1.0f - powf(1.0f - x, 4.0f);
}

static void DrawGradientRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImU32 col1, ImU32 col2, bool horizontal = true) {
    if (horizontal) {
        dl->AddRectFilledMultiColor(p1, p2, col1, col2, col2, col1);
    } else {
        dl->AddRectFilledMultiColor(p1, p2, col1, col1, col2, col2);
    }
}

static bool SidebarButton(const char* label, const char* icon, bool selected, float width) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = ImVec2(width - 20.0f, 58.0f);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);

    static std::map<ImGuiID, float> hoverAnim;
    float& animT = hoverAnim[id];
    float targetT = (selected || hovered) ? 1.0f : 0.0f;
    animT += (targetT - animT) * g.IO.DeltaTime * 12.0f;

    ImDrawList* dl = window->DrawList;
    
    if (selected) {
        ImU32 gradCol1 = IM_COL32(40, 100, 180, 255);
        ImU32 gradCol2 = IM_COL32(60, 130, 200, 255);
        dl->AddRectFilled(bb.Min, bb.Max, gradCol1, 10.0f);
        dl->AddRectFilled(ImVec2(bb.Min.x, bb.Min.y + 2), ImVec2(bb.Min.x + 6, bb.Max.y - 2), IM_COL32(100, 200, 255, 255), 3.0f);
    } else if (animT > 0.01f) {
        ImU32 hoverCol = IM_COL32(50, 50, 60, (int)(180 * animT));
        dl->AddRectFilled(bb.Min, bb.Max, hoverCol, 12.0f);
    }

    float iconOffset = 8.0f * animT;
    ImVec2 iconPos = ImVec2(bb.Min.x + 22.0f + iconOffset, bb.Min.y + (size.y - g.FontSize) * 0.5f);
    dl->AddText(iconPos, selected ? IM_COL32(255, 255, 255, 255) : IM_COL32(140, 140, 160, (int)(180 + 75 * animT)), icon);
    
    ImVec2 textPos = ImVec2(bb.Min.x + 58.0f + iconOffset, bb.Min.y + (size.y - g.FontSize) * 0.5f);
    dl->AddText(textPos, selected ? IM_COL32(255, 255, 255, 255) : IM_COL32(200, 200, 215, (int)(200 + 55 * animT)), label);

    return pressed;
}

static bool ToggleSwitch(const char* label, bool* v) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    float height = 32.0f;
    float width = 56.0f;
    float radius = height * 0.5f;

    ImVec2 textSize = CalcTextSize(label);
    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = ImVec2(GetContentRegionAvail().x, ImMax(height, textSize.y) + style.FramePadding.y * 2 + 10.0f);

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);
    if (pressed) *v = !*v;

    static std::map<ImGuiID, float> switchAnim;
    float& animT = switchAnim[id];
    float targetT = *v ? 1.0f : 0.0f;
    animT += (targetT - animT) * g.IO.DeltaTime * 14.0f;

    ImDrawList* dl = window->DrawList;
    
    if (hovered) {
        dl->AddRectFilled(bb.Min, bb.Max, IM_COL32(45, 45, 55, 100), 10.0f);
    }
    
    ImVec2 togglePos = ImVec2(bb.Max.x - width - 15.0f, bb.Min.y + (size.y - height) * 0.5f);
    ImVec2 toggleEnd = ImVec2(togglePos.x + width, togglePos.y + height);
    
    ImVec4 offColor = ImVec4(0.27f, 0.27f, 0.31f, 1.0f);
    ImVec4 onColor = ImVec4(0.20f, 0.55f, 0.86f, 1.0f);
    ImVec4 bgColorV = ImLerp(offColor, onColor, animT);
    dl->AddRectFilled(togglePos, toggleEnd, ImColor(bgColorV), radius);
    
    float knobX = togglePos.x + radius + (width - height) * animT;
    float knobY = togglePos.y + radius;
    float knobR = radius - 4.0f;
    
    dl->AddCircleFilled(ImVec2(knobX, knobY), knobR + 2.0f, IM_COL32(0, 0, 0, 40));
    dl->AddCircleFilled(ImVec2(knobX, knobY), knobR, IM_COL32(255, 255, 255, 255));

    dl->AddText(ImVec2(bb.Min.x + 15.0f, bb.Min.y + (size.y - textSize.y) * 0.5f), IM_COL32(230, 230, 240, 255), label);

    return pressed;
}

INLINE void DrawAutoQueue() {
    if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        static std::chrono::steady_clock::time_point last_call_time;
        static std::chrono::steady_clock::time_point countdown_start;
        static bool counting = false;

        auto now = std::chrono::steady_clock::now();

        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - last_call_time).count() > 500) {
            counting = false;
        }
        last_call_time = now;

        if (!counting) {
            counting = true;
            countdown_start = now;
        }

        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - countdown_start).count();
        int remaining_ms = 3000 - elapsed;

        if (remaining_ms <= 0) {
            if (sharedMenuManager.getMenuStateId() == 13) PopMenuState(13);
            StartLastMatch();
            counting = false;
            return;
        }

        SetNextWindowPos(ImVec2(Width / 2.0f, Height / 2.0f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        SetNextWindowSize(ImVec2(360, 260), ImGuiCond_Always);
        PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.10f, 0.10f, 0.12f, 0.98f));
        PushStyleVar(ImGuiStyleVar_WindowRounding, 20.0f);

        if (Begin(O("##AutoQueue"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
            ImDrawList* dl = GetWindowDrawList();
            ImVec2 winPos = GetWindowPos();
            ImVec2 winSize = GetWindowSize();
            
            DrawGradientRect(dl, winPos, ImVec2(winPos.x + winSize.x, winPos.y + 70), IM_COL32(40, 100, 180, 255), IM_COL32(60, 140, 200, 255), true);
            dl->AddRectFilled(winPos, ImVec2(winPos.x + winSize.x, winPos.y + 20), IM_COL32(40, 100, 180, 255), 20.0f, ImDrawFlags_RoundCornersTop);
            
            ImVec2 titleSize = CalcTextSize(O("Auto Queue"));
            dl->AddText(ImVec2(winPos.x + (winSize.x - titleSize.x) * 0.5f, winPos.y + 22), IM_COL32(255, 255, 255, 255), O("Auto Queue"));

            SetCursorPosY(90);
            float font_scale = 3.5f;
            SetWindowFontScale(font_scale);

            std::string count_str = std::to_string((remaining_ms / 1000) + 1);
            auto text_size = CalcTextSize(count_str.c_str());
            SetCursorPosX((winSize.x - text_size.x) * 0.5f);
            TextColored(ImVec4(0.35f, 0.7f, 1.0f, 1.0f), "%s", count_str.c_str());

            SetWindowFontScale(1.0f);

            SetCursorPosY(winSize.y - 75);
            SetCursorPosX(25);
            PushStyleColor(ImGuiCol_Button, ImVec4(0.75f, 0.25f, 0.25f, 1.0f));
            PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.85f, 0.35f, 0.35f, 1.0f));
            PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);
            
            if (Button(O("Cancel"), ImVec2(winSize.x - 50, 50))) {
                persistent_bool[O("bAutoQueue")] = false;
                counting = false;
            }
            
            PopStyleVar();
            PopStyleColor(2);
            End();
        }
        PopStyleVar();
        PopStyleColor();
    }
}

INLINE void DrawESP(ImDrawList* draw) {
    if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        if (!sharedGameManager) return;

        UpdateScreenTable();

        sharedDirector = F(ptr, libmain + O(0x4f06288));
        if (!sharedDirector) return;

        sharedUserInfo = F(ptr, libmain + O(0x4e9feb8));
        if (!sharedUserInfo) return;

        F(bool, sharedUserInfo + 0x340) = true;

        sharedMainManager = F(ptr, libmain + O(0x4dde3e0));
        if (!sharedMainManager) return;

        sharedMenuManager = F(ptr, libmain + O(0x4dfe838));
        if (!sharedMenuManager) return;

        MainStateManager mainStateManager = sharedMainManager.mStateManager;
        if (!mainStateManager) return;
        if (!mainStateManager.isInGame()) {
        if (persistent_bool[O("bAutoQueue")]) {
            if (!sharedMenuManager.isInQueue()) DrawAutoQueue();
        } return;
        }

        auto visualCue = sharedGameManager.mVisualCue();

        Ball::Classification myclass = sharedGameManager.getPlayerClassification();

        Table table = sharedGameManager.mTable;
        if (!table) return;

        auto tableProperties = table.mTableProperties();
        if (!tableProperties) return;

        auto& pockets = tableProperties.mPockets();

        if (persistent_bool[O("bESP_DrawPockets")]) {
            for (int i = 0; i < 6; i++) {
                auto screenPos = WorldToScreen(pockets[i]);
                draw->AddCircle(ImVec2(screenPos.x, screenPos.y), 40, WHITE, 0, 3.f);
            }
        }

        GameStateManager gameStateManager = sharedGameManager.mStateManager;
        if (!gameStateManager) return;

        if (persistent_bool[O("bAutoPlay")]) AutoPlay::Update();

        auto stateId = gameStateManager.getCurrentStateId();
        if (stateId == 4) gPrediction->determineShotResult(false);
        if (stateId == 6 || stateId == 7 || stateId == 8) return;

        if (persistent_bool[O("bESP_DrawPocketsShotState")]) {
            for (int i = 0; i < 6; i++) {
                if (Prediction::pocketStatus[i]) {
                    auto screenPos = WorldToScreen(pockets[i]);
                    draw->AddCircle(ImVec2(screenPos.x, screenPos.y), 40, GREEN, 0, 5.f);
                }
            }
        }

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    ImVec2 lastPos{};
                    for (int j = 1; j < ball.positions.size(); j++) {
                        auto point = WorldToScreen(ball.positions[j]);
                        if (lastPos.x || lastPos.y) draw->AddLine(lastPos, point, colors[i], 10.f);
                        lastPos = point;
                    }
                }
            }
        }

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    draw->AddCircle(WorldToScreen(ball.initialPosition), 20, colors[i], 0, 6.f);
                    draw->AddCircleFilled(WorldToScreen(ball.predictedPosition), 20, colors[i]);
                }
            }
        }
    }
}

#include "ButtonClicker.h"

static void DrawSidebar(float sidebarW, float winH) {
    ImDrawList* dl = GetWindowDrawList();
    ImVec2 winPos = GetWindowPos();
    
    DrawGradientRect(dl, winPos, ImVec2(winPos.x + sidebarW, winPos.y + winH), IM_COL32(22, 22, 28, 255), IM_COL32(28, 28, 35, 255), false);
    dl->AddLine(ImVec2(winPos.x + sidebarW, winPos.y), ImVec2(winPos.x + sidebarW, winPos.y + winH), IM_COL32(55, 55, 65, 255), 1.0f);
    
    SetCursorPos(ImVec2(0, 25));
    
    BeginGroup();
    
    Dummy(ImVec2(sidebarW, 5));
    SetCursorPosX(25);
    
    PushStyleColor(ImGuiCol_Text, ImVec4(0.4f, 0.75f, 1.0f, 1.0f));
    SetWindowFontScale(1.2f);
    Text(O("AK"));
    SetWindowFontScale(1.0f);
    PopStyleColor();
    
    SetCursorPosX(25);
    TextColored(ImVec4(0.55f, 0.55f, 0.6f, 1.0f), O("Engine"));
    
    Dummy(ImVec2(sidebarW, 35));
    
    SetCursorPosX(15);
    if (SidebarButton(O("ESP"), O(">"), g_menu.currentTab == 0, sidebarW)) g_menu.currentTab = 0;
    
    Dummy(ImVec2(0, 5));
    SetCursorPosX(15);
    if (SidebarButton(O("Auto Play"), O(">"), g_menu.currentTab == 1, sidebarW)) g_menu.currentTab = 1;
    
    Dummy(ImVec2(0, 5));
    SetCursorPosX(15);
    if (SidebarButton(O("Auto Queue"), O(">"), g_menu.currentTab == 2, sidebarW)) g_menu.currentTab = 2;
    
    EndGroup();
}

static void DrawContentArea(float sidebarW, float winW, float winH) {
    bool need_save = false;
    
    ImDrawList* dl = GetWindowDrawList();
    ImVec2 winPos = GetWindowPos();
    
    DrawGradientRect(dl, ImVec2(winPos.x + sidebarW, winPos.y), ImVec2(winPos.x + winW, winPos.y + 65), IM_COL32(30, 30, 38, 255), IM_COL32(35, 35, 42, 255), false);
    dl->AddLine(ImVec2(winPos.x + sidebarW, winPos.y + 65), ImVec2(winPos.x + winW, winPos.y + 65), IM_COL32(50, 50, 60, 255), 1.0f);
    
    const char* tabTitles[] = { "ESP Settings", "Auto Play", "Auto Queue" };
    
    SetCursorPos(ImVec2(sidebarW + 25, 22));
    SetWindowFontScale(1.15f);
    TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "%s", tabTitles[g_menu.currentTab]);
    SetWindowFontScale(1.0f);
    
    SetCursorPos(ImVec2(sidebarW + 15, 80));
    
    PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_ScrollbarSize, 0.0f);
    BeginChild(O("##ContentArea"), ImVec2(winW - sidebarW - 30, winH - 95), false, ImGuiWindowFlags_NoScrollbar);
    
    switch (g_menu.currentTab) {
        case 0: {
            Dummy(ImVec2(0, 10));
            need_save |= ToggleSwitch(O("Draw Prediction Lines"), &persistent_bool[O("bESP_DrawPredictionLine")]);
            need_save |= ToggleSwitch(O("Draw Pockets"), &persistent_bool[O("bESP_DrawPockets")]);
            need_save |= ToggleSwitch(O("Draw Shot State"), &persistent_bool[O("bESP_DrawPocketsShotState")]);
            break;
        }
        
        case 1: {
            Dummy(ImVec2(0, 10));
            need_save |= ToggleSwitch(O("Enable Auto Play"), &persistent_bool[O("bAutoPlay")]);
            
            Dummy(ImVec2(0, 20));
            TextColored(ImVec4(0.5f, 0.5f, 0.55f, 1.0f), O("Auto play will automatically"));
            TextColored(ImVec4(0.5f, 0.5f, 0.55f, 1.0f), O("aim and shoot for you"));
            break;
        }
        
        case 2: {
            Dummy(ImVec2(0, 10));
            need_save |= ToggleSwitch(O("Enable Auto Queue"), &persistent_bool[O("bAutoQueue")]);
            Dummy(ImVec2(0, 20));
            
            TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), O("Mode"));
            Dummy(ImVec2(0, 8));
            PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
            PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(15, 12));
            PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.12f, 0.12f, 0.15f, 1.0f));
            PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.16f, 0.16f, 0.20f, 1.0f));
            SetNextItemWidth(GetContentRegionAvail().x);
            need_save |= Combo("##mode", &persistent_int["iAutoQueue_Mode"], "Last Selected\0Smart\0");
            PopStyleColor(2);
            PopStyleVar(2);
            
            if (persistent_int["iAutoQueue_Mode"] == 1) {
                Dummy(ImVec2(0, 15));
                TextColored(ImVec4(0.75f, 0.75f, 0.8f, 1.0f), O("Bet Percent"));
                Dummy(ImVec2(0, 8));
                PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
                PushStyleVar(ImGuiStyleVar_GrabRounding, 10.0f);
                PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.12f, 0.12f, 0.15f, 1.0f));
                PushStyleColor(ImGuiCol_SliderGrab, ImVec4(0.3f, 0.6f, 0.95f, 1.0f));
                PushStyleColor(ImGuiCol_SliderGrabActive, ImVec4(0.4f, 0.7f, 1.0f, 1.0f));
                SetNextItemWidth(GetContentRegionAvail().x);
                need_save |= SliderInt("##betpercent", &persistent_int["iAutoQueue_BetPercent"], 1, 100, "%d%%");
                PopStyleColor(3);
                PopStyleVar(2);
            }
            
            Dummy(ImVec2(0, 25));
            TextColored(ImVec4(0.5f, 0.5f, 0.55f, 1.0f), O("You will be auto queued to"));
            TextColored(ImVec4(0.5f, 0.5f, 0.55f, 1.0f), O("the last game mode you played"));
            break;
        }
    }
    
    if (need_save) save_persistence();
    
    EndChild();
    PopStyleVar();
    PopStyleColor();
}

INLINE void DrawMenu(ImGuiIO& io) {
    if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        if (is_segv_handler_active()) {
            jump_buffer_active = 1;
            if (!sigsetjmp(jump_buffer, 1)) DrawESP(GetBackgroundDrawList());
            jump_buffer_active = 0;
        }

        float targetAlpha = g_menu.isOpen ? 1.0f : 0.0f;
        if (g_menu.isOpen) {
            g_menu.menuAlpha += (1.0f - g_menu.menuAlpha) * io.DeltaTime * 12.0f;
        } else {
            g_menu.menuAlpha = 0.0f;
        }

        if (g_menu.menuAlpha > 0.01f) {
            float winW = 800.0f;
            float winH = 580.0f;
            
            SetNextWindowSize(ImVec2(winW, winH), ImGuiCond_Always);
            SetNextWindowPos(ImVec2(Width / 2.0f, Height / 2.0f), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
            
            PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.13f, 0.13f, 0.16f, g_menu.menuAlpha));
            PushStyleVar(ImGuiStyleVar_WindowRounding, 16.0f);
            PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
            PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
            PushStyleVar(ImGuiStyleVar_Alpha, g_menu.menuAlpha);
            
            ImGuiWindowFlags winFlags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse;
            
            if (Begin(O("##MainMenu"), &g_menu.isOpen, winFlags)) {
                ImDrawList* dl = GetWindowDrawList();
                ImVec2 winPos = GetWindowPos();
                
                dl->AddRect(winPos, ImVec2(winPos.x + winW, winPos.y + winH), IM_COL32(60, 60, 70, (int)(150 * g_menu.menuAlpha)), 16.0f, 0, 1.5f);
                
                DrawSidebar(g_menu.sidebarWidth, winH);
                DrawContentArea(g_menu.sidebarWidth, winW, winH);
            }
            End();
            
            PopStyleVar(4);
            PopStyleColor();
        }
    }
}

static void DrawFloatingButton(ImGuiIO& io) {
    static ImVec2 buttonPos = ImVec2(80, 60);
    static bool isDragging = false;
    static float hoverAnim = 0.0f;
    
    float buttonRadius = 38.0f;
    float buttonSize = buttonRadius * 2.0f;
    float textWidth = 140.0f;
    float totalWidth = buttonSize + textWidth + 15.0f;
    float totalHeight = buttonSize + 4.0f;
    
    bool isHovered = false;
    
    SetNextWindowPos(buttonPos, ImGuiCond_Always);
    SetNextWindowSize(ImVec2(totalWidth, totalHeight), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    
    if (Begin(O("##FloatBtn"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
        ImDrawList* dl = GetWindowDrawList();
        
        ImVec2 center = ImVec2(buttonPos.x + buttonRadius + 2, buttonPos.y + buttonRadius + 2);
        
        SetCursorPos(ImVec2(0, 0));
        InvisibleButton(O("##FloatBtnHit"), ImVec2(totalWidth, totalHeight));
        isHovered = IsItemHovered();
        
        float targetHover = isHovered ? 1.0f : 0.0f;
        hoverAnim += (targetHover - hoverAnim) * io.DeltaTime * 10.0f;
        
        float currentRadius = buttonRadius + hoverAnim * 4.0f;
        
        dl->AddCircleFilled(ImVec2(center.x + 2, center.y + 3), currentRadius, IM_COL32(0, 0, 0, 60), 32);
        dl->AddCircleFilled(center, currentRadius, IM_COL32(30, 85, 160, 255), 32);
        dl->AddCircleFilled(center, currentRadius - 4, IM_COL32(40, 100, 180, 255), 32);
        dl->AddCircle(center, currentRadius, IM_COL32(70, 150, 230, (int)(200 + 55 * hoverAnim)), 32, 2.5f);
        
        float iconSize = 12.0f;
        ImU32 iconColor = IM_COL32(255, 255, 255, 255);
        
        if (g_menu.isOpen) {
            dl->AddLine(ImVec2(center.x - iconSize, center.y - iconSize), ImVec2(center.x + iconSize, center.y + iconSize), iconColor, 3.5f);
            dl->AddLine(ImVec2(center.x + iconSize, center.y - iconSize), ImVec2(center.x - iconSize, center.y + iconSize), iconColor, 3.5f);
        } else {
            float barW = 14.0f;
            float barH = 3.0f;
            float gap = 6.0f;
            dl->AddRectFilled(ImVec2(center.x - barW, center.y - gap - barH), ImVec2(center.x + barW, center.y - gap), iconColor, 2.0f);
            dl->AddRectFilled(ImVec2(center.x - barW, center.y - barH * 0.5f), ImVec2(center.x + barW, center.y + barH * 0.5f), iconColor, 2.0f);
            dl->AddRectFilled(ImVec2(center.x - barW, center.y + gap), ImVec2(center.x + barW, center.y + gap + barH), iconColor, 2.0f);
        }
        
        float textX = buttonPos.x + buttonSize + 12.0f;
        float textY = buttonPos.y + (totalHeight - 38.0f) * 0.5f;
        dl->AddText(ImVec2(textX, textY), IM_COL32(70, 160, 255, 255), O("AK"));
        dl->AddText(ImVec2(textX, textY + 24.0f), IM_COL32(180, 180, 190, 255), O("Engine"));
        
        if (IsItemActive() && IsMouseDragging(0)) {
            isDragging = true;
            buttonPos.x += io.MouseDelta.x;
            buttonPos.y += io.MouseDelta.y;
            buttonPos.x = ImClamp(buttonPos.x, 0.0f, (float)Width - totalWidth);
            buttonPos.y = ImClamp(buttonPos.y, 0.0f, (float)Height - totalHeight);
        }
        
        if (IsItemHovered() && IsMouseReleased(0) && !isDragging) {
            g_menu.isOpen = !g_menu.isOpen;
        }
        
        if (!IsItemActive()) isDragging = false;
    }
    End();
    
    PopStyleVar(2);
    PopStyleColor();
}

static bool first_time = true;

static jobject GetCurrentAndroidActivity(JNIEnv* env) {
    if (!env) return nullptr;

    jclass activityThreadClass = env->FindClass("android/app/ActivityThread");
    if (!activityThreadClass) return nullptr;

    jmethodID currentActivityThread = env->GetStaticMethodID(
        activityThreadClass,
        "currentActivityThread",
        "()Landroid/app/ActivityThread;"
    );
    if (!currentActivityThread) {
        env->DeleteLocalRef(activityThreadClass);
        return nullptr;
    }

    jobject activityThread = env->CallStaticObjectMethod(
        activityThreadClass,
        currentActivityThread
    );
    if (!activityThread) {
        env->DeleteLocalRef(activityThreadClass);
        return nullptr;
    }

    jfieldID activitiesField = env->GetFieldID(
        activityThreadClass,
        "mActivities",
        "Landroid/util/ArrayMap;"
    );
    if (!activitiesField) {
        env->DeleteLocalRef(activityThread);
        env->DeleteLocalRef(activityThreadClass);
        return nullptr;
    }

    jobject activities = env->GetObjectField(activityThread, activitiesField);
    if (!activities) {
        env->DeleteLocalRef(activityThread);
        env->DeleteLocalRef(activityThreadClass);
        return nullptr;
    }

    jclass arrayMapClass = env->FindClass("android/util/ArrayMap");
    jclass collectionClass = env->FindClass("java/util/Collection");
    jclass iteratorClass = env->FindClass("java/util/Iterator");

    if (!arrayMapClass || !collectionClass || !iteratorClass) {
        if (arrayMapClass) env->DeleteLocalRef(arrayMapClass);
        if (collectionClass) env->DeleteLocalRef(collectionClass);
        if (iteratorClass) env->DeleteLocalRef(iteratorClass);
        env->DeleteLocalRef(activities);
        env->DeleteLocalRef(activityThread);
        env->DeleteLocalRef(activityThreadClass);
        return nullptr;
    }

    jmethodID valuesMethod = env->GetMethodID(
        arrayMapClass,
        "values",
        "()Ljava/util/Collection;"
    );
    jobject values = valuesMethod
        ? env->CallObjectMethod(activities, valuesMethod)
        : nullptr;

    jobject activity = nullptr;
    if (values) {
        jmethodID iteratorMethod = env->GetMethodID(
            collectionClass,
            "iterator",
            "()Ljava/util/Iterator;"
        );
        jobject iterator = iteratorMethod
            ? env->CallObjectMethod(values, iteratorMethod)
            : nullptr;

        if (iterator) {
            jmethodID hasNextMethod = env->GetMethodID(
                iteratorClass,
                "hasNext",
                "()Z"
            );
            jmethodID nextMethod = env->GetMethodID(
                iteratorClass,
                "next",
                "()Ljava/lang/Object;"
            );

            while (hasNextMethod && nextMethod &&
                   env->CallBooleanMethod(iterator, hasNextMethod)) {
                jobject record = env->CallObjectMethod(iterator, nextMethod);
                if (!record) continue;

                jclass recordClass = env->GetObjectClass(record);
                jfieldID activityField = recordClass
                    ? env->GetFieldID(recordClass, "activity", "Landroid/app/Activity;")
                    : nullptr;

                if (activityField) {
                    jobject candidate = env->GetObjectField(record, activityField);
                    if (candidate) {
                        activity = env->NewGlobalRef(candidate);
                        env->DeleteLocalRef(candidate);
                        env->DeleteLocalRef(recordClass);
                        env->DeleteLocalRef(record);
                        break;
                    }
                }

                if (recordClass) env->DeleteLocalRef(recordClass);
                env->DeleteLocalRef(record);
            }

            env->DeleteLocalRef(iterator);
        }

        env->DeleteLocalRef(values);
    }

    env->DeleteLocalRef(arrayMapClass);
    env->DeleteLocalRef(collectionClass);
    env->DeleteLocalRef(iteratorClass);
    env->DeleteLocalRef(activities);
    env->DeleteLocalRef(activityThread);
    env->DeleteLocalRef(activityThreadClass);

    return activity;
}

static bool ShowAndroidSoftKeyboard() {
    if (!VM) return false;

    JNIEnv* env = nullptr;
    jint getEnvResult = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
    bool attachedHere = false;

    if (getEnvResult == JNI_EDETACHED) {
        if (VM->AttachCurrentThread(&env, nullptr) != 0) return false;
        attachedHere = true;
    } else if (getEnvResult != JNI_OK || !env) {
        return false;
    }

    jobject activity = GetCurrentAndroidActivity(env);
    if (!activity) {
        if (attachedHere) VM->DetachCurrentThread();
        return false;
    }

    bool shown = false;

    jclass activityClass = env->GetObjectClass(activity);
    jmethodID getWindow = activityClass
        ? env->GetMethodID(activityClass, "getWindow", "()Landroid/view/Window;")
        : nullptr;
    jobject window = getWindow
        ? env->CallObjectMethod(activity, getWindow)
        : nullptr;

    if (window) {
        jclass windowClass = env->GetObjectClass(window);
        jmethodID getDecorView = windowClass
            ? env->GetMethodID(windowClass, "getDecorView", "()Landroid/view/View;")
            : nullptr;
        jobject decorView = getDecorView
            ? env->CallObjectMethod(window, getDecorView)
            : nullptr;

        if (decorView) {
            jmethodID requestFocus = env->GetMethodID(
                env->GetObjectClass(decorView),
                "requestFocus",
                "()Z"
            );
            if (requestFocus) {
                env->CallBooleanMethod(decorView, requestFocus);
            }

            jclass contextClass = env->FindClass("android/content/Context");
            jfieldID inputMethodServiceField = contextClass
                ? env->GetStaticFieldID(
                    contextClass,
                    "INPUT_METHOD_SERVICE",
                    "Ljava/lang/String;"
                )
                : nullptr;
            jstring serviceName = inputMethodServiceField
                ? (jstring)env->GetStaticObjectField(contextClass, inputMethodServiceField)
                : nullptr;

            jmethodID getSystemService = activityClass
                ? env->GetMethodID(
                    activityClass,
                    "getSystemService",
                    "(Ljava/lang/String;)Ljava/lang/Object;"
                )
                : nullptr;
            jobject imm = (getSystemService && serviceName)
                ? env->CallObjectMethod(activity, getSystemService, serviceName)
                : nullptr;

            if (imm) {
                jclass immClass = env->FindClass("android/view/inputmethod/InputMethodManager");
                jmethodID showSoftInput = immClass
                    ? env->GetMethodID(
                        immClass,
                        "showSoftInput",
                        "(Landroid/view/View;I)Z"
                    )
                    : nullptr;

                if (showSoftInput) {
                    shown = env->CallBooleanMethod(imm, showSoftInput, decorView, 0) == JNI_TRUE;
                }

                if (immClass) env->DeleteLocalRef(immClass);
                env->DeleteLocalRef(imm);
            }

            if (serviceName) env->DeleteLocalRef(serviceName);
            if (contextClass) env->DeleteLocalRef(contextClass);
            env->DeleteLocalRef(decorView);
        }

        if (windowClass) env->DeleteLocalRef(windowClass);
        env->DeleteLocalRef(window);
    }

    if (activityClass) env->DeleteLocalRef(activityClass);
    env->DeleteGlobalRef(activity);

    if (attachedHere) VM->DetachCurrentThread();
    return shown;
}

INLINE void DrawLogin(ImGuiIO& io) {
    if (logged_in) return DrawMenu(io);

    // Dim Background Overlay
    SetNextWindowPos(ImVec2(0, 0));
    SetNextWindowSize(io.DisplaySize);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.04f, 0.05f, 0.07f, 0.90f));
    Begin(O("##Overlay"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBringToFrontOnFocus);
    PopStyleColor();

    float cardW = 500.0f;
    float cardH = 390.0f;

    SetNextWindowSize(ImVec2(cardW, cardH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    // Sleek Dark Slate Card
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.09f, 0.10f, 0.13f, 0.98f));
    PushStyleColor(ImGuiCol_Border, ImVec4(0.18f, 0.22f, 0.29f, 0.60f));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));

    Begin(O("##LoginCard"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar);

    ImDrawList* dl = GetWindowDrawList();
    ImVec2 winPos = GetWindowPos();

    // Subtle Top Glowing Accent Line
    DrawGradientRect(dl, winPos, ImVec2(winPos.x + cardW, winPos.y + 3.0f), IM_COL32(35, 120, 240, 255), IM_COL32(65, 200, 240, 255), true);

    // Top Header Section
    SetCursorPosY(28);
    ImVec2 tagSize = CalcTextSize("SECURE GATEWAY");
    float badgeW = tagSize.x + 22.0f;
    float badgeH = 22.0f;
    ImVec2 badgePos = ImVec2(winPos.x + (cardW - badgeW) * 0.5f, winPos.y + 24.0f);
    
    dl->AddRectFilled(badgePos, ImVec2(badgePos.x + badgeW, badgePos.y + badgeH), IM_COL32(30, 80, 160, 60), 11.0f);
    dl->AddRect(badgePos, ImVec2(badgePos.x + badgeW, badgePos.y + badgeH), IM_COL32(50, 140, 255, 120), 11.0f, 0, 1.0f);
    dl->AddText(ImVec2(badgePos.x + 11.0f, badgePos.y + 3.0f), IM_COL32(80, 175, 255, 255), "SECURE GATEWAY");

    SetCursorPosY(56);
    SetWindowFontScale(1.35f);
    ImVec2 titleSize = CalcTextSize("AK_ENGINE");
    SetCursorPosX((cardW - titleSize.x) * 0.5f);
    TextColored(ImVec4(0.96f, 0.97f, 1.0f, 1.0f), "AK_ENGINE");
    SetWindowFontScale(1.0f);

    SetCursorPosY(88);
    ImVec2 subSize = CalcTextSize("Enter your license key to authenticate");
    SetCursorPosX((cardW - subSize.x) * 0.5f);
    TextColored(ImVec4(0.50f, 0.54f, 0.62f, 1.0f), "Enter your license key to authenticate");

    // Dynamic Error Banner
    if (!ERROR_MESSAGE.empty()) {
        SetCursorPosY(118);
        SetCursorPosX(35);
        ImVec2 errBoxMin = ImVec2(winPos.x + 35, winPos.y + 118);
        ImVec2 errBoxMax = ImVec2(winPos.x + cardW - 35, winPos.y + 154);
        dl->AddRectFilled(errBoxMin, errBoxMax, IM_COL32(230, 50, 65, 30), 8.0f);
        dl->AddRect(errBoxMin, errBoxMax, IM_COL32(230, 50, 65, 110), 8.0f, 0, 1.0f);

        SetCursorPos(ImVec2(45, 126));
        PushTextWrapPos(cardW - 45);
        TextColored(ImVec4(1.0f, 0.35f, 0.35f, 1.0f), "%s", ERROR_MESSAGE.c_str());
        PopTextWrapPos();
    }

    if (is_logging_in) {
        SetCursorPosY(180);

        static float spinner_angle = 0.0f;
        spinner_angle += io.DeltaTime * 6.0f;

        float spinner_size = 32.0f;
        ImVec2 spinnerCenter = ImVec2(winPos.x + cardW * 0.5f, winPos.y + 225);

        for (int i = 0; i < 14; i++) {
            float angle = spinner_angle + (i * PI * 2.0f / 14.0f);
            float alpha = (float)(14 - i) / 14.0f;
            ImVec2 dotPos = ImVec2(
                spinnerCenter.x + cosf(angle) * spinner_size,
                spinnerCenter.y + sinf(angle) * spinner_size
            );
            dl->AddCircleFilled(dotPos, 4.5f, IM_COL32(50, 160, 255, (int)(alpha * 255)));
        }

        SetCursorPosY(280);
        ImVec2 loadingSize = CalcTextSize("Verifying License Key...");
        SetCursorPosX((cardW - loadingSize.x) * 0.5f);
        TextColored(ImVec4(0.70f, 0.75f, 0.85f, 1.0f), "Verifying License Key...");
    } else {
        SetCursorPosY(168);

        static char licenseKey[256] = "";
        static bool inputInitialized = false;
        static bool inputWasActive = false;

        if (!inputInitialized) {
            const std::string& savedKey = persistent_string["key"];
            if (!savedKey.empty()) {
                std::strncpy(licenseKey, savedKey.c_str(), sizeof(licenseKey) - 1);
                licenseKey[sizeof(licenseKey) - 1] = '\0';
            }
            inputInitialized = true;
        }

        const float inputH = 50.0f;
        const float pasteW = 48.0f;
        const float gap = 8.0f;
        const float inputW = cardW - 70.0f - pasteW - gap;

        SetCursorPosX(35);
        PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.06f, 0.07f, 0.09f, 1.0f));
        PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.08f, 0.09f, 0.12f, 1.0f));
        PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0.09f, 0.11f, 0.15f, 1.0f));
        PushStyleColor(ImGuiCol_Border, ImVec4(0.20f, 0.25f, 0.33f, 0.9f));
        PushStyleColor(ImGuiCol_Text, ImVec4(0.95f, 0.97f, 1.0f, 1.0f));
        PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
        PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
        PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(16.0f, 12.0f));

        InputText(
            "##LicenseKey",
            licenseKey,
            sizeof(licenseKey),
            ImGuiInputTextFlags_CharsNoBlank
        );

        bool inputActive = IsItemActive();
        if (inputActive && !inputWasActive) {
            ShowAndroidSoftKeyboard();
        }
        inputWasActive = inputActive;

        PopStyleVar(3);
        PopStyleColor(5);

        SameLine(0.0f, gap);

        // Modern Minimalist Paste Button
        PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.15f, 0.20f, 1.0f));
        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.16f, 0.21f, 0.29f, 1.0f));
        PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.10f, 0.13f, 0.18f, 1.0f));
        PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
        PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
        PushStyleColor(ImGuiCol_Border, ImVec4(0.22f, 0.28f, 0.38f, 0.8f));

        bool pastePressed = Button("##PasteLicense", ImVec2(pasteW, inputH));
        ImVec2 iconMin = GetItemRectMin();
        ImVec2 iconMax = GetItemRectMax();
        ImVec2 iconCenter = ImVec2(
            (iconMin.x + iconMax.x) * 0.5f,
            (iconMin.y + iconMax.y) * 0.5f
        );

        // Vector Clipboard Icon
        ImDrawList* iconDl = GetWindowDrawList();
        ImVec2 backMin = ImVec2(iconCenter.x - 8.0f, iconCenter.y - 9.0f);
        ImVec2 backMax = ImVec2(iconCenter.x + 6.0f, iconCenter.y + 8.0f);
        ImVec2 frontMin = ImVec2(iconCenter.x - 4.0f, iconCenter.y - 5.0f);
        ImVec2 frontMax = ImVec2(iconCenter.x + 10.0f, iconCenter.y + 10.0f);

        iconDl->AddRect(backMin, backMax, IM_COL32(140, 160, 185, 200), 2.5f, 0, 1.6f);
        iconDl->AddRectFilled(frontMin, frontMax, IM_COL32(35, 110, 200, 240), 2.5f);
        iconDl->AddRect(frontMin, frontMax, IM_COL32(200, 225, 255, 255), 2.5f, 0, 1.6f);

        PopStyleVar(2);
        PopStyleColor(4);

        if (pastePressed) {
            JNIEnv* env = nullptr;
            jint getEnvResult = VM ? VM->GetEnv((void**)&env, JNI_VERSION_1_6) : JNI_ERR;
            bool attachedHere = false;

            if (getEnvResult == JNI_EDETACHED) {
                if (VM->AttachCurrentThread(&env, nullptr) == 0) {
                    attachedHere = true;
                } else {
                    env = nullptr;
                }
            }

            if (env) {
                std::string clipboardText = getClipboard(env);
                if (!clipboardText.empty()) {
                    std::strncpy(licenseKey, clipboardText.c_str(), sizeof(licenseKey) - 1);
                    licenseKey[sizeof(licenseKey) - 1] = '\0';
                    ERROR_MESSAGE.clear();
                } else {
                    ERROR_MESSAGE = O("Clipboard is empty");
                }
            } else {
                ERROR_MESSAGE = O("Failed to access clipboard");
            }

            if (attachedHere) VM->DetachCurrentThread();
        }

        // Action Button: Online Verification
        SetCursorPosY(242);
        SetCursorPosX(35);
        PushStyleColor(ImGuiCol_Button, ImVec4(0.14f, 0.46f, 0.86f, 1.0f));
        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.18f, 0.54f, 0.96f, 1.0f));
        PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.12f, 0.40f, 0.76f, 1.0f));
        PushStyleVar(ImGuiStyleVar_FrameRounding, 11.0f);

        if (Button("AUTHENTICATE", ImVec2(cardW - 70, 52))) {
            std::string key = licenseKey;

            if (key.empty()) {
                ERROR_MESSAGE = O("Please enter your license key");
            } else {
                JNIEnv* env = nullptr;
                jint getEnvResult = VM ? VM->GetEnv((void**)&env, JNI_VERSION_1_6) : JNI_ERR;

                if (getEnvResult == JNI_EDETACHED) {
                    if (VM->AttachCurrentThread(&env, nullptr) != 0) {
                        ERROR_MESSAGE = O("Failed to attach thread to JVM");
                    } else {
                        std::string androidId = getAndroidID(env);
                        std::thread([](std::string androidId, std::string key) {
                            Login(androidId, key);
                        }, androidId, key).detach();
                        first_time = false;
                    }
                } else if (getEnvResult != JNI_OK || !env) {
                    ERROR_MESSAGE = O("Failed to get JNIEnv");
                } else {
                    std::string androidId = getAndroidID(env);
                    std::thread([](std::string androidId, std::string key) {
                        Login(androidId, key);
                    }, androidId, key).detach();
                    first_time = false;
                }
            }
        }

        PopStyleVar();
        PopStyleColor(3);

        // Bottom Footer Hint
        SetCursorPosY(312);
        ImVec2 helpSize = CalcTextSize("Directly paste your key or tap input to type");
        SetCursorPosX((cardW - helpSize.x) * 0.5f);
        TextColored(ImVec4(0.38f, 0.42f, 0.50f, 1.0f), "Directly paste your key or tap input to type");
    }

    End();
    PopStyleVar(3);
    PopStyleColor(2);

    End();
}

INLINE void SetupImgui() {
    PACKAGE_NAME = string(getcmdline());

    ImGui::CreateContext();

    auto& style = ImGui::GetStyle();
    auto& io = ImGui::GetIO();

    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;

    switch_theme(current_theme);

    load_persistence();
    load_imgui_style();

    static string INI_PATH = O("/data/user_de/0/") + PACKAGE_NAME + O("/no_backup/.ini");
    io.IniFilename = persistent_bool["bImguiAutoSave"] ? INI_PATH.c_str() : nullptr;
    io.ConfigWindowsMoveFromTitleBarOnly = persistent_bool["bMoveOnlyWithTitleBar"];

    ImFontConfig font_cfg;
    font_cfg.SizePixels = persistent_float["fFontScale"];
    io.Fonts->AddFontDefault(&font_cfg);

    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(O("#version 300 es"));

    bImguiSetup = true;
}

DEFINES(EGLBoolean, Draw, EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &Width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &Height);

    if (Width <= 0 || Height <= 0) return _Draw(dpy, surface);

    screenCenter = Vector2(Width / 2, Height / 2);

    if (!bImguiSetup) SetupImgui();

    ImGuiIO& io = ImGui::GetIO();

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(Width, Height);
    ImGui::NewFrame();

    if (!is_segv_handler_active()) setup_global_segv_handler();
    if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        DrawFloatingButton(io);
        DrawMenu(io);
    } else {
        DrawLogin(io);
    }
    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    ImGui_ClearHoverEffect();

    return _Draw(dpy, surface);
}

void __IMGUI__() {
    create_directory_recursive(CONC(O("/data/user_de/0/"), PACKAGE_NAME.c_str(), O("/no_backup")));
}
